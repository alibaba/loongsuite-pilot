#!/usr/bin/env bash
set -euo pipefail

default_root="${PILOT_DATA:-${HOME}/.local/share/teamharness}"
target_dir="${TEAMHARNESS_QODERCLI_PLUGIN_DIR:-${default_root}/plugins/teamharness-qodercli-plugin}"
rm -rf "${target_dir}"

if [ -n "${TEAMHARNESS_INSTALL_LOG:-}" ]; then
  mkdir -p "$(dirname "${TEAMHARNESS_INSTALL_LOG}")"
  printf '{"event":"uninstall","runtime":"qodercli","pluginDir":"%s"}\n' "${target_dir}" >> "${TEAMHARNESS_INSTALL_LOG}"
fi
