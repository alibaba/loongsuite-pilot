#!/usr/bin/env bash
set -euo pipefail

bundle_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
node_bin="${PILOT_NODE_BIN:-node}"
export TEAMHARNESS_NODE_BIN="${TEAMHARNESS_NODE_BIN:-${node_bin}}"
export TEAMHARNESS_CLAUDE_PLUGIN_DIR="${TEAMHARNESS_CLAUDE_PLUGIN_DIR:-${bundle_dir}/teamharness-claude-plugin}"
export TEAMHARNESS_NODE_RUNTIME_CORE_DIR="${TEAMHARNESS_NODE_RUNTIME_CORE_DIR:-${bundle_dir}/node-runtime-core}"
export TEAMHARNESS_STATE_DIR="${TEAMHARNESS_STATE_DIR:-${bundle_dir}/.agentteams/runtime/claude-code}"

exec "${node_bin}" "${bundle_dir}/claude-code-worker/dist/cli.js" "$@"
