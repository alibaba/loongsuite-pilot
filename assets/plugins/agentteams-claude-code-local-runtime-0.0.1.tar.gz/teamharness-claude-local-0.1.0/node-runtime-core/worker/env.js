#!/usr/bin/env node
"use strict";

const CONTEXT_TEAMHARNESS_KEYS = new Set([
  "TEAMHARNESS_TEAM_NAME",
  "TEAMHARNESS_MEMBER_NAME",
  "TEAMHARNESS_ROLE",
  "TEAMHARNESS_RUNTIME_CONFIG",
  "TEAMHARNESS_SHARED_DIR"
]);

function cleanManagedEnv(source) {
  const env = {};
  for (const [key, value] of Object.entries(source || {})) {
    if (key.startsWith("HICLAW_")) continue;
    if (key.startsWith("AGENTTEAM_")) continue;
    if (key.startsWith("AGENTTEAMS_")) continue;
    if (CONTEXT_TEAMHARNESS_KEYS.has(key)) continue;
    env[key] = value;
  }
  return env;
}

function agentteamsEnv(options) {
  const opts = options || {};
  const edge = opts.edge || {};
  const runtimeState = opts.runtimeState || {};
  const member = runtimeState.runtime?.member || {};
  return {
    AGENTTEAMS_WORKER_NAME: String(edge.workerName || member.runtimeName || "").trim()
  };
}

function buildManagedRuntimeEnv(baseEnv, options) {
  const opts = options || {};
  const env = cleanManagedEnv(baseEnv);
  env.TEAMHARNESS_NODE_BIN = env.TEAMHARNESS_NODE_BIN || process.execPath;
  if (Object.prototype.hasOwnProperty.call(opts, "brokerDescriptor")) {
    env.TEAMHARNESS_CREDENTIAL_BROKER_DESCRIPTOR = String(opts.brokerDescriptor || "");
  }
  Object.assign(env, agentteamsEnv(opts));
  return env;
}

module.exports = {
  agentteamsEnv,
  buildManagedRuntimeEnv,
  cleanManagedEnv
};
