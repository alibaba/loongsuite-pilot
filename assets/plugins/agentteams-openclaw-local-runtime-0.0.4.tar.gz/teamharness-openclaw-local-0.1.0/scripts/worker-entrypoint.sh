#!/usr/bin/env bash
set -euo pipefail

bundle_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
node_bin="${PILOT_NODE_BIN:-node}"
export TEAMHARNESS_NODE_BIN="${TEAMHARNESS_NODE_BIN:-${node_bin}}"
export TEAMHARNESS_OPENCLAW_ASSETS_DIR="${TEAMHARNESS_OPENCLAW_ASSETS_DIR:-${bundle_dir}/teamharness-openclaw-assets}"
export TEAMHARNESS_STATE_DIR="${TEAMHARNESS_STATE_DIR:-${bundle_dir}/.agentteams/runtime/openclaw}"

normalize_args() {
  local -a normalized=()
  while [ "$#" -gt 0 ]; do
    case "$1" in
      --plugin-install-scope)
        if [ "$#" -ge 2 ] && [ -z "${2:-}" ]; then
          normalized+=("--plugin-install-scope" "local")
          shift 2
        elif [ "$#" -ge 2 ] && [[ "${2}" != --* ]]; then
          normalized+=("--plugin-install-scope" "$2")
          shift 2
        else
          normalized+=("--plugin-install-scope" "local")
          shift
        fi
        ;;
      --model-config-mode)
        if [ "$#" -ge 2 ] && [ -z "${2:-}" ]; then
          normalized+=("--model-config-mode" "native-config")
          shift 2
        elif [ "$#" -ge 2 ] && [[ "${2}" != --* ]]; then
          normalized+=("--model-config-mode" "$2")
          shift 2
        else
          normalized+=("--model-config-mode" "native-config")
          shift
        fi
        ;;
      *)
        normalized+=("$1")
        shift
        ;;
    esac
  done
  set -- "${normalized[@]}"
  exec "${node_bin}" "${bundle_dir}/openclaw-worker/dist/cli.js" "$@"
}

normalize_args "$@"
