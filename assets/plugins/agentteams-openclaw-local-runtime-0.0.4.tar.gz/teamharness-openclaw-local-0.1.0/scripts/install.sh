#!/usr/bin/env bash
set -euo pipefail

bundle_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
default_root="${PILOT_DATA:-${HOME}/.local/share/teamharness}"
target_dir="${TEAMHARNESS_OPENCLAW_ASSETS_DIR:-${default_root}/plugins/teamharness-openclaw-assets}"
tmp_dir="${target_dir}.tmp"

rm -rf "${tmp_dir}"
mkdir -p "${tmp_dir}"
(cd "${bundle_dir}/teamharness-openclaw-assets" && tar -cf - .) | (cd "${tmp_dir}" && tar -xf -)
rm -rf "${target_dir}"
mv "${tmp_dir}" "${target_dir}"

if [ -n "${TEAMHARNESS_INSTALL_LOG:-}" ]; then
  mkdir -p "$(dirname "${TEAMHARNESS_INSTALL_LOG}")"
  printf '{"event":"install","runtime":"openclaw","assetsDir":"%s"}\n' "${target_dir}" >> "${TEAMHARNESS_INSTALL_LOG}"
fi
