#!/usr/bin/env bash
set -euo pipefail

bundle_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
node_bin="${PILOT_NODE_BIN:-node}"
export TEAMHARNESS_NODE_BIN="${TEAMHARNESS_NODE_BIN:-${node_bin}}"
export TEAMHARNESS_OPENCLAW_ASSETS_DIR="${TEAMHARNESS_OPENCLAW_ASSETS_DIR:-${bundle_dir}/teamharness-openclaw-assets}"
export TEAMHARNESS_STATE_DIR="${TEAMHARNESS_STATE_DIR:-${bundle_dir}/.agentteams/runtime/openclaw}"

exec "${node_bin}" "${bundle_dir}/openclaw-worker/dist/cli.js" "$@"
