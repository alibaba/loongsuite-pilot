#!/usr/bin/env node
"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");

const BINDING_NAMES = ["credentialBroker", "nodeExecutable"];
const EXECUTABLE_BINDINGS = new Set(["nodeExecutable"]);
const ENV_PATTERN = /^[A-Z_][A-Z0-9_]*$/;

function pluginError(reason, message, detail) {
  return Object.assign(new Error(message), { reason }, detail ? { detail } : {});
}

function invalidBinding(message, detail) {
  throw pluginError("PluginBindingInvalid", message, detail);
}

function unavailable(message, detail) {
  throw pluginError("RuntimeBindingUnavailable", message, detail);
}

function isWithin(file, root) {
  return file === root || file.startsWith(`${root}${path.sep}`);
}

function realDirectory(value, label) {
  if (typeof value !== "string" || !path.isAbsolute(value)) {
    unavailable(`${label} must be an absolute directory`, { type: "cwd" });
  }
  try {
    const resolved = fs.realpathSync(value);
    if (!fs.statSync(resolved).isDirectory()) throw new Error("not a directory");
    return resolved;
  } catch {
    unavailable(`${label} is unavailable`, { type: "cwd" });
  }
}

function realFile(value, label, { roots, executable = false, type } = {}) {
  if (typeof value !== "string" || !path.isAbsolute(value)) {
    unavailable(`${label} must be an absolute file`, { type });
  }
  let resolved;
  let stat;
  try {
    resolved = fs.realpathSync(value);
    stat = fs.statSync(resolved);
    if (!stat.isFile()) throw new Error("not a file");
  } catch {
    unavailable(`${label} is unavailable`, { type });
  }
  if (executable && process.platform !== "win32" && (stat.mode & 0o111) === 0) {
    unavailable(`${label} is not executable`, { type: "executable" });
  }
  if (roots?.length && !roots.some(root => isWithin(resolved, root))) {
    unavailable(`${label} escapes its allowed roots`, { type });
  }
  return resolved;
}

function validateManifestBindings(manifest) {
  const bindings = manifest?.bindings;
  if (!bindings || typeof bindings !== "object" || Array.isArray(bindings)) {
    invalidBinding("manifest bindings are required", { type: "missing-reference" });
  }
  const envNames = new Set();
  for (const name of Object.keys(bindings)) {
    if (!BINDING_NAMES.includes(name)) {
      invalidBinding("manifest contains an unknown binding", { type: "unknown-binding", binding: name });
    }
    const env = bindings[name]?.env;
    if (typeof env !== "string" || !ENV_PATTERN.test(env)) {
      invalidBinding("binding env is invalid", { type: "invalid-env", binding: name });
    }
    if (envNames.has(env)) {
      invalidBinding("binding env names must be globally unique", { type: "env-conflict", binding: name });
    }
    envNames.add(env);
  }
  return bindings;
}

function bindingNames(value, label, bindings) {
  if (!Array.isArray(value)) {
    invalidBinding(`${label} must be an array`, { type: "missing-reference" });
  }
  const seen = new Set();
  for (const name of value) {
    if (!BINDING_NAMES.includes(name)) {
      invalidBinding(`${label} contains an unknown binding`, { type: "unknown-binding", binding: name });
    }
    if (!Object.prototype.hasOwnProperty.call(bindings, name)) {
      invalidBinding(`${label} references an undeclared binding`, { type: "missing-reference", binding: name });
    }
    if (seen.has(name)) {
      invalidBinding(`${label} contains a duplicate binding`, { type: "duplicate-reference", binding: name });
    }
    seen.add(name);
  }
  return value;
}

function resolveRuntimeBindings({
  manifest,
  resolvedResources,
  runtimeServices,
  executables,
  instanceDirs
} = {}) {
  const bindings = validateManifestBindings(manifest);
  const dirs = instanceDirs || {};
  const inferredInstanceRoot = dirs.instanceRoot || (
    dirs.pluginStateDir ? path.dirname(path.dirname(path.resolve(dirs.pluginStateDir))) : ""
  );
  const instanceRoot = realDirectory(inferredInstanceRoot, "instance root");
  const workspaceDir = realDirectory(dirs.effectiveWorkspaceDir, "effective workspace");
  const pluginSourceDir = (resolvedResources?.mcpServers || []).length > 0
    ? realDirectory(dirs.pluginSourceDir, "plugin source")
    : null;
  if (dirs.pluginStateDir) {
    const pluginStateDir = realDirectory(dirs.pluginStateDir, "plugin state");
    if (!isWithin(pluginStateDir, instanceRoot)) {
      unavailable("plugin state escapes the instance root", { type: "cwd" });
    }
  }

  const resolvedExecutables = {
    node: realFile(executables?.node, "Node executable", {
      executable: true,
      type: "executable"
    })
  };
  const resolvedValues = new Map([["nodeExecutable", resolvedExecutables.node]]);
  const resolveValue = name => {
    if (resolvedValues.has(name)) return resolvedValues.get(name);
    let value;
    if (name === "credentialBroker") {
      value = realFile(
        runtimeServices?.credentialBroker?.descriptorPath,
        "credential broker descriptor",
        { roots: [instanceRoot], type: "descriptor" }
      );
    } else if (name === "nodeExecutable") {
      value = resolvedExecutables.node;
    } else {
      invalidBinding("binding is not supported", { type: "unknown-binding", binding: name });
    }
    resolvedValues.set(name, value);
    return value;
  };

  const runtimeBindingNames = new Set();
  for (const skill of resolvedResources?.skills || []) {
    for (const name of bindingNames(skill.bindings || [], `skill ${skill.id}.bindings`, bindings)) {
      runtimeBindingNames.add(name);
    }
  }
  const runtimeEnv = {};
  for (const name of BINDING_NAMES) {
    if (runtimeBindingNames.has(name)) runtimeEnv[bindings[name].env] = resolveValue(name);
  }

  const mcpServers = [];
  for (const server of resolvedResources?.mcpServers || []) {
    const commandBinding = server?.command?.binding;
    if (!BINDING_NAMES.includes(commandBinding) || !Object.prototype.hasOwnProperty.call(bindings, commandBinding)) {
      invalidBinding(`MCP server ${server?.id || "<unknown>"} command binding is unknown`, {
        type: "missing-reference",
        binding: commandBinding
      });
    }
    if (!EXECUTABLE_BINDINGS.has(commandBinding)) {
      invalidBinding(`MCP server ${server.id} command binding is not executable`, {
        type: "invalid-command-binding",
        binding: commandBinding
      });
    }
    const serverBindingNames = bindingNames(server.bindings || [], `MCP server ${server.id}.bindings`, bindings);
    const env = {};
    for (const name of serverBindingNames) env[bindings[name].env] = resolveValue(name);
    if (!Array.isArray(server.args) || server.args.length === 0) {
      invalidBinding(`MCP server ${server.id}.args must not be empty`, { type: "invalid-args" });
    }
    const args = server.args.map((arg, index) => realFile(arg, `MCP server ${server.id} arg ${index}`, {
      roots: [pluginSourceDir],
      type: "plugin-path"
    }));
    mcpServers.push({
      id: server.id,
      command: resolveValue(commandBinding),
      args,
      cwd: workspaceDir,
      env
    });
  }

  const digestInput = {
    executables: resolvedExecutables,
    runtimeEnv,
    mcpServers
  };
  const runtimeBindingDigest = `sha256:${crypto
    .createHash("sha256")
    .update(JSON.stringify(digestInput))
    .digest("hex")}`;
  return { executables: resolvedExecutables, runtimeEnv, mcpServers, runtimeBindingDigest };
}

module.exports = {
  resolveRuntimeBindings
};
