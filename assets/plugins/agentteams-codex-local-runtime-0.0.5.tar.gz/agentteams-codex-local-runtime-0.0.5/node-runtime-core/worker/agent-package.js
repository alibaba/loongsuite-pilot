#!/usr/bin/env node
"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const zlib = require("node:zlib");

const { ossFetch } = require("./storage-oss");
const { readJson, writeJson } = require("./status");

const EMPTY_AGENT_PACKAGE_DIGEST = `sha256:${crypto.createHash("sha256").update("").digest("hex")}`;
const MAX_ARCHIVE_BYTES = 64 * 1024 * 1024;
const MAX_EXTRACTED_BYTES = 256 * 1024 * 1024;
const MAX_ENTRIES = 10_000;
const PACKAGE_MARKER = ".agent-package.json";

function throwIfAborted(signal) {
  if (!signal?.aborted) return;
  const error = new Error("Agent Package load aborted");
  error.name = "AbortError";
  throw error;
}

function statePath(args) {
  return path.join(args.stateDir, "agent-package-state.json");
}

function safeJoin(root, entryName) {
  const rootPath = path.resolve(root);
  const target = path.resolve(rootPath, entryName);
  if (target !== rootPath && !target.startsWith(`${rootPath}${path.sep}`)) {
    throw new Error(`unsafe zip entry path: ${entryName}`);
  }
  return target;
}

function findEndOfCentralDirectory(buffer) {
  const min = Math.max(0, buffer.length - 0xffff - 22);
  for (let offset = buffer.length - 22; offset >= min; offset -= 1) {
    if (buffer.readUInt32LE(offset) === 0x06054b50) return offset;
  }
  throw new Error("invalid zip: end of central directory not found");
}

function extractZip(buffer, destination) {
  if (!Buffer.isBuffer(buffer)) throw new Error("Agent Package archive must be a Buffer");
  if (buffer.length > MAX_ARCHIVE_BYTES) throw new Error("Agent Package archive exceeds size limit");
  const eocd = findEndOfCentralDirectory(buffer);
  const entryCount = buffer.readUInt16LE(eocd + 10);
  if (entryCount > MAX_ENTRIES) throw new Error("Agent Package archive has too many entries");
  const centralSize = buffer.readUInt32LE(eocd + 12);
  const centralStart = buffer.readUInt32LE(eocd + 16);
  const centralEnd = centralStart + centralSize;
  if (centralStart > eocd || centralEnd > eocd) {
    throw new Error("invalid zip: central directory is out of bounds");
  }
  let centralOffset = centralStart;
  let declaredBytes = 0;
  const entries = [];

  for (let index = 0; index < entryCount; index += 1) {
    if (centralOffset + 46 > centralEnd || buffer.readUInt32LE(centralOffset) !== 0x02014b50) {
      throw new Error("invalid zip: central directory entry expected");
    }
    const madeBy = buffer.readUInt16LE(centralOffset + 4);
    const method = buffer.readUInt16LE(centralOffset + 10);
    const compressedSize = buffer.readUInt32LE(centralOffset + 20);
    const uncompressedSize = buffer.readUInt32LE(centralOffset + 24);
    const fileNameLength = buffer.readUInt16LE(centralOffset + 28);
    const extraLength = buffer.readUInt16LE(centralOffset + 30);
    const commentLength = buffer.readUInt16LE(centralOffset + 32);
    const externalAttributes = buffer.readUInt32LE(centralOffset + 38);
    const localHeaderOffset = buffer.readUInt32LE(centralOffset + 42);
    const nameStart = centralOffset + 46;
    const nameEnd = nameStart + fileNameLength;
    const entryEnd = nameEnd + extraLength + commentLength;
    if (entryEnd > centralEnd) throw new Error("invalid zip: truncated central directory entry");
    const entryName = buffer.subarray(nameStart, nameEnd).toString("utf8");
    centralOffset = entryEnd;

    const unixMode = madeBy >> 8 === 3 ? externalAttributes >>> 16 : 0;
    const unixFileType = unixMode & 0o170000;
    const directory = entryName.endsWith("/");
    if (unixFileType === 0o120000) throw new Error(`symbolic links are not allowed: ${entryName}`);
    if (unixFileType !== 0 &&
        unixFileType !== (directory ? 0o040000 : 0o100000)) {
      throw new Error(`unsupported zip entry type: ${entryName}`);
    }
    if (!entryName || entryName.includes("\0") || path.isAbsolute(entryName)) {
      throw new Error(`unsafe zip entry path: ${entryName}`);
    }
    const target = safeJoin(destination, entryName);
    declaredBytes += uncompressedSize;
    if (declaredBytes > MAX_EXTRACTED_BYTES) {
      throw new Error("Agent Package extracted content exceeds size limit");
    }
    if (directory) {
      entries.push({ entryName, target, directory: true });
      continue;
    }
    if (method !== 0 && method !== 8) {
      throw new Error(`unsupported zip compression method ${method} for ${entryName}`);
    }
    if (method === 0 && compressedSize !== uncompressedSize) {
      throw new Error(`invalid zip size for ${entryName}`);
    }
    if (localHeaderOffset + 30 > buffer.length || buffer.readUInt32LE(localHeaderOffset) !== 0x04034b50) {
      throw new Error(`invalid zip local header for ${entryName}`);
    }
    if (buffer.readUInt16LE(localHeaderOffset + 8) !== method) {
      throw new Error(`invalid zip local header for ${entryName}`);
    }
    const localNameLength = buffer.readUInt16LE(localHeaderOffset + 26);
    const localExtraLength = buffer.readUInt16LE(localHeaderOffset + 28);
    const dataStart = localHeaderOffset + 30 + localNameLength + localExtraLength;
    const dataEnd = dataStart + compressedSize;
    if (dataStart > centralStart || dataEnd > centralStart) throw new Error(`invalid zip data for ${entryName}`);
    entries.push({
      entryName,
      target,
      directory: false,
      unixMode,
      method,
      compressedSize,
      uncompressedSize,
      dataStart,
      dataEnd
    });
  }

  let extractedBytes = 0;
  fs.mkdirSync(destination, { recursive: true, mode: 0o700 });
  for (const entry of entries) {
    if (entry.directory) {
      fs.mkdirSync(entry.target, { recursive: true, mode: 0o700 });
      continue;
    }
    const {
      entryName,
      target,
      unixMode,
      method,
      uncompressedSize,
      dataStart,
      dataEnd
    } = entry;
    const compressed = buffer.subarray(dataStart, dataEnd);
    let data;
    if (method === 0) data = compressed;
    else {
      try {
        data = zlib.inflateRawSync(compressed, {
          maxOutputLength: Math.max(uncompressedSize, 1)
        });
      } catch (error) {
        if (error?.code === "ERR_BUFFER_TOO_LARGE") {
          throw new Error(`invalid zip size for ${entryName}`);
        }
        throw error;
      }
    }
    if (data.length !== uncompressedSize) throw new Error(`invalid zip size for ${entryName}`);
    extractedBytes += data.length;
    if (extractedBytes > MAX_EXTRACTED_BYTES) throw new Error("Agent Package extracted content exceeds size limit");
    fs.mkdirSync(path.dirname(target), { recursive: true, mode: 0o700 });
    fs.writeFileSync(target, data, { mode: unixMode & 0o111 ? 0o700 : 0o600 });
  }
}

function computePackageContentDigest(root) {
  const digest = crypto.createHash("sha256");
  const visit = (entryPath, relative) => {
    const entry = fs.lstatSync(entryPath);
    const mode = (entry.mode & 0o777).toString(8).padStart(3, "0");
    if (entry.isSymbolicLink()) throw new Error(`Agent Package cache must not contain symbolic links: ${entryPath}`);
    if (entry.isDirectory()) {
      digest.update(`D\0${relative}\0${mode}\0`);
      for (const name of fs.readdirSync(entryPath).sort()) {
        if (!relative && name === PACKAGE_MARKER) continue;
        visit(path.join(entryPath, name), relative ? `${relative}/${name}` : name);
      }
      return;
    }
    if (!entry.isFile()) throw new Error(`Agent Package cache contains unsupported entry: ${entryPath}`);
    if (entry.nlink !== 1) throw new Error(`Agent Package cache must not contain hard links: ${entryPath}`);
    const content = fs.readFileSync(entryPath);
    digest.update(`F\0${relative}\0${mode}\0${content.length}\0`);
    digest.update(content);
    digest.update("\0");
  };
  visit(root, "");
  return `sha256:${digest.digest("hex")}`;
}

function freezePackageTree(root) {
  const entry = fs.lstatSync(root);
  if (entry.isSymbolicLink()) throw new Error(`Agent Package cache must not contain symbolic links: ${root}`);
  if (entry.isDirectory()) {
    fs.chmodSync(root, 0o700);
    for (const name of fs.readdirSync(root)) freezePackageTree(path.join(root, name));
    return;
  }
  if (!entry.isFile()) throw new Error(`Agent Package cache contains unsupported entry: ${root}`);
  if (entry.nlink !== 1) throw new Error(`Agent Package cache must not contain hard links: ${root}`);
  fs.chmodSync(root, entry.mode & 0o111 ? 0o500 : 0o400);
}

function integrityError(message) {
  return Object.assign(new Error(message), { reason: "AgentPackageIntegrityFailed" });
}

function hasExpectedMarkerMode(entry, platform = process.platform) {
  const mode = entry.mode & 0o777;
  if (platform === "win32") return (mode & 0o444) !== 0 && (mode & 0o222) === 0;
  return mode === 0o400;
}

function verifyPackageContent(root, marker) {
  const markerPath = path.join(root, PACKAGE_MARKER);
  const markerEntry = fs.lstatSync(markerPath);
  if (!markerEntry.isFile() || markerEntry.nlink !== 1 || !hasExpectedMarkerMode(markerEntry)) {
    throw integrityError(`Agent Package cache marker mode mismatch: ${markerPath}`);
  }
  if (marker.agentPackageDigest !== marker.contentDigest) {
    throw integrityError(`Agent Package cache marker identity mismatch: ${markerPath}`);
  }
  if (!/^sha256:[0-9a-f]{64}$/.test(String(marker.contentDigest || "")) ||
      computePackageContentDigest(root) !== marker.contentDigest) {
    throw integrityError(`Agent Package cache content digest mismatch: ${root}`);
  }
}

function cachedPackage(args, state, ref) {
  if (!state || state.ref !== ref || !/^sha256:[0-9a-f]{64}$/.test(String(state.agentPackageDigest || ""))) {
    return null;
  }
  const expectedRoot = path.resolve(
    args.stateDir,
    "agent-package",
    "versions",
    state.agentPackageDigest.replace(/^sha256:/, "")
  );
  const root = path.resolve(String(state.packageRoot || ""));
  if (root !== expectedRoot) {
    throw integrityError(`Agent Package cache path mismatch: ${root}`);
  }
  if (!root || !fs.existsSync(path.join(root, PACKAGE_MARKER))) return null;
  const marker = readJson(path.join(root, PACKAGE_MARKER), {});
  if (marker.schemaVersion !== 1 || !marker.contentDigest) return null;
  if (marker.agentPackageDigest !== state.agentPackageDigest || marker.contentDigest !== state.agentPackageDigest) {
    throw integrityError(`Agent Package cache marker identity mismatch: ${path.join(root, PACKAGE_MARKER)}`);
  }
  verifyPackageContent(root, marker);
  return state;
}

function packageContents(packageRoot) {
  if (!packageRoot) return { agents: null, soul: null, skills: [] };
  const context = name => {
    const source = [path.join(packageRoot, "config", name), path.join(packageRoot, name)]
      .find(candidate => fs.existsSync(candidate) && fs.statSync(candidate).isFile());
    return source ? { path: source } : null;
  };
  const skills = [];
  const seen = new Set();
  const walk = current => {
    for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
      const target = path.join(current, entry.name);
      if (!entry.isDirectory()) continue;
      if (fs.existsSync(path.join(target, "SKILL.md"))) {
        if (!/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(entry.name) || seen.has(entry.name)) {
          throw new Error(`invalid or duplicate Agent Package Skill id: ${entry.name}`);
        }
        seen.add(entry.name);
        skills.push({ id: entry.name, path: target });
      } else {
        walk(target);
      }
    }
  };
  walk(packageRoot);
  skills.sort((left, right) => left.id.localeCompare(right.id));
  return { agents: context("AGENTS.md"), soul: context("SOUL.md"), skills };
}

function publishPackageState(args, runtimeState, state, enabled) {
  if (enabled === false) return;
  writeJson(statePath(args), state);
  runtimeState.agentPackage = state;
}

function emptyPackage(args, runtimeState, publishState) {
  const state = {
    status: "ready",
    ref: "",
    objectKey: "",
    agentPackageDigest: EMPTY_AGENT_PACKAGE_DIGEST,
    digest: EMPTY_AGENT_PACKAGE_DIGEST,
    packageRoot: "",
    ...packageContents(""),
    updatedAt: new Date().toISOString()
  };
  publishPackageState(args, runtimeState, state, publishState);
  return state;
}

async function loadAgentPackage(options) {
  const opts = options || {};
  const args = opts.args || {};
  const runtimeState = opts.runtimeState || {};
  throwIfAborted(opts.signal);
  const ref = String(runtimeState.runtime?.desired?.agentPackage?.ref || "").trim();
  if (!ref) return emptyPackage(args, runtimeState, opts.publishState);
  if (!ref.startsWith("oss://")) {
    throw Object.assign(new Error(`unsupported agent package ref: ${ref}`), {
      reason: "UnsupportedAgentPackageRef"
    });
  }

  const previous = runtimeState.agentPackage || readJson(statePath(args), {});
  const cached = cachedPackage(args, previous, ref);
  if (cached) {
    const reused = { ...cached, ...packageContents(cached.packageRoot) };
    throwIfAborted(opts.signal);
    if (opts.publishState !== false) runtimeState.agentPackage = reused;
    return reused;
  }

  const objectKey = ref.replace(/^oss:\/\//, "").replace(/^\/+/, "");
  const fetchPackage = opts.fetchPackage || ossFetch;
  const archive = await fetchPackage("GET", opts.sts, objectKey, { signal: opts.signal });
  throwIfAborted(opts.signal);
  if (!Buffer.isBuffer(archive)) throw new Error("Agent Package download did not return bytes");
  const versionsRoot = path.join(args.stateDir, "agent-package", "versions");
  fs.mkdirSync(versionsRoot, { recursive: true, mode: 0o700 });
  const staging = path.join(versionsRoot, `.staging-${crypto.randomUUID()}`);
  let agentPackageDigest;
  let packageRoot;
  let markerPath;
  try {
    extractZip(archive, staging);
    freezePackageTree(staging);
    agentPackageDigest = computePackageContentDigest(staging);
    packageRoot = path.join(versionsRoot, agentPackageDigest.replace(/^sha256:/, ""));
    markerPath = path.join(packageRoot, PACKAGE_MARKER);
    if (!fs.existsSync(markerPath)) {
      writeJson(path.join(staging, PACKAGE_MARKER), {
        schemaVersion: 1,
        agentPackageDigest,
        contentDigest: agentPackageDigest
      }, 0o400);
      try {
        fs.renameSync(staging, packageRoot);
      } catch (error) {
        if (!fs.existsSync(markerPath)) throw error;
      }
    }
  } finally {
    fs.rmSync(staging, { recursive: true, force: true });
  }

  throwIfAborted(opts.signal);
  const marker = readJson(markerPath, {});
  if (marker.schemaVersion !== 1 || marker.agentPackageDigest !== agentPackageDigest) {
    throw Object.assign(new Error(`Agent Package cache conflict for ${ref}`), {
      reason: "AgentPackageConflict"
    });
  }
  verifyPackageContent(packageRoot, marker);
  const state = {
    status: "ready",
    ref,
    objectKey,
    agentPackageDigest,
    digest: agentPackageDigest,
    packageRoot,
    ...packageContents(packageRoot),
    updatedAt: new Date().toISOString()
  };
  throwIfAborted(opts.signal);
  publishPackageState(args, runtimeState, state, opts.publishState);
  return state;
}

module.exports = {
  EMPTY_AGENT_PACKAGE_DIGEST,
  extractZip,
  hasExpectedMarkerMode,
  loadAgentPackage
};
