#!/usr/bin/env node
"use strict";

const fs = require("node:fs");
const path = require("node:path");

const { loadAgentPackage } = require("./agent-package");
const { loadPluginManifest, resolvePluginResources } = require("./plugin-resources");
const { parsePluginRef, resolvePluginSource } = require("./plugin-store");
const { canonicalJson, preparePluginView, publishPluginCurrent } = require("./plugin-view");
const {
  discardUnpublishedResources,
  publishCurrentView,
  retainCurrentView
} = require("./view-registry");
const { syncAgentPackageViewInBackground } = require("./package-view");
const { resolveRuntimeBindings } = require("./runtime-bindings");
const { logEvent } = require("./log");
const {
  clearPluginResolverState,
  pluginStatePath,
  readJson,
  writeJson,
  writePluginResolverState,
  writePluginState
} = require("./status");

const REDACTED_PLUGIN_REF = "[redacted]";
const MAX_STATE_PLUGIN_REF_LENGTH = 256;
const LAST_SUCCESSFUL_FIELDS = [
  "appliedVersion",
  "viewDigest",
  "materializedPath",
  "agentPackageDigest",
  "runtimeBindingDigest"
];
const instancePreparations = new Map();
const sharedRuntimeHandlePrototype = Object.freeze({});

function abortError() {
  const error = new Error("plugin preparation aborted");
  error.name = "AbortError";
  return error;
}

function throwIfAborted(signal) {
  if (signal?.aborted) throw abortError();
}

function isAbortError(error) {
  return Boolean(error && error.name === "AbortError");
}

function instanceRoot(args) {
  if (args.instanceDir) return path.resolve(args.instanceDir);
  return path.dirname(path.resolve(args.stateDir));
}

function pluginState(args, name, payload) {
  if (payload?.phase === "Ready") return writePluginState(args, name, payload);
  const previous = readJson(pluginStatePath(args, name), {});
  const source = previous.phase === "Ready" ? previous : previous.lastSuccessful;
  const lastSuccessful = source && typeof source === "object"
    ? Object.fromEntries(
      LAST_SUCCESSFUL_FIELDS
        .filter(field => source[field] !== undefined)
        .map(field => [field, source[field]])
    )
    : null;
  return writePluginState(args, name, {
    ...(payload || {}),
    ...(lastSuccessful && Object.keys(lastSuccessful).length
      ? { lastSuccessful }
      : {})
  });
}

function statePluginRef(value) {
  const ref = String(value || "");
  if (!ref) return "";
  if (ref.length > MAX_STATE_PLUGIN_REF_LENGTH) return REDACTED_PLUGIN_REF;
  try {
    parsePluginRef(ref);
    return ref;
  } catch {
    return REDACTED_PLUGIN_REF;
  }
}

function failureMessage(error, pluginRef) {
  if (statePluginRef(pluginRef) === REDACTED_PLUGIN_REF) {
    return error?.reason === "PluginRefInvalid"
      ? "plugin ref must be <name>@<exact-semver>"
      : "plugin resolution failed";
  }
  return String(error?.message || error).slice(0, 500);
}

function failureForCaller(error, pluginRef) {
  if (statePluginRef(pluginRef) !== REDACTED_PLUGIN_REF) return error;
  const safeError = new Error(failureMessage(error, pluginRef));
  if (error?.reason !== undefined) safeError.reason = error.reason;
  if (error?.detail !== undefined) safeError.detail = error.detail;
  return safeError;
}

function statePluginIdentity(source) {
  if (!source?.name || !source?.version) return null;
  return statePluginRef(`${source.name}@${source.version}`) === REDACTED_PLUGIN_REF ? null : source;
}

function stateBase(args, source, resources, adapter) {
  return {
    name: source.name,
    selectionMode: source.selectionMode,
    requestedRef: statePluginRef(args.pluginRef),
    desiredVersion: source.version,
    resolvedVersion: source.version,
    pluginDigest: source.pluginDigest,
    runtime: String(args.runtime || adapter.runtime || ""),
    runtimeRole: resources.runtimeRole,
    pluginRole: resources.pluginRole,
    materializerVersion: adapter.materializerVersion,
    source: source.source,
    fromCache: Boolean(source.fromCache)
  };
}

function cloneJson(value) {
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}

function plainObject(value) {
  if (!value || typeof value !== "object") return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function createSharedRuntimeHandle(properties) {
  return Object.assign(Object.create(sharedRuntimeHandlePrototype), properties || {});
}

function clonePlainData(value, seen) {
  if (!Array.isArray(value) && !plainObject(value)) return value;
  if (seen.has(value)) return seen.get(value);
  const clone = Array.isArray(value) ? [] : Object.create(Object.getPrototypeOf(value));
  seen.set(value, clone);
  const descriptors = Object.getOwnPropertyDescriptors(value);
  for (const key of Reflect.ownKeys(descriptors)) {
    const descriptor = descriptors[key];
    if (Object.prototype.hasOwnProperty.call(descriptor, "value")) {
      descriptor.value = clonePlainData(descriptor.value, seen);
    }
    Object.defineProperty(clone, key, descriptor);
  }
  return clone;
}

function freezePlainData(value, seen) {
  if (!Array.isArray(value) && !plainObject(value)) return value;
  if (seen.has(value)) return value;
  seen.add(value);
  for (const key of Reflect.ownKeys(value)) {
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (descriptor && Object.prototype.hasOwnProperty.call(descriptor, "value")) {
      freezePlainData(descriptor.value, seen);
    }
  }
  return Object.freeze(value);
}

function copyRuntimeState(args, runtimeState, freeze) {
  const sourceArgs = args || {};
  const sourceRuntimeState = runtimeState || {};
  const seen = new WeakMap();
  const snapshotArgs = Object.create(Object.getPrototypeOf(sourceArgs));
  const snapshotRuntimeState = Object.create(Object.getPrototypeOf(sourceRuntimeState));
  seen.set(sourceArgs, snapshotArgs);
  seen.set(sourceRuntimeState, snapshotRuntimeState);

  const copyDescriptors = (source, target) => {
    const descriptors = Object.getOwnPropertyDescriptors(source);
    for (const key of Reflect.ownKeys(descriptors)) {
      const descriptor = descriptors[key];
      if (Object.prototype.hasOwnProperty.call(descriptor, "value")) {
        descriptor.value = clonePlainData(descriptor.value, seen);
      }
      Object.defineProperty(target, key, descriptor);
    }
  };
  copyDescriptors(sourceArgs, snapshotArgs);
  copyDescriptors(sourceRuntimeState, snapshotRuntimeState);
  if (!Object.prototype.hasOwnProperty.call(snapshotRuntimeState, "args")) {
    Object.defineProperty(snapshotRuntimeState, "args", {
      configurable: true,
      enumerable: true,
      value: snapshotArgs,
      writable: true
    });
  }

  const execution = { args: snapshotArgs, runtimeState: snapshotRuntimeState };
  return freeze ? freezePlainData(execution, new WeakSet()) : execution;
}

function createMutableRuntimeCandidate(args, runtimeState) {
  return copyRuntimeState(args, runtimeState, false);
}

function createRuntimeSnapshot(args, runtimeState) {
  return copyRuntimeState(args, runtimeState, true);
}

function prepareInputIdentity(args, runtimeState) {
  return canonicalJson({
    args: {
      pluginDefaultFile: args.pluginDefaultFile,
      instanceDir: args.instanceDir,
      nodeExecutable: args.nodeExecutable,
      pilotDataDir: args.pilotDataDir,
      pluginRef: args.pluginRef,
      runtime: args.runtime,
      stateDir: args.stateDir,
      workDir: args.workDir
    },
    runtime: {
      brokerDescriptorPath: runtimeState.brokerDescriptorPath,
      digest: runtimeState.digest,
      edge: runtimeState.edge || {},
      objectKey: runtimeState.objectKey,
      runtime: runtimeState.runtime || {}
    }
  });
}

function runtimeSnapshot(runtimeState, sts) {
  return {
    agentPackage: cloneJson(runtimeState.agentPackage),
    brokerDescriptorPath: runtimeState.brokerDescriptorPath,
    digest: runtimeState.digest,
    edge: cloneJson(runtimeState.edge || {}),
    loadedAt: runtimeState.loadedAt,
    objectKey: runtimeState.objectKey,
    runtime: cloneJson(runtimeState.runtime || {}),
    sts: runtimeState.sts || sts
  };
}

function discardPreparation(args, prepared, agentPackage) {
  discardUnpublishedResources(args, {
    viewDigest: prepared?.viewDigest,
    viewPath: prepared?.viewPath,
    materializedPluginDir: prepared?.materializedPluginDir,
    agentPackageDigest: agentPackage?.agentPackageDigest || agentPackage?.digest,
    packageRoot: agentPackage?.packageRoot
  });
}

function discardPreparedPluginRuntime(args, runtimeState) {
  const pluginRuntime = runtimeState?.pluginRuntime || {};
  const agentPackage = runtimeState?.agentPackage || pluginRuntime.agentPackage || {};
  if (!pluginRuntime.viewPath && !agentPackage.packageRoot) return;
  discardUnpublishedResources(args, {
    viewDigest: pluginRuntime.viewDigest,
    viewPath: pluginRuntime.viewPath,
    materializedPluginDir: pluginRuntime.materializedPluginDir || args?.pluginDir,
    agentPackageDigest: agentPackage.agentPackageDigest || agentPackage.digest,
    packageRoot: agentPackage.packageRoot
  });
}

async function withInstancePreparation(args, operation) {
  const key = instanceRoot(args);
  const previous = instancePreparations.get(key) || Promise.resolve();
  const current = previous.catch(() => {}).then(operation);
  instancePreparations.set(key, current);
  try {
    return await current;
  } finally {
    if (instancePreparations.get(key) === current) instancePreparations.delete(key);
  }
}

async function preparePluginRuntimeLocked(opts, args, runtimeState, adapter) {
  while (true) {
    throwIfAborted(opts.signal);
    const attemptArgs = { ...args };
    const attemptRuntimeState = runtimeSnapshot(runtimeState, opts.sts);
    const expectedInputIdentity = prepareInputIdentity(attemptArgs, attemptRuntimeState);
    const isCurrent = () => prepareInputIdentity(args, runtimeState) === expectedInputIdentity;
    let source;
    let resources;
    let agentPackage;
    let prepared;
    try {
      source = await resolvePluginSource({
        pilotDataDir: attemptArgs.pilotDataDir,
        pluginDefaultFile: attemptArgs.pluginDefaultFile,
        pluginRef: attemptArgs.pluginRef,
        fetchPackage: opts.fetchPluginPackage,
        signal: opts.signal
      });
      if (source.cacheRecovery) {
        logEvent("warn", "plugin_cache_discarded", {
          runtime: attemptArgs.runtime,
          pluginName: source.name,
          pluginVersion: source.version,
          reason: source.cacheRecovery,
          replacementSource: source.source
        });
      }
      clearPluginResolverState(attemptArgs);
      resources = resolvePluginResources({
        pluginSourceDir: source.sourceDir,
        runtimeRole: attemptRuntimeState.staticRole || attemptRuntimeState.runtime?.member?.role
      });
      const base = stateBase(attemptArgs, source, resources, adapter);
      pluginState(attemptArgs, source.name, {
        ...base,
        phase: "Verifying",
        reason: "PluginVerifying"
      });

      agentPackage = await loadAgentPackage({
        args: attemptArgs,
        runtimeState: attemptRuntimeState,
        sts: attemptRuntimeState.sts,
        fetchPackage: opts.fetchPackage,
        publishState: false,
        signal: opts.signal
      });
      throwIfAborted(opts.signal);
      const manifest = loadPluginManifest(source.sourceDir);
      const root = instanceRoot(attemptArgs);
      const stateDir = path.dirname(pluginStatePath(attemptArgs, source.name));
      fs.mkdirSync(stateDir, { recursive: true, mode: 0o700 });
      const runtimeBindings = resolveRuntimeBindings({
        manifest,
        resolvedResources: resources,
        runtimeServices: {
          credentialBroker: { descriptorPath: attemptRuntimeState.brokerDescriptorPath }
        },
        executables: {
          node: attemptArgs.nodeExecutable
        },
        instanceDirs: {
          instanceRoot: root,
          pluginSourceDir: source.sourceDir,
          effectiveWorkspaceDir: attemptArgs.workDir,
          pluginStateDir: stateDir
        }
      });

      pluginState(attemptArgs, source.name, {
        ...base,
        agentPackageDigest: agentPackage.agentPackageDigest,
        runtimeBindingDigest: runtimeBindings.runtimeBindingDigest,
        phase: "Materializing",
        reason: "PluginMaterializing"
      });

      const instancePluginDir = path.join(root, "plugins", source.name);
      prepared = await preparePluginView({
        instanceRoot: root,
        instancePluginDir,
        runtime: adapter.runtime,
        verifiedSource: source,
        resolvedResources: resources,
        runtimeBindings,
        agentPackage,
        adapter,
        publishCurrent: false
      });

      throwIfAborted(opts.signal);
      if (!isCurrent()) {
        discardPreparation(attemptArgs, prepared, agentPackage);
        continue;
      }
      args.pluginDir = prepared.materializedPluginDir;
      args.pluginRuntimeEnv = runtimeBindings.runtimeEnv;
      args.pluginMcpServers = runtimeBindings.mcpServers;
      const ready = {
        ...base,
        appliedVersion: source.version,
        agentPackageDigest: agentPackage.agentPackageDigest,
        runtimeBindingDigest: runtimeBindings.runtimeBindingDigest,
        viewDigest: prepared.viewDigest,
        materializedPath: path.relative(root, prepared.materializedPluginDir).split(path.sep).join("/"),
        phase: "Ready",
        reason: "PluginReady"
      };
      runtimeState.agentPackage = agentPackage;
      runtimeState.pluginRuntime = {
        ...ready,
        sourceDir: source.sourceDir,
        viewPath: prepared.viewPath,
        materializedPluginDir: prepared.materializedPluginDir,
        resolvedResources: resources,
        runtimeBindings,
        agentPackage
      };
      if (opts.publish !== false) {
        publishPreparedPluginRuntime(args, runtimeState, {
          signal: opts.signal,
          sts: attemptRuntimeState.sts
        });
      }
      return { ...prepared, source, resources, runtimeBindings, agentPackage };
    } catch (error) {
      discardPreparation(attemptArgs, prepared, agentPackage);
      if (opts.signal?.aborted || isAbortError(error)) throw (isAbortError(error) ? error : abortError());
      if (!isCurrent()) continue;
      const failedSource = statePluginIdentity(source || (error.pluginName ? {
        name: error.pluginName,
        version: error.pluginVersion
      } : null));
      if (failedSource?.name) {
        clearPluginResolverState(attemptArgs);
        pluginState(attemptArgs, failedSource.name, {
          ...(resources ? stateBase(attemptArgs, source, resources, adapter) : {
            name: failedSource.name,
            selectionMode: attemptArgs.pluginRef ? "explicit" : "bundle-default",
            requestedRef: statePluginRef(attemptArgs.pluginRef),
            desiredVersion: failedSource.version,
            pluginDigest: failedSource.pluginDigest,
            runtime: String(attemptArgs.runtime || adapter.runtime || "")
          }),
          phase: "Failed",
          reason: error.reason || "PluginMaterializeFailed",
          message: failureMessage(error, attemptArgs.pluginRef)
        });
      } else {
        writePluginResolverState(attemptArgs, {
          selectionMode: attemptArgs.pluginRef ? "explicit" : "bundle-default",
          requestedRef: statePluginRef(attemptArgs.pluginRef),
          runtime: String(attemptArgs.runtime || adapter.runtime || ""),
          phase: "Failed",
          reason: error.reason || "PluginResolveFailed",
          message: failureMessage(error, attemptArgs.pluginRef)
        });
      }
      throw failureForCaller(error, attemptArgs.pluginRef);
    }
  }
}

function publishPreparedPluginRuntime(args, runtimeState, options) {
  const pluginRuntime = runtimeState?.pluginRuntime;
  if (!pluginRuntime?.name || !pluginRuntime?.materializedPluginDir) {
    throw new Error("prepared plugin runtime is required before publication");
  }
  const root = instanceRoot(args);
  const instancePluginDir = path.join(root, "plugins", pluginRuntime.name);
  const current = options?.publishCurrent === false ? null : publishPluginCurrent({
    instancePluginDir,
    name: pluginRuntime.name,
    version: pluginRuntime.appliedVersion || pluginRuntime.resolvedVersion,
    pluginDigest: pluginRuntime.pluginDigest,
    materializerVersion: pluginRuntime.materializerVersion,
    viewDigest: pluginRuntime.viewDigest,
    materializedPath: pluginRuntime.materializedPluginDir
  });
  writeJson(path.join(args.stateDir, "agent-package-state.json"), pluginRuntime.agentPackage);
  pluginState(args, pluginRuntime.name, {
    name: pluginRuntime.name,
    selectionMode: pluginRuntime.selectionMode,
    requestedRef: pluginRuntime.requestedRef,
    desiredVersion: pluginRuntime.desiredVersion,
    resolvedVersion: pluginRuntime.resolvedVersion,
    pluginDigest: pluginRuntime.pluginDigest,
    runtime: pluginRuntime.runtime,
    runtimeRole: pluginRuntime.runtimeRole,
    pluginRole: pluginRuntime.pluginRole,
    materializerVersion: pluginRuntime.materializerVersion,
    source: pluginRuntime.source,
    fromCache: pluginRuntime.fromCache,
    appliedVersion: pluginRuntime.appliedVersion,
    agentPackageDigest: pluginRuntime.agentPackageDigest,
    runtimeBindingDigest: pluginRuntime.runtimeBindingDigest,
    viewDigest: pluginRuntime.viewDigest,
    materializedPath: pluginRuntime.materializedPath,
    phase: "Ready",
    reason: "PluginReady"
  });
  publishCurrentView(args, runtimeState);
  if (pluginRuntime.agentPackage?.packageRoot) {
    const viewLease = retainCurrentView(args);
    try {
      syncAgentPackageViewInBackground(
        args,
        runtimeState,
        pluginRuntime.agentPackage,
        pluginRuntime.agentPackage.packageRoot,
        options?.sts || runtimeState.sts,
        { signal: options?.signal, viewLease }
      );
    } catch (error) {
      viewLease.release();
      throw error;
    }
  }
  return current;
}

async function preparePluginRuntime(options) {
  const opts = options || {};
  const args = opts.args || {};
  const runtimeState = opts.runtimeState || {};
  const adapter = opts.adapter || {};
  if (!args.stateDir) throw new Error("stateDir is required");
  if (!args.workDir) throw new Error("workDir is required");
  if (!adapter.runtime || !adapter.materializerVersion || typeof adapter.materialize !== "function") {
    throw new Error("plugin materializer adapter is invalid");
  }
  throwIfAborted(opts.signal);
  return withInstancePreparation(args, () => preparePluginRuntimeLocked(opts, args, runtimeState, adapter));
}

module.exports = {
  createMutableRuntimeCandidate,
  createRuntimeSnapshot,
  createSharedRuntimeHandle,
  discardPreparedPluginRuntime,
  preparePluginRuntime,
  publishPreparedPluginRuntime
};
