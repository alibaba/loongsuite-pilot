#!/usr/bin/env node
"use strict";

const { decodeBootstrapToken, readBootstrapTokenFile } = require("./bootstrap");
const { exchangeEdgeToken, requestSts, reportHeartbeat } = require("./controller");
const {
  closeRuntimeRefresh,
  loadRuntimeConfig,
  publishRuntimeConfigState
} = require("./runtime-config");
const { logEvent } = require("./log");
const { modelConfigLogFields, publishModelRuntime, stopModelProxy } = require("./model-config");
const { probeRuntimeCommandVersion, resolveRuntimeCommand } = require("./command-resolver");
const { cleanupBrokerState } = require("./broker");
const { stopAgentPackageViewSync } = require("./package-view");
const {
  createSharedRuntimeHandle,
  preparePluginRuntime: prepareCorePluginRuntime
} = require("./plugin-runtime");
const { cleanupLegacySensitiveState, mkdirp, writeStatus } = require("./status");

function commandExists(command) {
  return resolveRuntimeCommand({
    command,
    source: command && (command.includes("/") || command.includes("\\")) ? "arg" : "default",
    searchPaths: [],
    loginShell: false
  }).ok;
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function closeServer(server) {
  return new Promise(resolve => {
    if (!server || typeof server.close !== "function") {
      resolve();
      return;
    }
    const timer = setTimeout(resolve, 1000);
    try {
      server.close(() => {
        clearTimeout(timer);
        resolve();
      });
    } catch {
      clearTimeout(timer);
      resolve();
    }
  });
}

function installSignalShutdown(requestShutdown) {
  let requested = false;
  const handler = signal => {
    if (requested) return;
    requested = true;
    requestShutdown(signal);
  };
  const onSigint = () => handler("SIGINT");
  const onSigterm = () => handler("SIGTERM");
  process.once("SIGINT", onSigint);
  process.once("SIGTERM", onSigterm);
  return () => {
    process.removeListener("SIGINT", onSigint);
    process.removeListener("SIGTERM", onSigterm);
  };
}

function workerOnce(args) {
  return Boolean(args.once || process.env.TEAMHARNESS_WORKER_ONCE === "1");
}

function commandConfig(args, adapter) {
  const config = typeof adapter.commandConfig === "function" ? adapter.commandConfig(args) : {};
  return {
    runtime: args.runtime,
    displayName: config.displayName || args.runtime,
    commandName: config.commandName || "runtimeCommand",
    command: config.command || adapter.command(args),
    source: config.source || args[`${config.commandName || "runtimeCommand"}Source`] || args.runtimeCommandSource || "default",
    searchPaths: config.searchPaths || [],
    wrapperDirsToSkip: config.wrapperDirsToSkip || [],
    versionArgs: config.versionArgs || ["--version"],
    env: config.env || process.env,
    validateVersion: config.validateVersion
  };
}

function runtimeCommandStatus(metadata, extra) {
  return {
    ...(extra || {}),
    runtimeCommand: metadata
  };
}

function commandWaitingReason(result, adapter) {
  if (result.reason === "RuntimeCommandNotFound") return adapter.commandMissingReason;
  return result.reason || "RuntimeCommandInvalid";
}

function commandWaitingMessage(result, args, adapter) {
  return result.reason === "RuntimeCommandNotFound" ? adapter.commandMissingMessage(args) : result.message;
}

function resolveWorkerCommand(args, adapter) {
  const config = commandConfig(args, adapter);
  const resolved = resolveRuntimeCommand(config);
  if (!resolved.ok) {
    return { ok: false, config, result: resolved };
  }

  const version = probeRuntimeCommandVersion(resolved.command, {
    args: config.versionArgs,
    env: config.env
  });
  if (!version.ok) {
    return { ok: false, config, result: version };
  }
  const versionError = typeof config.validateVersion === "function"
    ? config.validateVersion(version.version || "")
    : "";
  if (versionError) {
    return {
      ok: false,
      config,
      result: {
        ok: false,
        reason: "RuntimeCommandInvalid",
        message: String(versionError),
        version: version.version || ""
      }
    };
  }

  args[config.commandName] = resolved.command;
  if (typeof adapter.validateRuntimeEnvironment === "function") {
    const environment = adapter.validateRuntimeEnvironment(args, {
      command: resolved.command,
      commandSource: resolved.source,
      env: config.env
    });
    if (environment && environment.ok === false) {
      return { ok: false, config, result: environment };
    }
    args.runtimePrerequisiteMetadata = environment?.metadata || null;
  }
  args.runtimeCommandMetadata = {
    name: config.commandName,
    requestedCommand: resolved.requestedCommand || config.command,
    command: resolved.command,
    source: resolved.source,
    version: version.version || ""
  };
  return { ok: true, config, result: resolved, version };
}

async function runWorkerMain(argv, adapter) {
  const args = adapter.parseArgs(argv);
  mkdirp(args.stateDir);
  cleanupLegacySensitiveState(args);
  logEvent("info", "worker_starting", {
    runtime: args.runtime,
    stateDir: args.stateDir,
    workDir: args.workDir,
    modelConfigMode: args.modelConfigMode,
    requestedMode: args.modelConfigMode,
    requestedModelConfigMode: args.modelConfigMode,
    inheritLocalSkills: args.inheritLocalSkills === true,
    maxConcurrentTasks: args.maxConcurrentTasks
  });

  let bootstrap;
  try {
    bootstrap = decodeBootstrapToken(readBootstrapTokenFile(args));
  } catch (error) {
    writeStatus(args, "Failed", error.reason || "InvalidBootstrapToken", error.message);
    logEvent("error", "bootstrap_token_invalid", { runtime: args.runtime, error });
    throw error;
  }
  Object.defineProperty(args, "edgeBootstrap", {
    value: bootstrap,
    writable: true,
    configurable: true,
    enumerable: false
  });

  if (!args.workDir) {
    writeStatus(args, "Failed", "MissingWorkDir", "work dir is required; pass --work-dir");
    logEvent("error", "worker_workdir_missing", { runtime: args.runtime });
    throw new Error("work dir is required; pass --work-dir");
  }
  mkdirp(args.workDir);

  let commandMissingLogged = false;
  let commandReady = resolveWorkerCommand(args, adapter);
  while (!commandReady.ok) {
    const reason = commandWaitingReason(commandReady.result, adapter);
    const message = commandWaitingMessage(commandReady.result, args, adapter);
    writeStatus(args, "Waiting", reason, message, runtimeCommandStatus({
      requestedCommand: commandReady.config.command,
      source: commandReady.config.source,
      reason: commandReady.result.reason,
      ...(commandReady.result.version ? { version: commandReady.result.version } : {})
    }));
    if (!commandMissingLogged) {
      commandMissingLogged = true;
      logEvent("warn", "worker_command_missing", {
        runtime: args.runtime,
        command: commandReady.config.command,
        commandSource: commandReady.config.source,
        reason
      });
    }
    if (workerOnce(args)) {
      return;
    }
    await wait(Math.max(1, args.intervalSeconds) * 1000);
    commandReady = resolveWorkerCommand(args, adapter);
  }
  logEvent("info", "runtime_command_resolved", {
    runtime: args.runtime,
    command: args.runtimeCommandMetadata.command,
    commandSource: args.runtimeCommandMetadata.source,
    version: args.runtimeCommandMetadata.version
  });
  if (args.runtimePrerequisiteMetadata) {
    logEvent("info", "runtime_prerequisite_ready", {
      runtime: args.runtime,
      ...args.runtimePrerequisiteMetadata
    });
  }

  const edge = await exchangeEdgeToken(args, bootstrap);
  logEvent("info", "edge_token_exchanged", {
    runtime: args.runtime,
    workerName: edge.workerName,
    workerResourceName: edge.workerResourceName,
    controllerUrl: args.controllerUrl
  });
  const sts = await requestSts(args, edge);
  logEvent("info", "sts_credentials_ready", {
    runtime: args.runtime,
    bucket: sts.oss_bucket,
    endpoint: sts.oss_endpoint
  });
  const runtimeState = await loadRuntimeConfig(args, edge, sts);
  runtimeState.matrixCredentialRevision = Number(runtimeState.matrixCredentialRevision || 0);
  runtimeState.matrixCredentialHandle = createSharedRuntimeHandle({
    current: Object.freeze({
      token: String(runtimeState.runtime?.matrix?.accessToken || ""),
      revision: runtimeState.matrixCredentialRevision
    })
  });
  runtimeState.sts = sts;
  runtimeState.args = args;
  runtimeState.edge = edge;
  const workerShutdownController = new AbortController();
  runtimeState.workerShutdownSignal = workerShutdownController.signal;
  args.runtimeState = runtimeState;
  if (typeof adapter.afterRuntimeLoaded === "function") {
    await adapter.afterRuntimeLoaded(args, edge, runtimeState);
  }
  runtimeState.lastRuntimeRefreshAt = Date.now();
  let broker;
  let removeSignalShutdown = () => {};
  let periodicStopper = null;
  let periodicStopPromise = null;
  const stopPeriodicTasks = () => {
    if (!periodicStopper) return Promise.resolve();
    if (!periodicStopPromise) {
      periodicStopPromise = Promise.resolve().then(() => periodicStopper());
    }
    return periodicStopPromise;
  };
  let cleanupPromise = null;
  const cleanupRuntime = () => {
    if (cleanupPromise) return cleanupPromise;
    cleanupPromise = (async () => {
      await stopPeriodicTasks();
      await closeRuntimeRefresh(runtimeState);
      await stopAgentPackageViewSync(args);
      logEvent("info", "worker_cleanup_started", { runtime: args.runtime });
      if (args.modelProxy?.server) {
        await stopModelProxy(args, "worker-cleanup", modelConfigLogFields(args, edge, runtimeState));
      }
      await closeServer(broker);
      if (typeof adapter.cleanupBrokerFiles === "function") adapter.cleanupBrokerFiles(args, runtimeState);
      cleanupBrokerState(args, runtimeState);
      if (typeof adapter.cleanupGlobalIntegrations === "function") adapter.cleanupGlobalIntegrations(args);
      logEvent("info", "worker_cleanup_finished", { runtime: args.runtime });
    })();
    return cleanupPromise;
  };

  try {
    if (typeof adapter.syncModelRuntime === "function") {
      await adapter.syncModelRuntime(args, edge, runtimeState);
    } else if (typeof adapter.startModelProxy === "function") {
      const modelProxy = await adapter.startModelProxy(args, edge, runtimeState);
      logEvent("info", modelProxy ? "model_proxy_started" : "model_proxy_disabled", {
        ...modelConfigLogFields(args, edge, runtimeState),
        endpoint: modelProxy?.endpoint || ""
      });
    }
    broker = await adapter.startBroker(args, edge, sts, runtimeState);
    if (typeof adapter.preparePluginRuntime === "function") {
      await adapter.preparePluginRuntime(args, runtimeState, runtimeState.sts);
    } else {
      await prepareCorePluginRuntime({
        args,
        runtimeState,
        sts: runtimeState.sts,
        adapter: adapter.pluginMaterializer
      });
    }
    if (typeof adapter.afterBrokerStarted === "function") {
      await adapter.afterBrokerStarted(args, edge, runtimeState);
    }
    if (typeof adapter.applyGlobalIntegrations === "function") {
      adapter.applyGlobalIntegrations(args, edge, runtimeState);
    }
    publishModelRuntime(args);
    publishRuntimeConfigState(args, edge, runtimeState);

    removeSignalShutdown = installSignalShutdown(signal => {
      logEvent("info", "worker_shutdown_requested", {
        runtime: args.runtime,
        signal
      });
      workerShutdownController.abort();
    });
    await reportHeartbeat(args, edge, { signal: workerShutdownController.signal });
    if (workerShutdownController.signal.aborted) return;

    if (workerOnce(args)) return;

    writeStatus(args, "Running", "WorkerReady", adapter.readyMessage, {
      workerName: edge.workerName,
      workerResourceName: edge.workerResourceName,
      runtimeCommand: args.runtimeCommandMetadata
    });
    logEvent("info", "worker_ready", {
      runtime: args.runtime,
      workerName: edge.workerName,
      workerResourceName: edge.workerResourceName,
      matrixHomeserver: edge.matrixHomeserver
    });
    periodicStopper = adapter.startRemotePeriodicTasks(args, edge, runtimeState);
    await adapter.matrixLoop(args, edge, runtimeState);
  } catch (error) {
    if (workerShutdownController.signal.aborted && error?.name === "AbortError") return;
    writeStatus(args, "Failed", error.reason || "WorkerInitializationFailed", error.message);
    throw error;
  } finally {
    await stopPeriodicTasks();
    removeSignalShutdown();
    await cleanupRuntime();
  }
}

module.exports = {
  commandExists,
  wait,
  closeServer,
  installSignalShutdown,
  runWorkerMain
};
