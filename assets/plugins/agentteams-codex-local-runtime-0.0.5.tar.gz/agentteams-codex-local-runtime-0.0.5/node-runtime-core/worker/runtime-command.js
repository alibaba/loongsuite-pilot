#!/usr/bin/env node
"use strict";

const { spawn, spawnSync } = require("child_process");

const WINDOWS_CMD_META = /([()%!^"`<>&|;, *?])/g;

function isWindowsCommandScript(command, platform = process.platform) {
  return platform === "win32" && /\.(cmd|bat)$/i.test(String(command || ""));
}

function escapeWindowsCommand(value) {
  return String(value).replace(WINDOWS_CMD_META, "^$1");
}

function escapeWindowsArgument(value, doubleEscapeMeta = false) {
  let escaped = String(value)
    .replace(/(?=(\\+?)?)\1"/g, "$1$1\\\"")
    .replace(/(?=(\\+?)?)\1$/, "$1$1");
  escaped = `"${escaped}"`.replace(WINDOWS_CMD_META, "^$1");
  if (doubleEscapeMeta) escaped = escaped.replace(WINDOWS_CMD_META, "^$1");
  return escaped;
}

function runtimeCommandInvocation(command, args, options) {
  const opts = options || {};
  const platform = opts.platform || process.platform;
  const env = opts.env || process.env;
  const commandArgs = (args || []).map(value => String(value));
  if (!isWindowsCommandScript(command, platform)) {
    return {
      command,
      args: commandArgs,
      windowsVerbatimArguments: false
    };
  }

  const commandLine = [
    escapeWindowsCommand(command),
    ...commandArgs.map(value => escapeWindowsArgument(value, true))
  ].join(" ");
  return {
    command: String(env.ComSpec || env.COMSPEC || "cmd.exe"),
    args: ["/d", "/s", "/c", `"chcp 65001>nul & ${commandLine}"`],
    windowsVerbatimArguments: true
  };
}

function spawnRuntimeCommand(command, args, options) {
  const opts = options || {};
  const invocation = runtimeCommandInvocation(command, args, opts);
  const childOptions = { ...opts };
  delete childOptions.platform;
  childOptions.windowsHide = childOptions.windowsHide !== false;
  childOptions.windowsVerbatimArguments = invocation.windowsVerbatimArguments;
  return spawn(invocation.command, invocation.args, childOptions);
}

function spawnRuntimeCommandSync(command, args, options) {
  const opts = options || {};
  const invocation = runtimeCommandInvocation(command, args, opts);
  const childOptions = { ...opts };
  delete childOptions.platform;
  childOptions.windowsHide = childOptions.windowsHide !== false;
  childOptions.windowsVerbatimArguments = invocation.windowsVerbatimArguments;
  return spawnSync(invocation.command, invocation.args, childOptions);
}

function terminateRuntimeProcessTree(child, signal = "SIGTERM") {
  if (!child?.pid) return;
  if (process.platform === "win32") {
    spawnSync("taskkill.exe", ["/PID", String(child.pid), "/T", "/F"], {
      windowsHide: true,
      stdio: "ignore"
    });
    return;
  }
  try {
    child.kill(signal);
  } catch {}
}

function bindRuntimeAbortSignal(child, signal) {
  if (!signal) return () => {};
  let forceKillTimer = null;
  const abort = () => {
    terminateRuntimeProcessTree(child);
    if (process.platform !== "win32") {
      forceKillTimer = setTimeout(
        () => terminateRuntimeProcessTree(child, "SIGKILL"),
        2000
      );
      if (typeof forceKillTimer.unref === "function") forceKillTimer.unref();
    }
  };
  const remove = () => {
    signal.removeEventListener("abort", abort);
    child.removeListener("close", remove);
    child.removeListener("error", remove);
    if (forceKillTimer) clearTimeout(forceKillTimer);
  };
  child.once("close", remove);
  child.once("error", remove);
  if (signal.aborted) abort();
  else signal.addEventListener("abort", abort, { once: true });
  return remove;
}

module.exports = {
  bindRuntimeAbortSignal,
  escapeWindowsArgument,
  isWindowsCommandScript,
  runtimeCommandInvocation,
  spawnRuntimeCommand,
  spawnRuntimeCommandSync,
  terminateRuntimeProcessTree
};
