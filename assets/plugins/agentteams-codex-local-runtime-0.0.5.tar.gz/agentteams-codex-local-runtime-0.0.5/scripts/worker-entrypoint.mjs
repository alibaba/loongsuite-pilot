#!/usr/bin/env node
"use strict";

import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";

const bundleDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const manifest = JSON.parse(fs.readFileSync(path.join(bundleDir, "worker.manifest.json"), "utf8"));
const runtime = String(manifest.runtime || "");
const workerDir = `${runtime}-worker`;
const workerCli = path.join(bundleDir, workerDir, "dist", "cli.js");
const pilotDataDir = String(process.env.PILOT_DATA_DIR || "").trim();

if (!pilotDataDir) {
  throw new Error("PILOT_DATA_DIR is required");
}
if (!fs.existsSync(workerCli)) {
  throw new Error(`runtime worker entry is missing: ${workerCli}`);
}

// Pilot preserves Manifest arguments and expands missing instance values to "".
// Normalize those empty values without inventing options absent from the Bundle contract.
const defaults = {
  "--plugin-install-scope": "local",
  "--model-config-mode": runtime === "qodercli" ? "native-config" : "runtime-auto"
};
const input = process.argv.slice(2);
const normalized = [];
for (let index = 0; index < input.length; index += 1) {
  const arg = input[index];
  const fallback = defaults[arg];
  if (!fallback) {
    normalized.push(arg);
    continue;
  }
  const value = input[index + 1];
  if (value && !value.startsWith("--")) {
    normalized.push(arg, value);
    index += 1;
  } else {
    normalized.push(arg, fallback);
    if (value === "") index += 1;
  }
}

normalized.push(
  "--plugin-default-file", path.join(bundleDir, "plugin-default.json"),
  "--node-executable", process.execPath,
  "--pilot-data-dir", pilotDataDir
);
const pluginRef = String(process.env.LOCAL_WORKER_PLUGIN_REF || "").trim();
if (pluginRef) normalized.push("--plugin-ref", pluginRef);

process.argv = [process.execPath, workerCli, ...normalized];
const worker = createRequire(import.meta.url)(workerCli);
if (typeof worker.start !== "function") {
  throw new Error(`runtime worker start function is missing: ${workerCli}`);
}
worker.start();
