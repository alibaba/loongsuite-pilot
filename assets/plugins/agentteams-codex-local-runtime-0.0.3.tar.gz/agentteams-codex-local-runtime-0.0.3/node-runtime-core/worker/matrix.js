#!/usr/bin/env node
"use strict";

const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const { readJson, writeJson, writeStatus } = require("./status");
const { normalizeMaxConcurrentTasks } = require("./args");
const { logEvent } = require("./log");
const {
  teamRoomId,
  personalRoomId,
  matrixRooms
} = require("./runtime-config");
const { modelConfigLogFields } = require("./model-config");

const MATRIX_USER_RE = /@[A-Za-z0-9._=+/\-]+:[A-Za-z0-9.\-]+(?::\d+)?/g;
const ROOM_KIND_CACHE_TTL_MS = 30_000;
const DEFAULT_MATRIX_TURN_TIMEOUT_MS = 15_000;
const DEFAULT_MATRIX_CLEANUP_TIMEOUT_MS = 3_000;
const DEFAULT_MATRIX_CONTROL_ACK_TIMEOUT_MS = 3_000;
const DEFAULT_MATRIX_METADATA_TIMEOUT_MS = 3_000;
const DEFAULT_MATRIX_JOIN_TIMEOUT_MS = 10_000;
const DEFAULT_MATRIX_SYNC_TIMEOUT_MS = 40_000;
const DEFAULT_SHUTDOWN_GRACE_MS = 30_000;

let markdownRenderer;
let markdownRendererLoaded = false;
const roomKindCache = new Map();

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function matrixTimeoutMs(value, fallback) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}

function sessionFingerprint(value) {
  const sessionId = String(value || "");
  if (!sessionId) return "";
  return `sha256:${crypto.createHash("sha256").update(sessionId).digest("hex")}`;
}

function turnMatrixIoOptions(signal, timeoutMs) {
  return {
    signal,
    timeoutMs: matrixTimeoutMs(timeoutMs, DEFAULT_MATRIX_TURN_TIMEOUT_MS)
  };
}

function containsNameMention(body, name) {
  const value = String(name || "").trim();
  if (!value) return false;
  return new RegExp(`(^|[^\\w-])@?${escapeRegExp(value)}($|[^\\w-])`).test(body);
}

function isMatrixThreadEvent(event) {
  const relatesTo = event?.content && typeof event.content === "object" ? event.content["m.relates_to"] : null;
  return Boolean(relatesTo && typeof relatesTo === "object" && relatesTo.rel_type === "m.thread");
}

function isMatrixReplaceEvent(event) {
  const relatesTo = event?.content && typeof event.content === "object" ? event.content["m.relates_to"] : null;
  return Boolean(relatesTo && typeof relatesTo === "object" && relatesTo.rel_type === "m.replace");
}

function matrixReplaceTargetEventId(event) {
  const relatesTo = event?.content && typeof event.content === "object" ? event.content["m.relates_to"] : null;
  if (!relatesTo || typeof relatesTo !== "object" || relatesTo.rel_type !== "m.replace") return "";
  return String(relatesTo.event_id || "").trim();
}

function extractMatrixMentionsFromText(text) {
  return Array.from(new Set(String(text || "").match(MATRIX_USER_RE) || []));
}

function formattedBodyMentionsUser(formattedBody, userId) {
  const body = String(formattedBody || "");
  const value = String(userId || "").trim();
  if (!body || !value) return false;
  const escaped = escapeRegExp(value);
  if (new RegExp(`href=["']https://matrix\\.to/#/${escaped}["']`, "i").test(body)) return true;
  const encoded = escapeRegExp(encodeURIComponent(value));
  return new RegExp(`href=["']https://matrix\\.to/#/${encoded}["']`, "i").test(body);
}

function eventMentionsUser(event, userId) {
  const value = String(userId || "").trim();
  if (!value) return false;
  const content = event && event.content && typeof event.content === "object" ? event.content : {};
  const mentions = content["m.mentions"] && typeof content["m.mentions"] === "object" ? content["m.mentions"] : {};
  const userIds = Array.isArray(mentions.user_ids) ? mentions.user_ids : [];
  if (userIds.some(item => String(item || "") === value)) return true;
  if (mentions.room) return true;
  if (formattedBodyMentionsUser(content.formatted_body, value)) return true;
  return extractMatrixMentionsFromText(eventBody(event)).some(item => item.toLowerCase() === value.toLowerCase());
}

function messagesAfter(messages, lastEventId) {
  if (!lastEventId) return messages;
  const index = messages.findIndex(event => event.event_id === lastEventId);
  return index >= 0 ? messages.slice(index + 1) : messages;
}

function normalizeRooms(value) {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const rooms = {};
    for (const [roomId, room] of Object.entries(value)) {
      rooms[roomId] = {
        history: Array.isArray(room?.history) ? room.history : [],
        pendingTurn: room?.pendingTurn || null,
        runningTurn: room?.runningTurn || null,
        pausedByStop: Boolean(room?.pausedByStop)
      };
    }
    return rooms;
  }
  const rooms = {};
  if (Array.isArray(value)) {
    for (const roomId of value) {
      rooms[String(roomId)] = { history: [], pendingTurn: null, runningTurn: null, pausedByStop: false };
    }
  }
  return rooms;
}

function normalizeMatrixState(raw, args, hadFile) {
  const state = raw && typeof raw === "object" ? raw : {};
  const runtimeSessions = state.runtimeSessions && typeof state.runtimeSessions === "object" ? state.runtimeSessions : {};
  const codeRuntime = ["cla", "ude-code"].join("");
  const codeBucket = ["cla", "udeSessions"].join("");
  const codeSessions = runtimeSessions[codeRuntime] && typeof runtimeSessions[codeRuntime] === "object"
    ? runtimeSessions[codeRuntime]
    : (state[codeBucket] && typeof state[codeBucket] === "object" ? state[codeBucket] : {});
  const openclawSessions = runtimeSessions.openclaw && typeof runtimeSessions.openclaw === "object"
    ? runtimeSessions.openclaw
    : (state.openclawSessions && typeof state.openclawSessions === "object" ? state.openclawSessions : {});
  return {
    version: 2,
    matrixTransportIdentity: String(state.matrixTransportIdentity || ""),
    matrixSyncToken: String(state.matrixSyncToken || state.nextBatch || ""),
    nextBatch: String(state.matrixSyncToken || state.nextBatch || ""),
    seenEventIds: Array.isArray(state.seenEventIds) ? state.seenEventIds.map(String).filter(Boolean) : [],
    matrixCursors: state.matrixCursors && typeof state.matrixCursors === "object" ? state.matrixCursors : {},
    rooms: normalizeRooms(state.rooms),
    scheduler: {
      pendingRoomQueue: Array.isArray(state.scheduler?.pendingRoomQueue)
        ? state.scheduler.pendingRoomQueue.map(String).filter(Boolean)
        : []
    },
    configuredRooms: Array.isArray(state.configuredRooms)
      ? Array.from(new Set(state.configuredRooms.map(String).filter(Boolean)))
      : [],
    retiredRoomIds: Array.isArray(state.retiredRoomIds)
      ? Array.from(new Set(state.retiredRoomIds.map(String).filter(Boolean)))
      : [],
    runtimeSessions: {
      ...runtimeSessions,
      [codeRuntime]: codeSessions,
      openclaw: openclawSessions
    },
    [codeBucket]: codeSessions,
    openclawSessions,
    bootstrapPending: Boolean(state.bootstrapPending) || !hadFile || Object.keys(state).length === 0
  };
}

function loadMatrixState(args) {
  const file = path.join(args.stateDir, "matrix-state.json");
  const hadFile = fs.existsSync(file);
  return normalizeMatrixState(readJson(file, {}), args, hadFile);
}

function writeMatrixState(args, state) {
  const runtimeSessions = state.runtimeSessions && typeof state.runtimeSessions === "object" ? state.runtimeSessions : {};
  const codeRuntime = ["cla", "ude-code"].join("");
  const codeBucket = ["cla", "udeSessions"].join("");
  const codeSessions = runtimeSessions[codeRuntime] && typeof runtimeSessions[codeRuntime] === "object"
    ? runtimeSessions[codeRuntime]
    : (state[codeBucket] && typeof state[codeBucket] === "object" ? state[codeBucket] : {});
  const openclawSessions = runtimeSessions.openclaw && typeof runtimeSessions.openclaw === "object"
    ? runtimeSessions.openclaw
    : (state.openclawSessions && typeof state.openclawSessions === "object" ? state.openclawSessions : {});
  writeJson(path.join(args.stateDir, "matrix-state.json"), {
    version: 2,
    matrixTransportIdentity: String(state.matrixTransportIdentity || ""),
    matrixSyncToken: state.matrixSyncToken || "",
    nextBatch: state.matrixSyncToken || "",
    seenEventIds: Array.isArray(state.seenEventIds) ? state.seenEventIds : [],
    matrixCursors: state.matrixCursors || {},
    rooms: state.rooms && typeof state.rooms === "object" && !Array.isArray(state.rooms) ? state.rooms : {},
    scheduler: state.scheduler && typeof state.scheduler === "object" ? state.scheduler : { pendingRoomQueue: [] },
    configuredRooms: Array.isArray(state.configuredRooms) ? state.configuredRooms : [],
    retiredRoomIds: Array.isArray(state.retiredRoomIds) ? state.retiredRoomIds : [],
    bootstrapPending: Boolean(state.bootstrapPending),
    runtimeSessions: {
      ...runtimeSessions,
      [codeRuntime]: codeSessions,
      openclaw: openclawSessions
    },
    [codeBucket]: codeSessions,
    openclawSessions,
    updatedAt: new Date().toISOString()
  });
}

function matrixAbortError() {
  const error = new Error("Matrix request aborted");
  error.name = "AbortError";
  error.reason = "MatrixRequestAborted";
  return error;
}

function matrixTimeoutError(timeoutMs) {
  const error = new Error(`Matrix request timed out after ${timeoutMs}ms`);
  error.name = "TimeoutError";
  error.reason = "MatrixRequestTimeout";
  error.timeoutMs = timeoutMs;
  return error;
}

async function matrixRequest(method, homeserver, token, requestPath, body, options) {
  const opts = options || {};
  const signal = opts.signal;
  const configuredTimeout = Number(opts.timeoutMs);
  const timeoutMs = Number.isFinite(configuredTimeout) && configuredTimeout > 0 ? configuredTimeout : 0;
  if (signal?.aborted) throw matrixAbortError();
  const url = new URL(requestPath, `${homeserver.replace(/\/+$/, "")}/`);
  const controller = typeof AbortController === "function" ? new AbortController() : null;
  let abortListener = null;
  let timeoutId = null;
  let aborted = false;
  let timedOut = false;
  const gates = [];
  if (signal && typeof signal.addEventListener === "function") {
    gates.push(new Promise((_, reject) => {
      abortListener = () => {
        aborted = true;
        const error = matrixAbortError();
        if (controller) controller.abort(error);
        reject(error);
      };
      signal.addEventListener("abort", abortListener, { once: true });
    }));
  }
  if (timeoutMs > 0) {
    gates.push(new Promise((_, reject) => {
      timeoutId = setTimeout(() => {
        timedOut = true;
        const error = matrixTimeoutError(timeoutMs);
        if (controller) controller.abort(error);
        reject(error);
      }, timeoutMs);
    }));
  }
  const request = (async () => {
    const response = await fetch(url, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
        "Content-Type": "application/json; charset=utf-8"
      },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: controller?.signal
    });
    const text = await response.text();
    if (!response.ok) {
      throw Object.assign(
        new Error(`${method} ${url} failed: ${response.status} ${text}`),
        {
          reason: "MatrixRequestFailed",
          status: response.status,
          responseBody: text
        }
      );
    }
    return text.trim() ? JSON.parse(text) : {};
  })();
  try {
    return await (gates.length ? Promise.race([request, ...gates]) : request);
  } catch (error) {
    if (aborted) throw matrixAbortError();
    if (timedOut) throw matrixTimeoutError(timeoutMs);
    throw error;
  } finally {
    if (timeoutId) clearTimeout(timeoutId);
    if (abortListener && signal && typeof signal.removeEventListener === "function") {
      signal.removeEventListener("abort", abortListener);
    }
  }
}

function matrixCredential(runtimeState) {
  const live = runtimeState?.matrixCredentialHandle?.current;
  if (live && typeof live === "object") {
    return {
      token: String(live.token || ""),
      revision: Number(live.revision || 0)
    };
  }
  return {
    token: String(runtimeState?.runtime?.matrix?.accessToken || ""),
    revision: Number(runtimeState?.matrixCredentialRevision || 0)
  };
}

async function matrixRequestForRuntime(method, edge, runtimeState, requestPath, body, options) {
  const homeserver = matrixHomeserver(edge, runtimeState);
  const first = matrixCredential(runtimeState);
  if (!first.token) throw new Error("runtime.yaml missing matrix.accessToken");
  try {
    return await matrixRequest(method, homeserver, first.token, requestPath, body, options);
  } catch (error) {
    const latest = matrixCredential(runtimeState);
    if (
      error?.status !== 401 ||
      latest.revision === first.revision ||
      !latest.token ||
      latest.token === first.token
    ) {
      throw error;
    }
    return matrixRequest(method, homeserver, latest.token, requestPath, body, options);
  }
}

function matrixHomeserver(edge) {
  return String(edge?.matrixHomeserver || "").trim().replace(/\/+$/, "");
}

function matrixTransportIdentity(edge, runtime) {
  const value = runtime || {};
  const identity = JSON.stringify({
    homeserver: matrixHomeserver(edge),
    matrixUserId: String(value.member?.matrixUserId || "")
  });
  return `sha256:${crypto.createHash("sha256").update(identity).digest("hex")}`;
}

function applyMatrixTransportBoundary(matrixState, edge, runtime) {
  const next = matrixTransportIdentity(edge, runtime);
  const previous = String(matrixState.matrixTransportIdentity || "");
  matrixState.matrixTransportIdentity = next;
  if (!previous || previous === next) return false;
  matrixState.matrixSyncToken = "";
  matrixState.nextBatch = "";
  matrixState.seenEventIds = [];
  matrixState.matrixCursors = {};
  matrixState.rooms = {};
  matrixState.scheduler = { pendingRoomQueue: [] };
  matrixState.configuredRooms = [];
  matrixState.retiredRoomIds = [];
  matrixState.bootstrapPending = true;
  return true;
}

async function optionalMatrixState(edge, runtimeState, roomId, eventType, options) {
  const homeserver = matrixHomeserver(edge, runtimeState);
  if (!matrixCredential(runtimeState).token || !homeserver || !roomId || !eventType) return {};
  try {
    return await matrixRequestForRuntime(
      "GET",
      edge,
      runtimeState,
      `/_matrix/client/v3/rooms/${encodeURIComponent(roomId)}/state/${encodeURIComponent(eventType)}/`,
      undefined,
      { timeoutMs: matrixTimeoutMs(options?.timeoutMs, DEFAULT_MATRIX_METADATA_TIMEOUT_MS) }
    );
  } catch (_error) {
    return {};
  }
}

function matrixRoomStateText(content) {
  if (!content || typeof content !== "object") return "";
  return String(content.name || content.topic || content.displayname || content.display_name || "").trim();
}

function hasTaskRoomMarker(value) {
  const text = String(value || "").trim();
  return Boolean(text.startsWith("TASK：") || text.startsWith("TASK:") || text.includes("Task room for "));
}

function isTaskRoomState(roomMeta, roomName, roomTopic) {
  const roomKind = String(roomMeta?.roomKind || roomMeta?.room_kind || "").trim().toLowerCase();
  if (roomKind === "task_room" || roomKind === "task-room" || roomKind === "task" || roomKind === "agentteams-app-task") return true;
  return hasTaskRoomMarker(matrixRoomStateText(roomName)) || hasTaskRoomMarker(matrixRoomStateText(roomTopic));
}

function roomKindInfo(kind, source) {
  const normalized = String(kind || "unknown").trim() || "unknown";
  return {
    kind: normalized,
    source: String(source || ""),
    isDm: normalized === "dm",
    isGroup: !["personal", "dm"].includes(normalized)
  };
}

function cachedRoomKindInfo(cacheKey) {
  const cached = roomKindCache.get(cacheKey);
  if (!cached || (Date.now() - Number(cached.cachedAt || 0)) > ROOM_KIND_CACHE_TTL_MS) {
    roomKindCache.delete(cacheKey);
    return null;
  }
  return cached.info;
}

function storeRoomKindInfo(cacheKey, info) {
  roomKindCache.set(cacheKey, { info, cachedAt: Date.now() });
  return info;
}

async function joinedRoomMembers(edge, runtimeState, roomId, options) {
  const homeserver = matrixHomeserver(edge, runtimeState);
  if (!matrixCredential(runtimeState).token || !homeserver || !roomId) return [];
  const data = await matrixRequestForRuntime(
    "GET",
    edge,
    runtimeState,
    `/_matrix/client/v3/rooms/${encodeURIComponent(roomId)}/joined_members`,
    undefined,
    { timeoutMs: matrixTimeoutMs(options?.timeoutMs, DEFAULT_MATRIX_METADATA_TIMEOUT_MS) }
  );
  if (data && data.joined && typeof data.joined === "object" && !Array.isArray(data.joined)) {
    return Object.keys(data.joined);
  }
  if (Array.isArray(data?.members)) return data.members.map(item => String(item?.user_id || item || "")).filter(Boolean);
  return [];
}

async function classifyMatrixRoom(edge, runtimeState, roomId, event, options) {
  const runtime = runtimeState?.runtime || {};
  const member = runtime.member || {};
  if (personalRoomId(runtime) && roomId === personalRoomId(runtime)) return roomKindInfo("personal", "runtime.personalRoomId");
  if (teamRoomId(runtime) && roomId === teamRoomId(runtime)) return roomKindInfo("team", "runtime.teamRoomId");

  const cacheKey = [
    String(edge?.matrixHomeserver || ""),
    String(member.matrixUserId || ""),
    String(roomId || "")
  ].join("|");
  const cached = cachedRoomKindInfo(cacheKey);
  if (cached) return cached;

  const [roomMeta, roomName, roomTopic] = await Promise.all([
    optionalMatrixState(edge, runtimeState, roomId, "room.meta", options),
    optionalMatrixState(edge, runtimeState, roomId, "m.room.name", options),
    optionalMatrixState(edge, runtimeState, roomId, "m.room.topic", options)
  ]);
  if (isTaskRoomState(roomMeta, roomName, roomTopic)) {
    return storeRoomKindInfo(cacheKey, roomKindInfo("task", "matrix.state"));
  }

  try {
    const members = await joinedRoomMembers(edge, runtimeState, roomId, options);
    const selfId = String(member.matrixUserId || "");
    const sender = String(event?.sender || "");
    if (members.length === 2 && members.includes(selfId) && members.includes(sender)) {
      return storeRoomKindInfo(cacheKey, roomKindInfo("dm", "matrix.joined_members"));
    }
    return storeRoomKindInfo(cacheKey, roomKindInfo("group", "matrix.joined_members"));
  } catch (_error) {
    return storeRoomKindInfo(cacheKey, roomKindInfo("unknown", "matrix.joined_members_error"));
  }
}

function txnId(prefix) {
  return `${prefix}-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`;
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function renderInlineMarkdown(value) {
  return escapeHtml(value)
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
}

function splitMarkdownTableRow(line) {
  let text = String(line || "").trim();
  if (!text.includes("|")) return [];
  if (text.startsWith("|")) text = text.slice(1);
  if (text.endsWith("|")) text = text.slice(0, -1);
  return text.split("|").map(cell => cell.trim());
}

function isMarkdownTableSeparator(line) {
  const cells = splitMarkdownTableRow(line);
  return cells.length > 0 && cells.every(cell => /^:?-{3,}:?$/.test(cell));
}

function renderMarkdownTable(headerLine, separatorLine, bodyLines) {
  const headers = splitMarkdownTableRow(headerLine);
  const separator = splitMarkdownTableRow(separatorLine);
  const width = Math.max(headers.length, separator.length);
  const headerHtml = [];
  for (let index = 0; index < width; index += 1) {
    headerHtml.push(`<th>${renderInlineMarkdown(headers[index] || "")}</th>`);
  }
  const rows = [];
  for (const line of bodyLines) {
    const cells = splitMarkdownTableRow(line);
    const cellHtml = [];
    for (let index = 0; index < width; index += 1) {
      cellHtml.push(`<td>${renderInlineMarkdown(cells[index] || "")}</td>`);
    }
    rows.push(`<tr>${cellHtml.join("")}</tr>`);
  }
  const tbody = rows.length ? `<tbody>${rows.join("")}</tbody>` : "";
  return `<table><thead><tr>${headerHtml.join("")}</tr></thead>${tbody}</table>`;
}

function loadMarkdownRenderer() {
  if (markdownRendererLoaded) return markdownRenderer;
  markdownRendererLoaded = true;
  try {
    const MarkdownIt = require("markdown-it");
    const renderer = new MarkdownIt({
      html: false,
      linkify: true,
      breaks: true,
      typographer: false
    });
    renderer.enable("table");
    renderer.enable("strikethrough");
    markdownRenderer = renderer;
  } catch (_error) {
    markdownRenderer = null;
  }
  return markdownRenderer;
}

function fallbackMatrixFormattedBody(text) {
  const lines = String(text || "").split(/\r?\n/);
  const html = [];
  let inCode = false;
  let codeLines = [];
  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    if (line.trim().startsWith("```")) {
      if (inCode) {
        html.push(`<pre><code>${escapeHtml(codeLines.join("\n"))}</code></pre>`);
        codeLines = [];
        inCode = false;
      } else {
        inCode = true;
      }
      continue;
    }
    if (inCode) {
      codeLines.push(line);
      continue;
    }
    if (splitMarkdownTableRow(line).length > 0 && i + 1 < lines.length && isMarkdownTableSeparator(lines[i + 1])) {
      const bodyLines = [];
      let j = i + 2;
      for (; j < lines.length; j += 1) {
        if (!lines[j].trim() || !lines[j].includes("|")) break;
        bodyLines.push(lines[j]);
      }
      html.push(renderMarkdownTable(line, lines[i + 1], bodyLines));
      i = j - 1;
      continue;
    }
    if (!line.trim()) {
      html.push("<br />");
    } else if (/^\s*[-*]\s+/.test(line)) {
      html.push(`${renderInlineMarkdown(line.replace(/^\s*[-*]\s+/, "• "))}<br />`);
    } else {
      html.push(`${renderInlineMarkdown(line)}<br />`);
    }
  }
  if (inCode) {
    html.push(`<pre><code>${escapeHtml(codeLines.join("\n"))}</code></pre>`);
  }
  return html.join("\n").replace(/(<br \/>\n?)+$/, "");
}

function matrixFormattedBody(text) {
  const renderer = loadMarkdownRenderer();
  if (renderer) {
    return renderer.render(String(text || "")).replace(/\n$/, "");
  }
  return fallbackMatrixFormattedBody(text);
}

function matrixEditFallbackHtml(text) {
  return `<p>* ${escapeHtml(text).replace(/\r?\n/g, "<br>\n")}</p>`;
}

function linkMatrixMentions(htmlBody, mentions) {
  let html = String(htmlBody || "");
  for (const mxid of mentions) {
    const encoded = encodeURIComponent(mxid);
    const display = escapeHtml(mxid.split(":")[0].replace(/^@/, "") || mxid);
    const anchor = `<a href="https://matrix.to/#/${encoded}">${display}</a>`;
    const escapedMxid = escapeHtml(mxid);
    if (html.includes(escapedMxid)) html = html.replace(escapedMxid, anchor);
    else if (!html.includes(anchor)) html = `${anchor} ${html}`.trim();
  }
  return html;
}

function applyMatrixMentions(content, text, runtimeState) {
  const selfId = String(runtimeState?.runtime?.member?.matrixUserId || "");
  const mentions = extractMatrixMentionsFromText(text).filter(mxid => mxid && mxid !== selfId);
  if (!mentions.length) return;
  content["m.mentions"] = { user_ids: mentions };
  if (content.formatted_body) {
    content.format = "org.matrix.custom.html";
    content.formatted_body = linkMatrixMentions(content.formatted_body, mentions);
  }
}

async function matrixSendMessage(edge, runtimeState, roomId, body, options) {
  const runtime = runtimeState.runtime || {};
  if (!runtime.matrix?.accessToken) {
    throw new Error("runtime.yaml missing matrix.accessToken");
  }
  const msgtype = options && options.msgtype ? options.msgtype : "m.text";
  const content = { msgtype, body };
  if (options && options.formatted !== false && (msgtype === "m.text" || msgtype === "m.notice")) {
    content.format = "org.matrix.custom.html";
    content.formatted_body = options.formattedBody || matrixFormattedBody(body);
  }
  applyMatrixMentions(content, body, runtimeState);
  if (options && options.threadRootEventId) {
    content["m.relates_to"] = {
      rel_type: "m.thread",
      event_id: options.threadRootEventId,
      is_falling_back: false
    };
  }
  if (options && options.replaceEventId) {
    content.body = `* ${body}`;
    const newContent = { msgtype, body };
    if (options.formatted !== false && (msgtype === "m.text" || msgtype === "m.notice")) {
      newContent.format = "org.matrix.custom.html";
      newContent.formatted_body = options.formattedBody || matrixFormattedBody(body);
      content.format = "org.matrix.custom.html";
      content.formatted_body = matrixEditFallbackHtml(body);
    }
    applyMatrixMentions(newContent, body, runtimeState);
    applyMatrixMentions(content, body, runtimeState);
    content["m.new_content"] = newContent;
    content["m.relates_to"] = {
      rel_type: "m.replace",
      event_id: options.replaceEventId
    };
  }
  const roomPath = encodeURIComponent(roomId);
  const eventType = encodeURIComponent("m.room.message");
  const transactionId = String(options?.transactionId || txnId("m"));
  return matrixRequestForRuntime(
    "PUT",
    edge,
    runtimeState,
    `/_matrix/client/v3/rooms/${roomPath}/send/${eventType}/${encodeURIComponent(transactionId)}`,
    content,
    {
      signal: options?.signal,
      timeoutMs: options?.timeoutMs
    }
  );
}

async function matrixRedactMessage(edge, runtimeState, roomId, eventId, reason) {
  const runtime = runtimeState.runtime || {};
  if (!runtime.matrix?.accessToken || !eventId) return {};
  const body = reason ? { reason } : {};
  return matrixRequestForRuntime(
    "PUT",
    edge,
    runtimeState,
    `/_matrix/client/v3/rooms/${encodeURIComponent(roomId)}/redact/${encodeURIComponent(eventId)}/${txnId("redact")}`,
    body
  );
}

async function matrixJoin(edge, runtimeState, roomId, options) {
  if (!runtimeState.runtime?.matrix?.accessToken) {
    return;
  }
  await matrixRequestForRuntime(
    "POST",
    edge,
    runtimeState,
    `/_matrix/client/v3/rooms/${encodeURIComponent(roomId)}/join`,
    {},
    { timeoutMs: matrixTimeoutMs(options?.timeoutMs, DEFAULT_MATRIX_JOIN_TIMEOUT_MS) }
  );
}

async function matrixTyping(edge, runtimeState, roomId, typing, options) {
  const userId = runtimeState.runtime?.member?.matrixUserId;
  if (!runtimeState.runtime?.matrix?.accessToken || !userId) {
    return;
  }
  await matrixRequestForRuntime(
    "PUT",
    edge,
    runtimeState,
    `/_matrix/client/v3/rooms/${encodeURIComponent(roomId)}/typing/${encodeURIComponent(userId)}`,
    { typing: Boolean(typing), timeout: typing ? 30000 : 0 },
    {
      signal: options?.signal,
      timeoutMs: options?.timeoutMs
    }
  );
}

function eventBody(event) {
  const content = event && event.content && typeof event.content === "object" ? event.content : {};
  const replacement = content["m.new_content"] && typeof content["m.new_content"] === "object" ? content["m.new_content"] : null;
  return String((replacement && replacement.body) || content.body || "");
}

function roomKindAllowsDirectHandling(kind) {
  return ["personal", "dm"].includes(String(kind || ""));
}

function roomKindCollectsHistory(kind) {
  return !roomKindAllowsDirectHandling(kind);
}

function fallbackRoomKindForRoom(roomId, runtimeState) {
  const runtime = runtimeState?.runtime || {};
  const personal = personalRoomId(runtime);
  if (personal && roomId === personal) return roomKindInfo("personal", "runtime.personalRoomId");
  return roomKindInfo("group", "fallback");
}

function shouldHandleEventForRoomKind(event, roomKind, runtimeState) {
  if (!event || event.type !== "m.room.message") return false;
  if (isMatrixThreadEvent(event)) return false;
  const runtime = runtimeState?.runtime || {};
  const member = runtime.member || {};
  const sender = String(event.sender || "");
  if (sender && sender === String(member.matrixUserId || "")) return false;
  const body = eventBody(event);
  if (!body.trim()) return false;
  if (roomKindAllowsDirectHandling(roomKind?.kind)) return true;
  return eventMentionsUser(event, member.matrixUserId);
}

function shouldHandleEvent(event, roomId, edge, runtimeState) {
  return shouldHandleEventForRoomKind(event, fallbackRoomKindForRoom(roomId, runtimeState), runtimeState);
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function matrixSyncRetryDelayMs(args, failures) {
  const base = Number(args.matrixReconnectBaseMs);
  const max = Number(args.matrixReconnectMaxMs);
  const baseMs = Number.isFinite(base) && base >= 0 ? base : 1000;
  const maxMs = Number.isFinite(max) && max >= 0 ? max : 30000;
  return Math.min(maxMs, baseMs * (2 ** Math.min(Math.max(failures - 1, 0), 5)));
}

function isNoReplyText(text) {
  return String(text ?? "").trim() === "NO_REPLY";
}

function controlMentionNames(edge, runtimeState) {
  const runtime = runtimeState?.runtime || {};
  const member = runtime.member || {};
  const values = [
    member.name,
    member.runtimeName,
    member.matrixUserId,
    String(member.matrixUserId || "").split(":")[0],
    String(member.matrixUserId || "").split(":")[0].replace(/^@/, ""),
    edge?.workerName,
    edge?.runtimeName
  ];
  return Array.from(new Set(values.map(value => String(value || "").trim()).filter(Boolean)));
}

function stripCurrentWorkerMentionText(body, edge, runtimeState) {
  let text = String(body || "");
  const names = controlMentionNames(edge, runtimeState).sort((a, b) => b.length - a.length);
  for (const name of names) {
    const variants = (name.startsWith("@") ? [name, name.slice(1)] : [name, `@${name}`]).sort((a, b) => b.length - a.length);
    for (const variant of variants) {
      if (!variant) continue;
      text = text.replace(new RegExp(`(^|\\s)${escapeRegExp(variant)}(?=$|\\s|[,:;，：])`, "g"), " ");
    }
  }
  return text.replace(/[,:;，：]/g, " ").replace(/\s+/g, " ").trim();
}

function matrixControlCommand(event, roomId, edge, runtimeState, roomKind) {
  const body = eventBody(event).trim();
  if (!roomId || !runtimeState) {
    if (body === "/stop" || body === "/clear") return body;
    return "";
  }
  const runtime = runtimeState.runtime || {};
  const effectiveRoomKind = roomKind || fallbackRoomKindForRoom(roomId, runtimeState);
  if (roomKindAllowsDirectHandling(effectiveRoomKind.kind)) {
    if (body === "/stop" || body === "/clear") return body;
    return "";
  }
  if (eventMentionsUser(event, runtime.member?.matrixUserId)) {
    const stripped = stripCurrentWorkerMentionText(body, edge, runtimeState);
    if (stripped === "/stop" || stripped === "/clear") return stripped;
  }
  return "";
}

function createTaskAbortController() {
  if (typeof AbortController === "function") return new AbortController();
  const signal = {
    aborted: false,
    addEventListener: () => {},
    removeEventListener: () => {}
  };
  return {
    signal,
    abort: () => {
      signal.aborted = true;
    }
  };
}

function sessionsFor(opts, matrixState) {
  return typeof opts.sessionStore === "function" ? opts.sessionStore(matrixState) : {};
}

function sessionForRoom(opts, sessions, roomId, args, runtimeState, edge) {
  return typeof opts.sessionForRoom === "function" ? opts.sessionForRoom(sessions, roomId, args, runtimeState, edge) : sessions[roomId] || "";
}

function storeSessionForRoom(opts, sessions, roomId, args, sessionId, runtimeState, edge) {
  if (typeof opts.storeSessionForRoom === "function") {
    opts.storeSessionForRoom(sessions, roomId, args, sessionId, runtimeState, edge);
  } else if (sessionId) {
    sessions[roomId] = sessionId;
  }
}

function dropSessionForRoom(opts, sessions, roomId, args, runtimeState, edge) {
  if (typeof opts.dropSessionForRoom === "function") {
    opts.dropSessionForRoom(sessions, roomId, args, runtimeState, edge);
  } else {
    delete sessions[roomId];
  }
}

function ensureRoomState(matrixState, roomId) {
  matrixState.rooms = matrixState.rooms && typeof matrixState.rooms === "object" && !Array.isArray(matrixState.rooms) ? matrixState.rooms : {};
  if (!matrixState.rooms[roomId]) {
    matrixState.rooms[roomId] = { history: [], pendingTurn: null, runningTurn: null, pausedByStop: false };
  }
  const room = matrixState.rooms[roomId];
  room.history = Array.isArray(room.history) ? room.history : [];
  room.pendingTurn = room.pendingTurn || null;
  room.runningTurn = room.runningTurn || null;
  room.pausedByStop = Boolean(room.pausedByStop);
  return room;
}

function enqueuePendingRoom(matrixState, roomId) {
  matrixState.scheduler = matrixState.scheduler && typeof matrixState.scheduler === "object" ? matrixState.scheduler : {};
  const queue = Array.isArray(matrixState.scheduler.pendingRoomQueue) ? matrixState.scheduler.pendingRoomQueue : [];
  if (!queue.includes(roomId)) queue.push(roomId);
  matrixState.scheduler.pendingRoomQueue = queue;
}

function trimSeenEventIds(matrixState, protectedIds) {
  const protectedSet = new Set((protectedIds || []).map(String).filter(Boolean));
  const seen = Array.isArray(matrixState.seenEventIds) ? matrixState.seenEventIds : [];
  const keep = [];
  for (let index = seen.length - 1; index >= 0; index -= 1) {
    const eventId = String(seen[index] || "");
    if (!eventId) continue;
    if (protectedSet.has(eventId) || keep.length < 200) keep.unshift(eventId);
  }
  matrixState.seenEventIds = Array.from(new Set(keep));
}

function addSeenEventId(matrixState, eventId, protectedIds) {
  const value = String(eventId || "");
  if (!value) return;
  const seen = Array.isArray(matrixState.seenEventIds) ? matrixState.seenEventIds : [];
  if (!seen.includes(value)) seen.push(value);
  matrixState.seenEventIds = seen;
  trimSeenEventIds(matrixState, protectedIds);
}

function turnId(prefix) {
  return `${prefix}-${Date.now().toString(36)}-${crypto.randomBytes(4).toString("hex")}`;
}

function messageFromEvent(event) {
  return {
    eventId: String(event?.event_id || ""),
    event_id: String(event?.event_id || ""),
    replacesEventId: matrixReplaceTargetEventId(event),
    sender: String(event?.sender || ""),
    body: eventBody(event),
    type: event?.type || "m.room.message",
    content: event?.content && typeof event.content === "object" ? event.content : { body: eventBody(event) },
    originServerTs: event?.origin_server_ts || event?.originServerTs || 0
  };
}

function appendRoomHistory(room, event) {
  const body = eventBody(event);
  const eventId = String(event?.event_id || "");
  const targetEventId = matrixReplaceTargetEventId(event);
  if (targetEventId) {
    const existing = room.history.find(item => item && (item.eventId === targetEventId || item.replacesEventId === targetEventId));
    if (existing) {
      existing.sender = event.sender || existing.sender || "";
      existing.body = body;
      existing.replacedByEventId = eventId;
      return;
    }
  }
  room.history.push({ sender: event.sender || "", body, eventId: targetEventId || eventId, replacesEventId: targetEventId || undefined });
  room.history = room.history.slice(-50);
}

function eventFromMessage(message) {
  const eventId = String(message?.eventId || message?.event_id || "");
  return {
    type: message?.type || "m.room.message",
    event_id: eventId,
    sender: String(message?.sender || ""),
    origin_server_ts: message?.originServerTs || message?.origin_server_ts || 0,
    content: message?.content && typeof message.content === "object" ? message.content : { body: String(message?.body || "") }
  };
}

function appendPendingMessage(matrixState, roomId, event, roomKind) {
  const room = ensureRoomState(matrixState, roomId);
  const message = messageFromEvent(event);
  const now = new Date().toISOString();
  if (!room.pendingTurn) {
    room.pendingTurn = {
      turnId: turnId("turn"),
      eventIds: [],
      messages: [],
      history: room.history.slice(-50),
      roomKind: roomKind?.kind || "",
      isDm: Boolean(roomKind?.isDm),
      isGroup: Boolean(roomKind?.isGroup),
      createdAt: now,
      updatedAt: now
    };
    room.history = [];
  }
  if (!room.pendingTurn.roomKind && roomKind?.kind) {
    room.pendingTurn.roomKind = roomKind.kind;
    room.pendingTurn.isDm = Boolean(roomKind.isDm);
    room.pendingTurn.isGroup = Boolean(roomKind.isGroup);
  }
  if (message.eventId && !room.pendingTurn.eventIds.includes(message.eventId)) {
    room.pendingTurn.eventIds.push(message.eventId);
  }
  room.pendingTurn.messages.push(message);
  room.pendingTurn.updatedAt = now;
  room.pausedByStop = false;
  enqueuePendingRoom(matrixState, roomId);
}

function mergePendingTurns(restored, pending) {
  if (!pending) return restored;
  return {
    ...restored,
    eventIds: [...(restored.eventIds || []), ...(pending.eventIds || [])],
    messages: [...(restored.messages || []), ...(pending.messages || [])],
    history: [...(restored.history || []), ...(pending.history || [])].slice(-50),
    roomKind: restored.roomKind || pending.roomKind || "",
    isDm: restored.isDm !== undefined ? restored.isDm : pending.isDm,
    isGroup: restored.isGroup !== undefined ? restored.isGroup : pending.isGroup,
    updatedAt: new Date().toISOString()
  };
}

function countRunningRooms(matrixState) {
  const rooms = matrixState.rooms && typeof matrixState.rooms === "object" ? matrixState.rooms : {};
  return Object.values(rooms).filter(room =>
    room?.runningTurn && String(room.runningTurn.status || "") !== "finishing"
  ).length;
}

function resolveMaxConcurrentTasks(args, runtimeState) {
  const desired = runtimeState?.runtime?.desired?.scheduler?.maxConcurrentTasks;
  if (args.maxConcurrentTasks !== undefined && args.maxConcurrentTasks !== null) {
    return normalizeMaxConcurrentTasks(args.maxConcurrentTasks, 2);
  }
  return normalizeMaxConcurrentTasks(desired, 2);
}

function normalizeRunResult(result) {
  if (result && typeof result === "object" && !Array.isArray(result)) {
    return result;
  }
  return { sessionId: result || "" };
}

function persistedTurnCompletion(result, error) {
  const normalized = normalizeRunResult(result || {});
  const finalError = error && error.name !== "AbortError" ? error : null;
  const hasText = Object.prototype.hasOwnProperty.call(normalized, "text") ||
    Object.prototype.hasOwnProperty.call(normalized, "replyText");
  return {
    error: finalError ? {
      message: String(finalError.message || finalError),
      name: String(finalError.name || "Error"),
      reason: String(finalError.reason || "")
    } : null,
    reply: {
      hasText,
      text: hasText ? String(normalized.text ?? normalized.replyText ?? "") : "",
      msgtype: String(normalized.msgtype || (normalized.notice ? "m.notice" : "m.text")),
      formatted: normalized.formatted !== false
    },
    session: {
      nextSessionId: String(normalized.sessionId || normalized.nextSessionId || ""),
      dropSession: Boolean(normalized.dropSession)
    }
  };
}

function runResultFromCompletion(completion) {
  const value = completion && typeof completion === "object" ? completion : {};
  const reply = value.reply && typeof value.reply === "object" ? value.reply : {};
  const session = value.session && typeof value.session === "object" ? value.session : {};
  const result = {};
  if (reply.hasText) result.text = String(reply.text || "");
  if (reply.msgtype) result.msgtype = String(reply.msgtype);
  if (reply.formatted === false) result.formatted = false;
  if (session.nextSessionId) result.sessionId = String(session.nextSessionId);
  if (session.dropSession) result.dropSession = true;
  return result;
}

function errorFromCompletion(completion) {
  const stored = completion?.error;
  if (!stored || typeof stored !== "object") return null;
  const error = new Error(String(stored.message || "Runtime execution failed"));
  error.name = String(stored.name || "Error");
  if (stored.reason) error.reason = String(stored.reason);
  return error;
}

function turnCompletionTransactionId(roomId, turnId) {
  const identity = `${String(roomId || "")}\0${String(turnId || "")}`;
  return `turn-final-${crypto.createHash("sha256").update(identity).digest("hex")}`;
}

function createStateMutationQueue(args, matrixState) {
  let chain = Promise.resolve();
  return function withStateMutation(fn) {
    const run = chain.then(async () => {
      const result = await fn(matrixState);
      writeMatrixState(args, matrixState);
      return result;
    });
    chain = run.catch(() => {});
    return run;
  };
}

async function runTurnAdapter(opts, args, edge, runtimeState, turn, execution) {
  const executionArgs = execution?.args || args;
  const executionRuntimeState = execution?.runtimeState || runtimeState;
  if (typeof opts.runForTurn === "function") {
    return normalizeRunResult(await opts.runForTurn(executionArgs, edge, executionRuntimeState, turn));
  }
  const messages = Array.isArray(turn.messages) ? turn.messages : [];
  const event = turn.event || eventFromMessage(messages[messages.length - 1] || {});
  return normalizeRunResult(await opts.runForEvent(executionArgs, edge, executionRuntimeState, turn.roomId, event, turn.history || [], turn.sessionId || "", {
    placeholderEventId: turn.placeholderEventId || "",
    abortSignal: turn.abortSignal,
    turn
  }));
}

function recoverRoomState(matrixState, roomId, room, opts, args, runtimeState, edge) {
  const running = room.runningTurn;
  if (!running) {
    if (room.pendingTurn && !room.pausedByStop) enqueuePendingRoom(matrixState, roomId);
    return;
  }
  const status = String(running.status || "");
  if (status === "finishing" && running.completion && typeof running.completion === "object") {
    return { status: "finishing", turnId: String(running.turnId || "") };
  }
  if (["starting", "running", "finishing"].includes(status)) {
    const restored = {
      turnId: running.turnId || turnId("turn"),
      eventIds: Array.isArray(running.eventIds) ? running.eventIds : [],
      messages: Array.isArray(running.messages) ? running.messages : [],
      history: Array.isArray(running.history) ? running.history : [],
      sessionId: running.sessionId || "",
      placeholderEventId: running.placeholderEventId || "",
      roomKind: running.roomKind || "",
      isDm: running.isDm,
      isGroup: running.isGroup,
      attempt: Number(running.attempt || 0) + 1,
      createdAt: running.createdAt || running.startedAt || new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    room.pendingTurn = mergePendingTurns(restored, room.pendingTurn);
    room.runningTurn = null;
    if (!room.pausedByStop) enqueuePendingRoom(matrixState, roomId);
    return null;
  }
  if (status === "stopping") {
    room.runningTurn = null;
    room.pausedByStop = true;
    return;
  }
  if (status === "resetting") {
    const sessions = sessionsFor(opts, matrixState);
    dropSessionForRoom(opts, sessions, roomId, args, runtimeState, edge);
    room.runningTurn = null;
    room.pendingTurn = null;
    room.history = [];
    room.pausedByStop = false;
  }
  return null;
}

async function runMatrixLoop(args, edge, runtimeState, options) {
  const opts = options || {};
  const initialRuntime = runtimeState.runtime || {};
  if (!initialRuntime.matrix?.accessToken) {
    writeStatus(args, "Degraded", "MatrixAccessTokenMissing", "runtime.yaml missing matrix.accessToken");
    logEvent("warn", "matrix_access_token_missing", { runtime: args.runtime });
    return;
  }
  const stableExecution = { args, runtimeState };
  const matrixState = runtimeState.matrixState || loadMatrixState(args);
  const transportReset = applyMatrixTransportBoundary(matrixState, edge, initialRuntime);
  runtimeState.matrixState = matrixState;
  const withStateMutation = createStateMutationQueue(args, matrixState);
  const activeControllers = new Map();
  const activePromises = new Map();
  const deliveryRetryTimers = new Map();
  const configuredRoomIds = new Set(matrixState.configuredRooms || []);
  const retiredConfiguredRooms = new Set(matrixState.retiredRoomIds || []);
  const joinedConfiguredRooms = new Set();
  const turnTimeoutMs = matrixTimeoutMs(opts.turnMatrixTimeoutMs, DEFAULT_MATRIX_TURN_TIMEOUT_MS);
  const cleanupTimeoutMs = matrixTimeoutMs(opts.cleanupMatrixTimeoutMs, DEFAULT_MATRIX_CLEANUP_TIMEOUT_MS);
  const controlAckTimeoutMs = matrixTimeoutMs(opts.controlAckTimeoutMs, DEFAULT_MATRIX_CONTROL_ACK_TIMEOUT_MS);
  const metadataTimeoutMs = matrixTimeoutMs(opts.metadataMatrixTimeoutMs, DEFAULT_MATRIX_METADATA_TIMEOUT_MS);
  const joinTimeoutMs = matrixTimeoutMs(opts.joinMatrixTimeoutMs, DEFAULT_MATRIX_JOIN_TIMEOUT_MS);
  const syncTimeoutMs = matrixTimeoutMs(opts.syncMatrixTimeoutMs, DEFAULT_MATRIX_SYNC_TIMEOUT_MS);
  const shutdownSignal = opts.shutdownSignal || runtimeState.workerShutdownSignal;
  const shutdownGraceMs = matrixTimeoutMs(opts.shutdownGraceMs, DEFAULT_SHUTDOWN_GRACE_MS);
  let draining = false;
  let drainAgain = false;
  let matrixSyncFailures = 0;
  let shutdownRequested = false;
  let shutdownRequestedAt = 0;
  let finishShutdownPromise = null;
  let resolveShutdownRequest;
  const shutdownRequest = new Promise(resolve => {
    resolveShutdownRequest = resolve;
  });
  const finishingRecoveries = [];

  function requestShutdown() {
    if (shutdownRequested) return;
    shutdownRequested = true;
    shutdownRequestedAt = Date.now();
    resolveShutdownRequest();
    runtimeState.matrixSyncAbortController?.abort();
    for (const scheduled of deliveryRetryTimers.values()) clearTimeout(scheduled.timer);
    deliveryRetryTimers.clear();
    for (const active of activeControllers.values()) {
      if (active.deliveryOnly) active.controller.abort();
    }
    logEvent("info", "matrix_shutdown_requested", {
      runtime: args.runtime,
      activeTurns: activePromises.size,
      graceMs: shutdownGraceMs
    });
  }

  async function reconcileConfiguredRooms(joinAttempts) {
    const nextRooms = matrixRooms(runtimeState.runtime || {});
    const nextRoomIds = new Set(nextRooms);
    const removed = Array.from(configuredRoomIds).filter(roomId => !nextRoomIds.has(roomId));
    const added = nextRooms.filter(roomId => !configuredRoomIds.has(roomId));

    for (const roomId of removed) retiredConfiguredRooms.add(roomId);
    for (const roomId of nextRooms) retiredConfiguredRooms.delete(roomId);
    configuredRoomIds.clear();
    for (const roomId of nextRooms) configuredRoomIds.add(roomId);

    await withStateMutation(state => {
      state.configuredRooms = Array.from(configuredRoomIds);
      state.retiredRoomIds = Array.from(retiredConfiguredRooms);
      for (const roomId of nextRooms) ensureRoomState(state, roomId);
      for (const roomId of removed) {
        const room = state.rooms?.[roomId];
        if (room) room.pendingTurn = null;
      }
      const queue = Array.isArray(state.scheduler?.pendingRoomQueue)
        ? state.scheduler.pendingRoomQueue
        : [];
      state.scheduler = state.scheduler && typeof state.scheduler === "object"
        ? state.scheduler
        : {};
      state.scheduler.pendingRoomQueue = queue.filter(roomId => !retiredConfiguredRooms.has(roomId));
    });

    for (const roomId of removed) {
      logEvent("info", "matrix_room_retired", { runtime: args.runtime, roomId });
    }
    for (const roomId of added) {
      logEvent("info", "matrix_room_configured", { runtime: args.runtime, roomId });
    }
    for (const roomId of nextRooms) {
      if (joinedConfiguredRooms.has(roomId)) continue;
      if (joinAttempts?.has(roomId)) continue;
      joinAttempts?.add(roomId);
      await matrixJoin(edge, runtimeState, roomId, { timeoutMs: joinTimeoutMs })
        .then(() => {
          joinedConfiguredRooms.add(roomId);
          logEvent("info", "matrix_room_joined", { runtime: args.runtime, roomId });
        })
        .catch(error => logEvent("warn", "matrix_room_join_failed", {
          runtime: args.runtime,
          roomId,
          error
        }));
    }
  }

  await withStateMutation(state => {
    for (const roomId of matrixRooms(initialRuntime)) ensureRoomState(state, roomId);
    for (const [roomId, room] of Object.entries(state.rooms || {})) {
      const recovery = recoverRoomState(state, roomId, ensureRoomState(state, roomId), opts, args, runtimeState, edge);
      if (recovery?.status === "finishing" && recovery.turnId) {
        finishingRecoveries.push({ roomId, turnId: recovery.turnId });
      }
    }
  });
  logEvent("info", "matrix_loop_started", {
    runtime: args.runtime,
    workerName: edge.workerName,
    rooms: matrixRooms(initialRuntime),
    maxConcurrentTasks: resolveMaxConcurrentTasks(args, runtimeState),
    hasSyncToken: Boolean(matrixState.matrixSyncToken),
    bootstrapPending: Boolean(matrixState.bootstrapPending)
  });
  if (transportReset) {
    logEvent("info", "matrix_transport_state_reset", {
      runtime: args.runtime,
      workerName: edge.workerName,
      rooms: matrixRooms(initialRuntime)
    });
  }

  for (const recovery of finishingRecoveries) {
    await deliverPersistedRoomTurn(
      recovery.roomId,
      recovery.turnId,
      stableExecution,
      { timeoutMs: turnTimeoutMs }
    );
  }
  async function applyControlCommand(command, roomId) {
    const execution = stableExecution;
    let abortController = null;
    let finishWithoutController = null;
    await withStateMutation(state => {
      const room = ensureRoomState(state, roomId);
      const running = room.runningTurn;
      if (command === "/stop") {
        room.pausedByStop = true;
        if (running) {
          const wasFinishing = running.status === "finishing";
          running.status = "stopping";
          abortController = activeControllers.get(roomId)?.controller || null;
          if (wasFinishing && !abortController) {
            finishWithoutController = {
              turnId: running.turnId,
              result: runResultFromCompletion(running.completion)
            };
          }
        }
      } else if (command === "/clear") {
        room.pendingTurn = null;
        room.history = [];
        room.pausedByStop = false;
        const sessions = sessionsFor(opts, state);
        dropSessionForRoom(opts, sessions, roomId, execution.args, execution.runtimeState, edge);
        if (running) {
          const wasFinishing = running.status === "finishing";
          running.status = "resetting";
          abortController = activeControllers.get(roomId)?.controller || null;
          if (wasFinishing && !abortController) {
            finishWithoutController = {
              turnId: running.turnId,
              result: runResultFromCompletion(running.completion)
            };
          }
        }
      }
    });
    if (abortController) abortController.abort();
    if (finishWithoutController) {
      cancelFinishingRetry(roomId, finishWithoutController.turnId);
      await finishStoppedOrResetting(
        roomId,
        finishWithoutController.turnId,
        finishWithoutController.result,
        execution
      );
    }
    logEvent("info", "matrix_control_command_applied", {
      runtime: execution.args.runtime,
      roomId,
      command,
      abortedRunningTask: Boolean(abortController)
    });
    const body = command === "/stop"
      ? "已停止当前任务，保留当前会话。"
      : "已停止当前任务并清空上下文，下一次消息会开启新会话。";
    await matrixSendMessage(edge, runtimeState, roomId, body, {
      msgtype: "m.notice",
      formatted: false,
      timeoutMs: controlAckTimeoutMs
    }).catch(() => {});
    writeStatus(execution.args, "Running", command === "/stop" ? "MatrixTaskStopped" : "MatrixSessionCleared", body);
  }

  async function finishStoppedOrResetting(roomId, turnId, result, execution) {
    const normalized = normalizeRunResult(result || {});
    const executionArgs = execution?.args || args;
    const executionRuntimeState = execution?.runtimeState || runtimeState;
    let handled = false;
    await withStateMutation(state => {
      const room = ensureRoomState(state, roomId);
      const running = room.runningTurn;
      if (!running || running.turnId !== turnId) return;
      if (running.status === "stopping") {
        const sessions = sessionsFor(opts, state);
        const nextSessionId = normalized.sessionId || normalized.nextSessionId || "";
        if (nextSessionId) {
          storeSessionForRoom(opts, sessions, roomId, executionArgs, nextSessionId, executionRuntimeState, edge);
        }
        room.runningTurn = null;
        room.pausedByStop = true;
        handled = true;
      } else if (running.status === "resetting") {
        room.runningTurn = null;
        room.pendingTurn = null;
        room.history = [];
        room.pausedByStop = false;
        handled = true;
      }
    });
    return handled;
  }

  function cancelFinishingRetry(roomId, turnId) {
    const scheduled = deliveryRetryTimers.get(roomId);
    if (!scheduled || (turnId && scheduled.turnId !== turnId)) return false;
    clearTimeout(scheduled.timer);
    deliveryRetryTimers.delete(roomId);
    return true;
  }

  function scheduleFinishingRetry(roomId, turnId, attempts) {
    if (shutdownRequested) return;
    const current = deliveryRetryTimers.get(roomId);
    if (current?.turnId === turnId) return;
    if (current) cancelFinishingRetry(roomId);
    const delayMs = matrixSyncRetryDelayMs(args, attempts);
    const timer = setTimeout(() => {
      const scheduled = deliveryRetryTimers.get(roomId);
      if (!scheduled || scheduled.turnId !== turnId) return;
      deliveryRetryTimers.delete(roomId);
      if (shutdownRequested) return;
      const controller = createTaskAbortController();
      const activeRetry = { turnId, controller, deliveryOnly: true };
      activeControllers.set(roomId, activeRetry);
      deliverPersistedRoomTurn(
        roomId,
        turnId,
        stableExecution,
        turnMatrixIoOptions(controller.signal, turnTimeoutMs)
      ).then(delivered => {
        if (delivered) return drainScheduler();
        return undefined;
      }).catch(error => {
        logEvent("warn", "matrix_turn_reply_retry_failed", {
          runtime: args.runtime,
          roomId,
          turnId,
          error
        });
        scheduleFinishingRetry(roomId, turnId, attempts + 1);
      }).finally(() => {
        if (activeControllers.get(roomId) === activeRetry) activeControllers.delete(roomId);
      });
    }, delayMs);
    timer.unref?.();
    deliveryRetryTimers.set(roomId, { turnId, timer });
  }

  async function deliverPersistedRoomTurn(roomId, turnId, execution, matrixOptions, persistedFinishing) {
    const executionArgs = execution?.args || args;
    const executionRuntimeState = execution?.runtimeState || runtimeState;
    let finishing = persistedFinishing || null;
    if (!finishing) {
      await withStateMutation(state => {
        const running = ensureRoomState(state, roomId).runningTurn;
        if (!running || running.turnId !== turnId || running.status !== "finishing" ||
            !running.completion || typeof running.completion !== "object") return;
        finishing = { ...running };
      });
    }
    if (!finishing) return false;

    let sendError = null;
    const completion = finishing.completion;
    const normalized = runResultFromCompletion(completion);
    const finalError = errorFromCompletion(completion);
    const transactionId = turnCompletionTransactionId(roomId, turnId);
    try {
      if (finalError) {
        const body = `${opts.failurePrefix || "Runtime 执行失败："}${finalError.message}`;
        const sendOptions = finishing.placeholderEventId
          ? { msgtype: "m.notice", replaceEventId: finishing.placeholderEventId, formatted: false }
          : { msgtype: "m.notice", formatted: false };
        await matrixSendMessage(edge, runtimeState, roomId, body, {
          ...sendOptions,
          ...matrixOptions,
          transactionId
        });
      } else {
        const hasText = Boolean(completion?.reply?.hasText);
        if (hasText) {
          const replyText = String(completion.reply.text || "");
          if (isNoReplyText(replyText)) {
            if (finishing.placeholderEventId) {
              await matrixSendMessage(edge, runtimeState, roomId, "已处理", {
                msgtype: "m.notice",
                replaceEventId: finishing.placeholderEventId,
                formatted: false,
                ...matrixOptions,
                transactionId
              });
            }
          } else {
            await matrixSendMessage(edge, runtimeState, roomId, replyText, {
              msgtype: completion.reply.msgtype || "m.text",
              replaceEventId: finishing.placeholderEventId,
              formatted: completion.reply.formatted !== false,
              ...matrixOptions,
              transactionId
            });
          }
        }
      }
    } catch (error) {
      sendError = error;
    }
    if (await finishStoppedOrResetting(roomId, turnId, normalized, execution)) return true;
    if (sendError) {
      let retained = false;
      let attempts = 1;
      let retryDelayMs = matrixSyncRetryDelayMs(args, attempts);
      await withStateMutation(state => {
        const running = ensureRoomState(state, roomId).runningTurn;
        if (!running || running.turnId !== turnId || running.status !== "finishing") return;
        attempts = Number(running.delivery?.attempts || 0) + 1;
        retryDelayMs = matrixSyncRetryDelayMs(args, attempts);
        running.delivery = {
          attempts,
          lastError: String(sendError.message || sendError).slice(0, 500),
          lastReason: String(sendError.reason || sendError.name || "MatrixReplyFailed"),
          lastStatus: Number(sendError.status || 0) || undefined,
          nextRetryAt: new Date(Date.now() + retryDelayMs).toISOString()
        };
        retained = true;
      });
      if (!retained) {
        return Boolean(await finishStoppedOrResetting(roomId, turnId, normalized, execution));
      }
      writeStatus(executionArgs, "Degraded", "MatrixReplyPending", `final reply delivery failed; retrying in ${Math.round(retryDelayMs / 1000)}s`, {
        roomId,
        turnId,
        attempts,
        retryDelayMs
      });
      logEvent("warn", "matrix_turn_reply_deferred", {
        ...modelConfigLogFields(executionArgs, edge, executionRuntimeState),
        roomId,
        turnId,
        eventIds: finishing.eventIds || [],
        attempts,
        retryDelayMs,
        error: sendError
      });
      scheduleFinishingRetry(roomId, turnId, attempts);
      return false;
    }
    cancelFinishingRetry(roomId, turnId);
    logEvent(finalError ? "warn" : "info", "matrix_turn_finished", {
      ...modelConfigLogFields(executionArgs, edge, executionRuntimeState),
      roomId,
      turnId,
      eventIds: finishing.eventIds || [],
      status: finalError ? "failed" : "completed",
      reason: finalError ? (finalError.reason || finalError.name || "RuntimeExecutionFailed") : "Completed",
      noReply: isNoReplyText(String(completion?.reply?.text || "")),
      hasReplyText: Boolean(completion?.reply?.hasText),
      error: finalError || undefined
    });

    await withStateMutation(state => {
      const room = ensureRoomState(state, roomId);
      const running = room.runningTurn;
      if (!running || running.turnId !== turnId) return;
      const sessions = sessionsFor(opts, state);
      const nextSessionId = normalized.sessionId || normalized.nextSessionId || "";
      const forceDropOnly = Boolean(finalError || running.dropSessionOnFinish);
      if ((forceDropOnly && !running.sessionDroppedOnFinish) || normalized.dropSession) {
        dropSessionForRoom(opts, sessions, roomId, executionArgs, executionRuntimeState, edge);
      }
      if (!forceDropOnly && nextSessionId) {
        storeSessionForRoom(opts, sessions, roomId, executionArgs, nextSessionId, executionRuntimeState, edge);
      }
      room.runningTurn = null;
      if (room.pendingTurn && !room.pausedByStop) enqueuePendingRoom(state, roomId);
    });
    return true;
  }

  async function finishRoomTurn(roomId, turnId, result, error, execution, matrixOptions) {
    const completion = persistedTurnCompletion(result, error);
    let finishing = null;
    await withStateMutation(state => {
      const room = ensureRoomState(state, roomId);
      const running = room.runningTurn;
      if (!running || running.turnId !== turnId) return;
      if (running.status === "stopping" || running.status === "resetting") return;
      running.status = "finishing";
      running.completion = completion;
      finishing = { ...running };
    });
    if (!finishing) {
      await finishStoppedOrResetting(roomId, turnId, runResultFromCompletion(completion), execution);
      return;
    }
    await deliverPersistedRoomTurn(roomId, turnId, execution, matrixOptions, finishing);
  }

  async function runRoomTurn(roomId, startedTurn) {
    const turnIdValue = startedTurn.turnId;
    const controller = createTaskAbortController();
    let execution = stableExecution;
    let viewHandle = null;
    let placeholderEventId = startedTurn.placeholderEventId || "";
    const turnIoOptions = turnMatrixIoOptions(controller.signal, turnTimeoutMs);
    const activeTurn = { turnId: turnIdValue, controller };
    activeControllers.set(roomId, activeTurn);
    logEvent("info", "matrix_turn_starting", {
      ...modelConfigLogFields(execution.args, edge, execution.runtimeState),
      roomId,
      turnId: turnIdValue,
      eventIds: startedTurn.eventIds || [],
      attempt: startedTurn.attempt || 0,
      hasSession: Boolean(startedTurn.sessionId)
    });
    try {
      if (typeof opts.acquireRuntimeForTask === "function") {
        try {
          viewHandle = await opts.acquireRuntimeForTask(args, edge, runtimeState, {
            abortSignal: controller.signal,
            turn: startedTurn
          });
          if (!viewHandle || typeof viewHandle.release !== "function") {
            throw new Error("runtime View handle is invalid");
          }
          const snapshot = viewHandle.snapshot || {};
          if (!snapshot.args || !snapshot.runtimeState) {
            throw new Error("runtime View snapshot is invalid");
          }
          execution = snapshot;
          const viewDigest = String(
            viewHandle.viewDigest ||
            snapshot.runtimeState?.pluginRuntime?.viewDigest ||
            ""
          ).trim();
          if (viewDigest) {
            startedTurn.viewDigest = viewDigest;
            await withStateMutation(state => {
              const running = ensureRoomState(state, roomId).runningTurn;
              if (running && running.turnId === turnIdValue) running.viewDigest = viewDigest;
            });
          }
        } catch (error) {
          if (!error?.restartRequired) {
            writeStatus(execution.args, "Degraded", error?.reason || "RuntimePrepareFailed", error?.message || String(error));
          }
          throw error;
        }
      } else if (typeof opts.prepareRuntimeForTask === "function") {
        try {
          await opts.prepareRuntimeForTask(args, edge, runtimeState);
          execution = { args, runtimeState };
        } catch (error) {
          writeStatus(execution.args, "Degraded", error?.reason || "RuntimePrepareFailed", error?.message || String(error));
          throw error;
        }
      }
      if (controller.signal.aborted) throw Object.assign(new Error("Matrix command stopped current session"), { name: "AbortError" });
      await matrixTyping(edge, runtimeState, roomId, true, turnIoOptions).catch(() => {});
      if (!placeholderEventId) {
        const placeholder = await matrixSendMessage(edge, runtimeState, roomId, "处理中...", {
          msgtype: "m.notice",
          formatted: false,
          ...turnIoOptions
        });
        placeholderEventId = placeholder.event_id || "";
      }

      let runnableTurn = null;
      await withStateMutation(state => {
        const room = ensureRoomState(state, roomId);
        const running = room.runningTurn;
        if (!running || running.turnId !== turnIdValue || running.status !== "starting") return;
        running.placeholderEventId = placeholderEventId;
        running.status = "running";
        runnableTurn = {
          ...running,
          roomId,
          abortSignal: controller.signal,
          matrixIoTimeoutMs: turnTimeoutMs
        };
      });
      if (!runnableTurn) {
        logEvent("warn", "matrix_turn_not_runnable", {
          runtime: execution.args.runtime,
          roomId,
          turnId: turnIdValue
        });
        await finishStoppedOrResetting(roomId, turnIdValue);
        return;
      }
      if (controller.signal.aborted) {
        logEvent("info", "matrix_turn_aborted_before_run", {
          runtime: execution.args.runtime,
          roomId,
          turnId: turnIdValue
        });
        await finishStoppedOrResetting(roomId, turnIdValue);
        return;
      }
      logEvent("info", "matrix_turn_running", {
        ...modelConfigLogFields(execution.args, edge, execution.runtimeState),
        roomId,
        turnId: turnIdValue,
        eventIds: runnableTurn.eventIds || [],
        hasSession: Boolean(runnableTurn.sessionId),
        sessionFingerprint: sessionFingerprint(runnableTurn.sessionId)
      });
      const result = await runTurnAdapter(opts, args, edge, runtimeState, runnableTurn, execution);
      await finishRoomTurn(roomId, turnIdValue, result, null, execution, turnIoOptions);
    } catch (error) {
      const stopped = controller.signal.aborted || error?.name === "AbortError";
      logEvent(stopped ? "info" : "error", stopped ? "matrix_turn_stopped" : "matrix_turn_failed", {
        ...modelConfigLogFields(execution.args, edge, execution.runtimeState),
        roomId,
        turnId: turnIdValue,
        eventIds: startedTurn.eventIds || [],
        reason: stopped ? "Stopped" : (error?.reason || error?.name || "RuntimeExecutionFailed"),
        error: stopped ? undefined : error
      });
      if (stopped) {
        await finishStoppedOrResetting(roomId, turnIdValue);
      } else {
        await finishRoomTurn(roomId, turnIdValue, null, error, execution, turnIoOptions);
      }
    } finally {
      await matrixTyping(edge, runtimeState, roomId, false, {
        timeoutMs: cleanupTimeoutMs
      }).catch(() => {});
      if (activeControllers.get(roomId) === activeTurn) activeControllers.delete(roomId);
      activePromises.delete(roomId);
      if (viewHandle) {
        try {
          await viewHandle.release();
        } catch (_) {}
      }
      await drainScheduler().catch(error => {
        writeStatus(args, "Degraded", "MatrixSchedulerDrainFailed", error.message);
      });
    }
  }

  async function drainScheduler() {
    if (shutdownRequested) return;
    if (draining) {
      drainAgain = true;
      return;
    }
    draining = true;
    try {
      do {
        drainAgain = false;
        for (;;) {
          let start = null;
          await withStateMutation(state => {
            if (shutdownRequested) return;
            const maxConcurrentTasks = resolveMaxConcurrentTasks(args, runtimeState);
            if (countRunningRooms(state) >= maxConcurrentTasks) return;
            const queue = Array.isArray(state.scheduler?.pendingRoomQueue) ? state.scheduler.pendingRoomQueue : [];
            state.scheduler = state.scheduler && typeof state.scheduler === "object" ? state.scheduler : {};
            state.scheduler.pendingRoomQueue = [];
            while (queue.length) {
              const roomId = String(queue.shift() || "");
              if (!roomId) continue;
              const room = ensureRoomState(state, roomId);
              if (retiredConfiguredRooms.has(roomId)) {
                room.pendingTurn = null;
                continue;
              }
              if (!room.pendingTurn || room.runningTurn || room.pausedByStop) continue;
              const sessions = sessionsFor(opts, state);
              const pending = room.pendingTurn;
              const execution = stableExecution;
              const sessionId = pending.sessionId || sessionForRoom(
                opts,
                sessions,
                roomId,
                execution.args,
                execution.runtimeState,
                edge
              );
              room.pendingTurn = null;
              room.runningTurn = {
                ...pending,
                sessionId,
                status: "starting",
                attempt: Number(pending.attempt || 0) + 1,
                startedAt: new Date().toISOString()
              };
              start = { roomId, turn: { ...room.runningTurn } };
              break;
            }
            for (const roomId of queue) {
              if (roomId && !state.scheduler.pendingRoomQueue.includes(roomId)) {
                state.scheduler.pendingRoomQueue.push(roomId);
              }
            }
          });
          if (!start) break;
          logEvent("info", "matrix_scheduler_dispatch", {
            runtime: args.runtime,
            roomId: start.roomId,
            turnId: start.turn.turnId,
            eventIds: start.turn.eventIds || [],
            activeRooms: activePromises.size,
            maxConcurrentTasks: resolveMaxConcurrentTasks(args, runtimeState)
          });
          const promise = runRoomTurn(start.roomId, start.turn);
          activePromises.set(start.roomId, promise);
        }
      } while (drainAgain);
    } finally {
      draining = false;
    }
  }

  async function processMatrixEvent(roomId, event, protectedIds, bootstrap) {
    if (shutdownRequested) return;
    const eventId = String(event.event_id || "");
    if (retiredConfiguredRooms.has(roomId)) {
      await withStateMutation(state => {
        if (!eventId) return;
        state.matrixCursors[roomId] = eventId;
        addSeenEventId(state, eventId, protectedIds);
      });
      logEvent("info", "matrix_event_processed", {
        runtime: args.runtime,
        roomId,
        eventId,
        sender: event.sender || "",
        action: "retired",
        bootstrap: Boolean(bootstrap),
        isReplace: isMatrixReplaceEvent(event),
        isThread: isMatrixThreadEvent(event)
      });
      return;
    }
    let controlToApply = "";
    let eventAction = "";
    const roomKind = await classifyMatrixRoom(edge, runtimeState, roomId, event, { timeoutMs: metadataTimeoutMs });
    if (shutdownRequested) return;
    await withStateMutation(state => {
      const runtime = runtimeState.runtime || {};
      const room = ensureRoomState(state, roomId);
      if (eventId && Array.isArray(state.seenEventIds) && state.seenEventIds.includes(eventId)) {
        state.matrixCursors[roomId] = eventId;
        return;
      }
      const body = eventBody(event);
      const collectsHistory = roomKindCollectsHistory(roomKind.kind);
      if (!bootstrap && event && event.type === "m.room.message" && !isMatrixThreadEvent(event)) {
        const command = matrixControlCommand(event, roomId, edge, runtimeState, roomKind);
        if (command) {
          controlToApply = command;
          eventAction = "control";
        } else if (shouldHandleEventForRoomKind(event, roomKind, runtimeState)) {
          appendPendingMessage(state, roomId, event, roomKind);
          eventAction = "queued";
        } else if (collectsHistory && body.trim() && event.sender !== runtime.member?.matrixUserId) {
          appendRoomHistory(room, event);
        }
      } else if (bootstrap && collectsHistory && body.trim() && event.sender !== runtime.member?.matrixUserId && !isMatrixThreadEvent(event)) {
        appendRoomHistory(room, event);
      }
      if (eventId) {
        state.matrixCursors[roomId] = eventId;
        addSeenEventId(state, eventId, protectedIds);
      }
    });

    if (eventAction) {
      logEvent("info", "matrix_event_processed", {
        runtime: args.runtime,
        roomId,
        eventId,
        sender: event.sender || "",
        action: eventAction,
        controlCommand: controlToApply,
        roomKind: roomKind.kind,
        bootstrap: Boolean(bootstrap),
        isReplace: isMatrixReplaceEvent(event),
        isThread: isMatrixThreadEvent(event)
      });
    }
    if (controlToApply) await applyControlCommand(controlToApply, roomId);
  }

  async function waitForIdleOnce() {
    for (;;) {
      await drainScheduler();
      const promises = Array.from(activePromises.values());
      if (!promises.length) return;
      await Promise.allSettled(promises);
    }
  }

  async function waitForActivePromises(promises, timeoutMs) {
    if (!promises.length) return true;
    let timer;
    const completed = Promise.allSettled(promises).then(() => true);
    const timedOut = new Promise(resolve => {
      timer = setTimeout(() => resolve(false), Math.max(1, timeoutMs));
    });
    try {
      return await Promise.race([completed, timedOut]);
    } finally {
      clearTimeout(timer);
    }
  }

  function finishShutdown() {
    if (finishShutdownPromise) return finishShutdownPromise;
    finishShutdownPromise = (async () => {
      const active = Array.from(activePromises.values());
      const elapsedMs = Math.max(0, Date.now() - shutdownRequestedAt);
      const completed = await waitForActivePromises(active, Math.max(1, shutdownGraceMs - elapsedMs));
      if (!completed) {
        logEvent("warn", "matrix_shutdown_grace_expired", {
          runtime: args.runtime,
          activeTurns: activePromises.size,
          graceMs: shutdownGraceMs
        });
        for (const activeTurn of activeControllers.values()) {
          activeTurn.controller.abort();
        }
        await waitForActivePromises(active, cleanupTimeoutMs);
      }
      logEvent("info", "matrix_shutdown_finished", {
        runtime: args.runtime,
        activeTurns: activePromises.size
      });
    })().finally(() => {
      shutdownSignal?.removeEventListener?.("abort", requestShutdown);
    });
    return finishShutdownPromise;
  }

  async function waitForShutdownOrDelay(delayMs) {
    let timer;
    try {
      await Promise.race([
        new Promise(resolve => {
          timer = setTimeout(resolve, delayMs);
        }),
        shutdownRequest
      ]);
    } finally {
      clearTimeout(timer);
    }
  }

  shutdownSignal?.addEventListener?.("abort", requestShutdown, { once: true });
  if (shutdownSignal?.aborted) requestShutdown();

  let joinAttempts = new Set();
  for (;;) {
    if (shutdownRequested) {
      await finishShutdown();
      return;
    }
    await reconcileConfiguredRooms(joinAttempts);
    if (shutdownRequested) {
      await finishShutdown();
      return;
    }
    const runtime = runtimeState.runtime || {};
    const token = runtime.matrix && runtime.matrix.accessToken;
    if (!token) {
      writeStatus(args, "Degraded", "MatrixAccessTokenMissing", "runtime.yaml missing matrix.accessToken");
      logEvent("warn", "matrix_access_token_missing", { runtime: args.runtime });
      await waitForShutdownOrDelay(Math.max(1, args.intervalSeconds) * 1000);
      continue;
    }
    const filter = encodeURIComponent(JSON.stringify({
      "io.agentteams.sync": "worker",
      room: { timeline: { limit: 50 } }
    }));
    const since = matrixState.matrixSyncToken || "";
    const query = since ? `timeout=30000&since=${encodeURIComponent(since)}&filter=${filter}` : `timeout=30000&filter=${filter}`;
    const syncRevision = Number(runtimeState.matrixCredentialRevision || 0);
    const syncController = new AbortController();
    runtimeState.matrixSyncAbortController = syncController;
    let sync;
    try {
      sync = await matrixRequestForRuntime(
        "GET",
        edge,
        runtimeState,
        `/_matrix/client/v3/sync?${query}`,
        undefined,
        { signal: syncController.signal, timeoutMs: syncTimeoutMs }
      );
      if (matrixSyncFailures > 0) {
        writeStatus(args, "Running", "MatrixReconnected", `Matrix sync recovered after ${matrixSyncFailures} failed attempt(s)`, {
          failureCount: matrixSyncFailures
        });
        logEvent("info", "matrix_sync_reconnected", {
          runtime: args.runtime,
          failureCount: matrixSyncFailures
        });
        matrixSyncFailures = 0;
      }
    } catch (error) {
      if (shutdownRequested) {
        await finishShutdown();
        return;
      }
      if (
        error?.reason === "MatrixRequestAborted" &&
        Number(runtimeState.matrixCredentialRevision || 0) !== syncRevision
      ) {
        logEvent("info", "matrix_sync_restarting_for_token_rotation", {
          runtime: args.runtime,
          revision: runtimeState.matrixCredentialRevision
        });
        continue;
      }
      matrixSyncFailures += 1;
      const retryDelayMs = matrixSyncRetryDelayMs(args, matrixSyncFailures);
      writeStatus(args, "Degraded", "MatrixSyncFailed", `${error.message}; retrying in ${Math.round(retryDelayMs / 1000)}s`, {
        failureCount: matrixSyncFailures,
        retryDelayMs
      });
      logEvent("warn", "matrix_sync_failed", {
        runtime: args.runtime,
        failureCount: matrixSyncFailures,
        retryDelayMs,
        error
      });
      await waitForShutdownOrDelay(retryDelayMs);
      continue;
    } finally {
      if (runtimeState.matrixSyncAbortController === syncController) {
        delete runtimeState.matrixSyncAbortController;
      }
    }
    if (shutdownRequested) {
      await finishShutdown();
      return;
    }
    await reconcileConfiguredRooms(joinAttempts);
    if (shutdownRequested) {
      await finishShutdown();
      return;
    }
    const bootstrap = Boolean(matrixState.bootstrapPending);

    const invites = sync.rooms && sync.rooms.invite ? sync.rooms.invite : {};
    for (const roomId of Object.keys(invites)) {
      if (shutdownRequested) break;
      await matrixJoin(edge, runtimeState, roomId, { timeoutMs: joinTimeoutMs }).catch(error => {
        writeStatus(args, "Degraded", "MatrixInviteJoinFailed", error.message);
        logEvent("warn", "matrix_invite_join_failed", {
          runtime: args.runtime,
          roomId,
          error
        });
      });
      await withStateMutation(state => ensureRoomState(state, roomId));
    }

    const joined = sync.rooms && sync.rooms.join ? sync.rooms.join : {};
    const protectedIds = [];
    for (const room of Object.values(joined)) {
      const events = room.timeline && Array.isArray(room.timeline.events) ? room.timeline.events : [];
      for (const event of events) {
        if (event?.event_id) protectedIds.push(String(event.event_id));
      }
    }
    for (const [roomId, room] of Object.entries(joined)) {
      if (shutdownRequested) break;
      await withStateMutation(state => {
        for (const configuredRoom of matrixRooms(runtime)) ensureRoomState(state, configuredRoom);
        ensureRoomState(state, roomId);
      });
      const events = room.timeline && Array.isArray(room.timeline.events) ? room.timeline.events : [];
      const hasSyncCheckpoint = Boolean(since);
      const lastEventId = String(matrixState.matrixCursors[roomId] || "");
      let unread = hasSyncCheckpoint || bootstrap ? events : messagesAfter(events, lastEventId);
      if (!hasSyncCheckpoint && !lastEventId && !bootstrap) {
        unread = unread.slice(-50);
      }
      for (const event of unread) {
        if (shutdownRequested) break;
        await processMatrixEvent(roomId, event, protectedIds, bootstrap);
      }
    }
    if (shutdownRequested) {
      await finishShutdown();
      return;
    }
    await withStateMutation(state => {
      state.matrixSyncToken = sync.next_batch || since;
      state.nextBatch = state.matrixSyncToken;
      state.bootstrapPending = false;
      trimSeenEventIds(state, []);
    });
    await drainScheduler();
    if (shutdownRequested) {
      await finishShutdown();
      return;
    }
    if (process.env.TEAMHARNESS_MATRIX_ONCE === "1" || args.once) {
      await waitForIdleOnce();
      shutdownSignal?.removeEventListener?.("abort", requestShutdown);
      return;
    }
    joinAttempts = new Set();
  }
}

module.exports = {
  applyMatrixTransportBoundary,
  escapeRegExp,
  containsNameMention,
  isMatrixThreadEvent,
  isMatrixReplaceEvent,
  eventMentionsUser,
  messagesAfter,
  loadMatrixState,
  matrixHomeserver,
  matrixTransportIdentity,
  writeMatrixState,
  matrixRequest,
  matrixRequestForRuntime,
  turnMatrixIoOptions,
  txnId,
  escapeHtml,
  renderInlineMarkdown,
  matrixFormattedBody,
  matrixEditFallbackHtml,
  matrixSendMessage,
  matrixRedactMessage,
  matrixJoin,
  matrixTyping,
  eventBody,
  classifyMatrixRoom,
  shouldHandleEventForRoomKind,
  shouldHandleEvent,
  isNoReplyText,
  matrixSyncRetryDelayMs,
  stripCurrentWorkerMentionText,
  matrixControlCommand,
  createStateMutationQueue,
  resolveMaxConcurrentTasks,
  runMatrixLoop
};
