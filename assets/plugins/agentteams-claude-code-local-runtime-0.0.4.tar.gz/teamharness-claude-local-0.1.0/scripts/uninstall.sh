#!/usr/bin/env bash
set -euo pipefail

default_root="${PILOT_DATA:-${HOME}/.local/share/teamharness}"
target_dir="${TEAMHARNESS_CLAUDE_PLUGIN_DIR:-${default_root}/plugins/teamharness-claude-plugin}"
rm -rf "${target_dir}"

if [ -n "${TEAMHARNESS_INSTALL_LOG:-}" ]; then
  mkdir -p "$(dirname "${TEAMHARNESS_INSTALL_LOG}")"
  printf '{"event":"uninstall","runtime":"claude-code","pluginDir":"%s"}\n' "${target_dir}" >> "${TEAMHARNESS_INSTALL_LOG}"
fi
