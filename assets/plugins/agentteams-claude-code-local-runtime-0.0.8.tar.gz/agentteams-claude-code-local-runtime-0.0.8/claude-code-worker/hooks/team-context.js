#!/usr/bin/env node
"use strict";

async function main() {
  const lines = [
    "A managed local Claude runtime is active.",
    "Use only the tools configured for this runtime and complete assigned work directly.",
    "Do not treat low-information acknowledgements as task completion."
  ];
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: "SessionStart",
      additionalContext: lines.join("\n")
    }
  }));
}

main().catch(() => {});
