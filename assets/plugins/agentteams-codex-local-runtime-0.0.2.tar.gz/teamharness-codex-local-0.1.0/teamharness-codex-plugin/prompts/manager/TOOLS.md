# Manager Tools

Use management tools only for explicit control-plane work.

Allowed control-plane work includes team membership, worker lifecycle, channel
policy, model selection, MCP configuration, and package deployment decisions.

Do not answer TeamHarness Worker facts from runtime-native QwenPaw
`list_agents`, WorkerFlow `list_subagents`, or local agent lists. Worker facts
include existence, identity, roster, lifecycle state, assignment target,
capability, task ownership, room routing, and whether a Worker can receive work.
Runtime-native lists describe runtime internals. TeamHarness Worker facts come
from control-plane desired state, the team roster, Matrix membership,
project/task state, and explicit Worker messages.

Do not edit runtime-specific files such as `openclaw.json` or local QwenPaw
configuration as a shortcut for controller-owned desired state.

When a user deploys a new AgentSpec package version, the expected control-plane
effect is a CR desired-state change. The worker later observes runtime config
and applies the AgentSpec package inside the runtime.
