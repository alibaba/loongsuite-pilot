---
name: teamharness-file-sharing
description: "Use for TeamHarness shared workspace paths, filesync, artifact publication, and Matrix room file boundaries, including artifact publish_file and task/project deliverables. Do not use for message routing or project state changes."
---

# File Sharing

Use shared workspace paths in task specs and team messages.

Project files belong under `shared/projects/{project-id}/`. Task specs,
deliverables, and results belong under `shared/tasks/{task-id}/`.

Do not expose object storage internals in human-facing messages. Use TeamHarness
filesync tools for explicit shared file operations.

## Shared Files vs Room Files

`shared/...` paths are durable collaboration state. Matrix room files are
visible `m.file` events; mentioning a shared path in text does not add it to the
room Files panel.

Keep Worker deliverables under `shared/tasks/{task-id}/` and list them in
`taskflow submit_task`. Keep Leader-owned project reports under
`shared/projects/{project-id}/`. `submit_task` publishes eligible task files to
the Matrix Task room and reports each outcome in `publishedArtifacts`.

Use `artifact publish_file` when another workspace-relative file must become a
Matrix room file. Pass an explicit Matrix `target` or `roomId`, and use the
requester report's Matrix `messageId` as `parentEventId` when the file should be
attached to that report.

Do not claim that Matrix room files were delivered to DingTalk, Feishu, WeChat,
or another non-Matrix requester channel. For those reports, list the relevant
`shared/...` paths instead. Do not publish sensitive files; TeamHarness rejects
obvious sensitive paths and text content.

## Shared Paths

Use these paths in task specs and team messages:

```text
shared/projects/{project-id}/meta.json
shared/projects/{project-id}/plan.md
shared/projects/{project-id}/result.md
shared/tasks/{task-id}/meta.json
shared/tasks/{task-id}/spec.md
shared/tasks/{task-id}/workspace/
shared/tasks/{task-id}/result.md
```

The Leader owns project files and task specs. Workers own task workspaces,
task deliverables, and task results.

## Filesync

Use `filesync` when you need an explicit shared file operation.

List a concrete shared directory:

```json
{
  "action": "list",
  "path": "shared/projects/demo-project-001"
}
```

Pull before reading remote shared state:

```json
{
  "action": "pull",
  "path": "shared/tasks/task-001"
}
```

Push after writing project-level files:

```json
{
  "action": "push",
  "path": "shared/projects/demo-project-001"
}
```

Do not ask humans or Workers to inspect storage bucket names, access keys, or
provider-specific prefixes. Use `shared/...` paths in all visible coordination.
