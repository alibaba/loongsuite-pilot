#!/usr/bin/env node
"use strict";

const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawnSync } = require("child_process");

const DEFAULT_LOGIN_SHELL_TIMEOUT_MS = 3000;
const DEFAULT_VERSION_TIMEOUT_MS = 10000;
const LOGIN_SHELL_PATH_MARKER = "__TEAMHARNESS_COMMAND_PATH__";

function hasPathSeparator(command) {
  return String(command || "").includes("/") || String(command || "").includes("\\");
}

function isExecutable(file) {
  try {
    const stat = fs.statSync(file);
    if (!stat.isFile()) return false;
    if (process.platform === "win32") return true;
    return (stat.mode & 0o111) !== 0;
  } catch {
    return false;
  }
}

function realpathOrAbsolute(file) {
  try {
    return fs.realpathSync(file);
  } catch {
    return path.resolve(file);
  }
}

function commandCandidates(command, dir, env) {
  const base = path.join(dir, command);
  if (process.platform !== "win32" || path.extname(base)) return [base];
  const extensions = String(env?.PATHEXT || ".EXE;.CMD;.BAT;.COM")
    .split(";")
    .map(item => item.trim())
    .filter(Boolean);
  return [base, ...extensions.map(ext => `${base}${ext}`)];
}

function wrapperDirSet(wrapperDirs) {
  const out = new Set();
  for (const dir of wrapperDirs || []) {
    if (!dir) continue;
    out.add(realpathOrAbsolute(dir));
  }
  return out;
}

function isInSkippedWrapperDir(file, skippedDirs) {
  if (!skippedDirs.size) return false;
  return skippedDirs.has(realpathOrAbsolute(path.dirname(file)));
}

function executableCandidate(file, skippedDirs) {
  if (!file || !isExecutable(file)) return "";
  if (isInSkippedWrapperDir(file, skippedDirs)) return "";
  return realpathOrAbsolute(file);
}

function findInPath(command, env, wrapperDirsToSkip) {
  if (!command || hasPathSeparator(command)) return "";
  const skippedDirs = wrapperDirSet(wrapperDirsToSkip);
  for (const dir of String(env?.PATH || "").split(path.delimiter)) {
    if (!dir) continue;
    for (const candidate of commandCandidates(command, dir, env)) {
      const resolved = executableCandidate(candidate, skippedDirs);
      if (resolved) return resolved;
    }
  }
  return "";
}

function findInSearchPaths(searchPaths, wrapperDirsToSkip) {
  const skippedDirs = wrapperDirSet(wrapperDirsToSkip);
  for (const candidate of searchPaths || []) {
    const resolved = executableCandidate(candidate, skippedDirs);
    if (resolved) return resolved;
  }
  return "";
}

function resolveShell(env) {
  const explicit = String(env?.SHELL || "").trim();
  if (explicit && isExecutable(explicit)) return explicit;
  for (const candidate of ["/bin/zsh", "/bin/bash", "/usr/bin/zsh", "/usr/bin/bash", "/bin/sh"]) {
    if (isExecutable(candidate)) return candidate;
  }
  return "";
}

function shellArgs(shell) {
  const name = path.basename(shell);
  if (name.includes("zsh") || name.includes("bash") || name.includes("ksh")) {
    return ["-ilc"];
  }
  return ["-lc"];
}

function resolveViaLoginShell(commandNames, options) {
  if (process.platform === "win32") return null;
  const opts = options || {};
  const env = opts.env || process.env;
  const shell = resolveShell(env);
  const names = (commandNames || []).filter(Boolean);
  if (!shell || !names.length) return null;

  const script = [
    "set +e",
    `printf '${LOGIN_SHELL_PATH_MARKER}%s\\n' "$PATH"`
  ].join("\n");
  const result = spawnSync(shell, [...shellArgs(shell), script], {
    env,
    timeout: opts.timeoutMs || DEFAULT_LOGIN_SHELL_TIMEOUT_MS,
    maxBuffer: 64 * 1024,
    encoding: "utf8"
  });
  if (result.error || result.status !== 0 || !result.stdout) return null;

  for (const line of String(result.stdout || "").split(/\r?\n/)) {
    if (!line.startsWith(LOGIN_SHELL_PATH_MARKER)) continue;
    const shellPath = line.slice(LOGIN_SHELL_PATH_MARKER.length);
    for (const name of names) {
      const resolved = findInPath(name, { ...env, PATH: shellPath }, opts.wrapperDirsToSkip);
      if (resolved) {
        return {
          command: resolved,
          shell,
          version: "",
          source: "login-shell"
        };
      }
    }
  }
  return null;
}

function invalidResult(command, source, message) {
  return {
    ok: false,
    command,
    source,
    reason: "RuntimeCommandInvalid",
    message
  };
}

function notFoundResult(command, source, displayName) {
  return {
    ok: false,
    command,
    source,
    reason: "RuntimeCommandNotFound",
    message: `${displayName || "Runtime command"} not found: ${command}`
  };
}

function resolveExplicitCommand(command, source, options) {
  const opts = options || {};
  const skippedDirs = wrapperDirSet(opts.wrapperDirsToSkip);
  if (hasPathSeparator(command)) {
    const resolved = executableCandidate(command, skippedDirs);
    if (resolved) return { ok: true, command: resolved, requestedCommand: command, source };
    return invalidResult(command, source, `Configured runtime command is not executable: ${command}`);
  }
  const resolved = findInPath(command, opts.env || process.env, opts.wrapperDirsToSkip);
  if (resolved) return { ok: true, command: resolved, requestedCommand: command, source };
  return invalidResult(command, source, `Configured runtime command is not on PATH: ${command}`);
}

function resolveRuntimeCommand(options) {
  const opts = options || {};
  const command = String(opts.command || opts.defaultCommand || "").trim();
  const source = String(opts.source || "default").trim() || "default";
  const env = opts.env || process.env;
  const displayName = opts.displayName || opts.runtime || "Runtime command";
  if (!command) return notFoundResult(command, source, displayName);

  if (source !== "default") {
    return resolveExplicitCommand(command, source, opts);
  }

  if (hasPathSeparator(command)) {
    const resolved = executableCandidate(command, wrapperDirSet(opts.wrapperDirsToSkip));
    if (resolved) return { ok: true, command: resolved, requestedCommand: command, source: "default" };
    return notFoundResult(command, source, displayName);
  }

  const fromPath = findInPath(command, env, opts.wrapperDirsToSkip);
  if (fromPath) return { ok: true, command: fromPath, requestedCommand: command, source: "path" };

  const fromSearchPath = findInSearchPaths(opts.searchPaths, opts.wrapperDirsToSkip);
  if (fromSearchPath) return { ok: true, command: fromSearchPath, requestedCommand: command, source: "search-path" };

  if (opts.loginShell !== false) {
    const fromShell = resolveViaLoginShell([command], opts);
    if (fromShell?.command) {
      return { ok: true, command: fromShell.command, requestedCommand: command, source: "login-shell", shell: fromShell.shell };
    }
  }

  return notFoundResult(command, source, displayName);
}

function firstNonEmptyLine(text) {
  for (const line of String(text || "").split(/\r?\n/)) {
    const trimmed = line.trim();
    if (trimmed) return trimmed;
  }
  return "";
}

function probeRuntimeCommandVersion(command, options) {
  const opts = options || {};
  const args = opts.args || ["--version"];
  const result = spawnSync(command, args, {
    env: opts.env || process.env,
    timeout: opts.timeoutMs || DEFAULT_VERSION_TIMEOUT_MS,
    maxBuffer: 64 * 1024,
    encoding: "utf8"
  });
  if (result.error) {
    return {
      ok: false,
      reason: "RuntimeCommandInvalid",
      message: `Runtime command version probe failed: ${result.error.message}`
    };
  }
  if (result.status !== 0) {
    return {
      ok: false,
      reason: "RuntimeCommandInvalid",
      message: `Runtime command version probe exited with status ${result.status}`
    };
  }
  return {
    ok: true,
    version: firstNonEmptyLine(`${result.stdout || ""}\n${result.stderr || ""}`)
  };
}

module.exports = {
  findInPath,
  findInSearchPaths,
  hasPathSeparator,
  isExecutable,
  probeRuntimeCommandVersion,
  resolveRuntimeCommand,
  resolveViaLoginShell
};
