#!/usr/bin/env node
"use strict";

const { decodeBootstrapToken, readBootstrapTokenFile } = require("./bootstrap");
const { exchangeEdgeToken, requestSts, reportHeartbeat } = require("./controller");
const { loadRuntimeConfig } = require("./runtime-config");
const { logEvent } = require("./log");
const { modelConfigLogFields, stopModelProxy } = require("./model-config");
const { probeRuntimeCommandVersion, resolveRuntimeCommand } = require("./command-resolver");
const { cleanupLegacySensitiveState, mkdirp, writeStatus } = require("./status");

function commandExists(command) {
  return resolveRuntimeCommand({
    command,
    source: command && (command.includes("/") || command.includes("\\")) ? "arg" : "default",
    searchPaths: [],
    loginShell: false
  }).ok;
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function closeServer(server) {
  return new Promise(resolve => {
    if (!server || typeof server.close !== "function") {
      resolve();
      return;
    }
    const timer = setTimeout(resolve, 1000);
    try {
      server.close(() => {
        clearTimeout(timer);
        resolve();
      });
    } catch {
      clearTimeout(timer);
      resolve();
    }
  });
}

function installSignalCleanup(cleanup) {
  let running = false;
  const handler = () => {
    if (running) return;
    running = true;
    Promise.resolve()
      .then(cleanup)
      .finally(() => process.exit(0));
  };
  process.once("SIGINT", handler);
  process.once("SIGTERM", handler);
  return () => {
    process.removeListener("SIGINT", handler);
    process.removeListener("SIGTERM", handler);
  };
}

function workerOnce(args) {
  return Boolean(args.once || process.env.TEAMHARNESS_WORKER_ONCE === "1");
}

function commandConfig(args, adapter) {
  const config = typeof adapter.commandConfig === "function" ? adapter.commandConfig(args) : {};
  return {
    runtime: args.runtime,
    displayName: config.displayName || args.runtime,
    commandName: config.commandName || "runtimeCommand",
    command: config.command || adapter.command(args),
    source: config.source || args[`${config.commandName || "runtimeCommand"}Source`] || args.runtimeCommandSource || "default",
    searchPaths: config.searchPaths || [],
    wrapperDirsToSkip: config.wrapperDirsToSkip || [],
    versionArgs: config.versionArgs || ["--version"],
    env: config.env || process.env,
    validateVersion: config.validateVersion
  };
}

function runtimeCommandStatus(metadata, extra) {
  return {
    ...(extra || {}),
    runtimeCommand: metadata
  };
}

function commandWaitingReason(result, adapter) {
  return result.reason === "RuntimeCommandInvalid" ? "RuntimeCommandInvalid" : adapter.commandMissingReason;
}

function commandWaitingMessage(result, args, adapter) {
  return result.reason === "RuntimeCommandInvalid" ? result.message : adapter.commandMissingMessage(args);
}

function resolveWorkerCommand(args, adapter) {
  const config = commandConfig(args, adapter);
  const resolved = resolveRuntimeCommand(config);
  if (!resolved.ok) {
    return { ok: false, config, result: resolved };
  }

  const version = probeRuntimeCommandVersion(resolved.command, {
    args: config.versionArgs,
    env: config.env
  });
  if (!version.ok) {
    return { ok: false, config, result: version };
  }
  const versionError = typeof config.validateVersion === "function"
    ? config.validateVersion(version.version || "")
    : "";
  if (versionError) {
    return {
      ok: false,
      config,
      result: {
        ok: false,
        reason: "RuntimeCommandInvalid",
        message: String(versionError),
        version: version.version || ""
      }
    };
  }

  args[config.commandName] = resolved.command;
  args.runtimeCommandMetadata = {
    name: config.commandName,
    requestedCommand: resolved.requestedCommand || config.command,
    command: resolved.command,
    source: resolved.source,
    version: version.version || ""
  };
  return { ok: true, config, result: resolved, version };
}

async function runWorkerMain(argv, adapter) {
  const args = adapter.parseArgs(argv);
  mkdirp(args.stateDir);
  cleanupLegacySensitiveState(args);
  logEvent("info", "worker_starting", {
    runtime: args.runtime,
    stateDir: args.stateDir,
    workDir: args.workDir,
    modelConfigMode: args.modelConfigMode,
    requestedMode: args.modelConfigMode,
    requestedModelConfigMode: args.modelConfigMode,
    maxConcurrentTasks: args.maxConcurrentTasks
  });

  let bootstrap;
  try {
    bootstrap = decodeBootstrapToken(readBootstrapTokenFile(args));
  } catch (error) {
    writeStatus(args, "Failed", error.reason || "InvalidBootstrapToken", error.message);
    logEvent("error", "bootstrap_token_invalid", { runtime: args.runtime, error });
    throw error;
  }
  Object.defineProperty(args, "edgeBootstrap", {
    value: bootstrap,
    writable: true,
    configurable: true,
    enumerable: false
  });

  if (!args.workDir) {
    writeStatus(args, "Failed", "MissingWorkDir", "work dir is required; pass --work-dir");
    logEvent("error", "worker_workdir_missing", { runtime: args.runtime });
    throw new Error("work dir is required; pass --work-dir");
  }
  mkdirp(args.workDir);

  let commandMissingLogged = false;
  let commandReady = resolveWorkerCommand(args, adapter);
  while (!commandReady.ok) {
    const reason = commandWaitingReason(commandReady.result, adapter);
    const message = commandWaitingMessage(commandReady.result, args, adapter);
    writeStatus(args, "Waiting", reason, message, runtimeCommandStatus({
      requestedCommand: commandReady.config.command,
      source: commandReady.config.source,
      reason: commandReady.result.reason,
      ...(commandReady.result.version ? { version: commandReady.result.version } : {})
    }));
    if (!commandMissingLogged) {
      commandMissingLogged = true;
      logEvent("warn", "worker_command_missing", {
        runtime: args.runtime,
        command: commandReady.config.command,
        commandSource: commandReady.config.source,
        reason
      });
    }
    if (workerOnce(args)) {
      return;
    }
    await wait(Math.max(1, args.intervalSeconds) * 1000);
    commandReady = resolveWorkerCommand(args, adapter);
  }
  logEvent("info", "runtime_command_resolved", {
    runtime: args.runtime,
    command: args.runtimeCommandMetadata.command,
    commandSource: args.runtimeCommandMetadata.source,
    version: args.runtimeCommandMetadata.version
  });

  const edge = await exchangeEdgeToken(args, bootstrap);
  logEvent("info", "edge_token_exchanged", {
    runtime: args.runtime,
    workerName: edge.workerName,
    workerResourceName: edge.workerResourceName,
    controllerUrl: args.controllerUrl
  });
  const sts = await requestSts(args, edge);
  logEvent("info", "sts_credentials_ready", {
    runtime: args.runtime,
    bucket: sts.oss_bucket,
    endpoint: sts.oss_endpoint
  });
  const runtimeState = await loadRuntimeConfig(args, edge, sts);
  runtimeState.sts = sts;
  runtimeState.args = args;
  runtimeState.edge = edge;
  args.runtimeState = runtimeState;
  if (typeof adapter.afterRuntimeLoaded === "function") {
    await adapter.afterRuntimeLoaded(args, edge, runtimeState);
  }
  runtimeState.lastRuntimeRefreshAt = Date.now();
  if (typeof adapter.syncModelRuntime === "function") {
    try {
      await adapter.syncModelRuntime(args, edge, runtimeState);
    } catch (error) {
      writeStatus(args, "Failed", error.reason || "ModelConfigModeInvalid", error.message);
      throw error;
    }
  }
  await adapter.applyAgentPackage(args, runtimeState, runtimeState.sts);
  if (typeof adapter.syncModelRuntime !== "function" && typeof adapter.startModelProxy === "function") {
    const modelProxy = await adapter.startModelProxy(args, edge, runtimeState);
    logEvent("info", modelProxy ? "model_proxy_started" : "model_proxy_disabled", {
      ...modelConfigLogFields(args, edge, runtimeState),
      endpoint: modelProxy?.endpoint || ""
    });
  }
  const broker = await adapter.startBroker(args, edge, sts, runtimeState);
  if (typeof adapter.afterBrokerStarted === "function") {
    await adapter.afterBrokerStarted(args, edge, runtimeState);
  }
  adapter.applyGlobalIntegrations(args, edge, runtimeState);

  const cleanupRuntime = async () => {
    logEvent("info", "worker_cleanup_started", { runtime: args.runtime });
    if (args.modelProxy?.server) {
      await stopModelProxy(args, "worker-cleanup", modelConfigLogFields(args, edge, runtimeState));
    }
    await closeServer(broker);
    adapter.cleanupBrokerFiles(args);
    adapter.cleanupGlobalIntegrations(args);
    logEvent("info", "worker_cleanup_finished", { runtime: args.runtime });
  };
  const removeSignalCleanup = installSignalCleanup(cleanupRuntime);
  await reportHeartbeat(args, edge);

  if (workerOnce(args)) {
    removeSignalCleanup();
    await cleanupRuntime();
    return;
  }

  writeStatus(args, "Running", "WorkerReady", adapter.readyMessage, {
    workerName: edge.workerName,
    workerResourceName: edge.workerResourceName,
    runtimeCommand: args.runtimeCommandMetadata
  });
  logEvent("info", "worker_ready", {
    runtime: args.runtime,
    workerName: edge.workerName,
    workerResourceName: edge.workerResourceName,
    matrixHomeserver: edge.matrixHomeserver
  });
  const stopPeriodicTasks = adapter.startRemotePeriodicTasks(args, edge, runtimeState);
  try {
    await adapter.matrixLoop(args, edge, runtimeState);
  } finally {
    stopPeriodicTasks();
    removeSignalCleanup();
    await cleanupRuntime();
  }
}

module.exports = {
  commandExists,
  wait,
  closeServer,
  installSignalCleanup,
  runWorkerMain
};
