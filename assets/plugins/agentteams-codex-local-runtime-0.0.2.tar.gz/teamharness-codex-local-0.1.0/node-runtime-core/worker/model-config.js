#!/usr/bin/env node
"use strict";

const crypto = require("crypto");
const { logEvent } = require("./log");
const { combineGatewayUrl } = require("./model-proxy");

const MODEL_CONFIG_MODES = ["runtime-auto", "managed-runtime", "managed-global", "native-config"];

function normalizeModelConfigMode(value, fallback) {
  const normalized = String(value === undefined || value === null || value === "" ? (fallback || "runtime-auto") : value)
    .trim()
    .toLowerCase();
  if (MODEL_CONFIG_MODES.includes(normalized)) return normalized;
  throw new Error(`model config mode must be runtime-auto, managed-runtime, managed-global, or native-config, got ${value}`);
}

function safeUrlHost(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  try {
    return new URL(raw).host;
  } catch {
    return "invalid-url";
  }
}

function runtimeModelFields(edge, runtimeState) {
  const model = runtimeState?.runtime?.desired?.model || {};
  const rawGatewayUrl = String(model.gatewayUrl || "").trim();
  const baseUrl = combineGatewayUrl(edge?.modelGatewayUrl, rawGatewayUrl);
  const apiKey = String(model.gatewayKey || "").trim();
  const modelName = String(model.model || "").trim();
  const providerId = String(model.providerId || "").trim();
  const intent = Boolean(modelName || providerId || rawGatewayUrl || apiKey);
  return {
    intent,
    complete: Boolean(modelName && baseUrl && apiKey),
    model: modelName,
    providerId,
    baseUrl,
    baseUrlHost: safeUrlHost(baseUrl),
    gatewayHost: safeUrlHost(rawGatewayUrl),
    hasGatewayUrl: Boolean(rawGatewayUrl),
    hasGatewayKey: Boolean(apiKey),
    hasModel: Boolean(modelName),
    hasProviderId: Boolean(providerId),
    signature: crypto.createHash("sha256").update(JSON.stringify({
      model: modelName,
      providerId,
      baseUrl,
      apiKey
    })).digest("hex")
  };
}

function modelConfigLogFields(args, edge, runtimeState, extra) {
  const requested = normalizeModelConfigMode(args?.modelConfigMode);
  const fields = runtimeModelFields(edge, runtimeState);
  const effective = String(args?.effectiveModelConfigMode || runtimeState?.modelConfig?.effectiveMode || "").trim();
  return {
    runtime: args?.runtime || "",
    workerName: edge?.workerName || "",
    requestedMode: requested,
    effectiveMode: effective,
    requestedModelConfigMode: requested,
    effectiveModelConfigMode: effective,
    modelConfigMode: effective || requested,
    runtimeDigest: runtimeState?.digest || "",
    managedModelIntent: fields.intent,
    managedModelComplete: fields.complete,
    managedModelName: fields.model,
    managedModelProviderId: fields.providerId,
    managedModelGatewayHost: fields.baseUrlHost,
    managedModelHasGatewayKey: fields.hasGatewayKey,
    ...(extra || {})
  };
}

function modeError(reason, message, fields) {
  const error = new Error(message);
  error.reason = reason;
  Object.assign(error, fields || {});
  return error;
}

function normalizeCapabilities(capabilities) {
  const caps = capabilities || {};
  return {
    managedRuntime: Boolean(caps.managedRuntime),
    managedGlobal: Boolean(caps.managedGlobal),
    runtimeAutoMode: caps.runtimeAutoMode === "native-only" ? "native-only" : "auto"
  };
}

function resolveEffectiveModelConfigMode(args, edge, runtimeState, options) {
  const requested = normalizeModelConfigMode(args?.modelConfigMode);
  const caps = normalizeCapabilities(options?.capabilities);
  const fields = runtimeModelFields(edge, runtimeState);
  const runtime = args?.runtime || options?.runtime || "worker";

  if (requested === "native-config") {
    return { requested, effective: "native-config", reason: fields.intent ? "ExplicitNativeConfig" : "NativeConfig", fields };
  }

  if (requested === "runtime-auto") {
    if (caps.runtimeAutoMode === "native-only") {
      return { requested, effective: "native-config", reason: fields.intent ? "RuntimeAutoNativeOnly" : "RuntimeAutoNoManagedIntent", fields };
    }
    if (!fields.intent) {
      return { requested, effective: "native-config", reason: "RuntimeAutoNoManagedIntent", fields };
    }
    if (!fields.complete) {
      throw modeError(
        "ManagedRuntimeModelConfigMissing",
        "runtime-auto managed model config requires desired.model.model, gatewayUrl (or bootstrap gateway), and gatewayKey",
        { requestedMode: requested, effectiveMode: "managed-runtime" }
      );
    }
    if (!caps.managedRuntime) {
      throw modeError(
        "UnsupportedModelConfigMode",
        `${runtime} does not support runtime-auto managed model config`,
        { requestedMode: requested, effectiveMode: "managed-runtime" }
      );
    }
    return { requested, effective: "managed-runtime", reason: "RuntimeAutoManagedRuntime", fields };
  }

  if (requested === "managed-runtime") {
    if (!caps.managedRuntime) {
      throw modeError(
        "UnsupportedModelConfigMode",
        `${runtime} does not support managed-runtime model config`,
        { requestedMode: requested, effectiveMode: requested }
      );
    }
    if (!fields.complete) {
      throw modeError(
        "ManagedRuntimeModelConfigMissing",
        "managed-runtime requires desired.model.model, gatewayUrl (or bootstrap gateway), and gatewayKey",
        { requestedMode: requested, effectiveMode: requested }
      );
    }
    return { requested, effective: "managed-runtime", reason: "ExplicitManagedRuntime", fields };
  }

  if (!caps.managedGlobal) {
    throw modeError(
      "UnsupportedModelConfigMode",
      `${runtime} does not support managed-global model config`,
      { requestedMode: requested, effectiveMode: requested }
    );
  }
  if (!fields.complete) {
    throw modeError(
      "ManagedRuntimeModelConfigMissing",
      "managed-global requires desired.model.model, gatewayUrl (or bootstrap gateway), and gatewayKey",
      { requestedMode: requested, effectiveMode: requested }
    );
  }
  return { requested, effective: "managed-global", reason: "ExplicitManagedGlobal", fields };
}

function usesNativeModelConfig(args) {
  const effective = String(args?.effectiveModelConfigMode || "").trim().toLowerCase();
  if (effective) return effective === "native-config";
  const requested = normalizeModelConfigMode(args?.modelConfigMode);
  return requested === "native-config" || requested === "runtime-auto";
}

function usesManagedRuntimeModel(args) {
  return String(args?.effectiveModelConfigMode || args?.modelConfigMode || "").trim().toLowerCase() === "managed-runtime";
}

function usesManagedModelConfig(args) {
  return !usesNativeModelConfig(args);
}

function closeServer(server) {
  return new Promise((resolve, reject) => {
    if (!server || typeof server.close !== "function") {
      resolve();
      return;
    }
    let done = false;
    const finish = error => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      if (error) reject(error);
      else resolve();
    };
    const timer = setTimeout(() => finish(), 1000);
    if (typeof timer.unref === "function") timer.unref();
    try {
      server.close(finish);
    } catch (error) {
      finish(error);
    }
  });
}

async function stopModelProxy(args, reason, fields) {
  const proxy = args?.modelProxy;
  if (!proxy) return;
  const logFields = {
    ...fields,
    proxyKind: proxy.kind || "",
    endpoint: proxy.endpoint || "",
    reason
  };
  logEvent("info", "model_proxy_stopping", logFields);
  try {
    await closeServer(proxy.server);
    logEvent("info", "model_proxy_stopped", logFields);
  } catch (error) {
    logEvent("warn", "model_proxy_stop_failed", { ...logFields, error });
  } finally {
    delete args.modelProxy;
  }
}

function logAdapterModelConfig(args, summary, result) {
  const fields = result.fields;
  const applied = result.effective !== "native-config";
  const event = applied ? "adapter_model_config_applied" : "adapter_model_config_skipped";
  const key = [
    event,
    result.requested,
    result.effective,
    result.reason,
    fields.intent,
    fields.signature
  ].join("|");
  if (args.lastAdapterModelConfigLogKey === key) return;
  args.lastAdapterModelConfigLogKey = key;
  logEvent("info", event, {
    ...summary,
    reason: result.reason,
    managedModelIntent: fields.intent,
    managedModelComplete: fields.complete
  });
}

async function syncModelRuntime(args, edge, runtimeState, options) {
  const opts = options || {};
  const runtime = opts.runtime || args.runtime || "";
  const proxyKind = opts.proxyKind || `${runtime}-model-proxy`;
  const previousEffective = String(args.effectiveModelConfigMode || "");
  const previousSignature = String(args.modelConfigSignature || "");
  let result;
  try {
    result = resolveEffectiveModelConfigMode(args, edge, runtimeState, opts);
  } catch (error) {
    const summary = modelConfigLogFields(args, edge, runtimeState, {
      reason: error.reason || "ModelConfigModeInvalid",
      requestedMode: error.requestedMode || normalizeModelConfigMode(args.modelConfigMode),
      effectiveMode: error.effectiveMode || "",
      requestedModelConfigMode: error.requestedMode || normalizeModelConfigMode(args.modelConfigMode),
      effectiveModelConfigMode: error.effectiveMode || "",
      modelConfigMode: error.effectiveMode || normalizeModelConfigMode(args.modelConfigMode)
    });
    logEvent("error", "model_config_mode_invalid", { ...summary, error });
    if (args.modelProxy) {
      await stopModelProxy(args, error.reason || "ModelConfigModeInvalid", summary);
    }
    throw error;
  }

  args.requestedModelConfigMode = result.requested;
  args.effectiveModelConfigMode = result.effective;
  args.modelConfigSignature = result.fields.signature;
  runtimeState.modelConfig = {
    requestedMode: result.requested,
    effectiveMode: result.effective,
    reason: result.reason,
    digest: runtimeState.digest || "",
    managedModelIntent: result.fields.intent,
    managedModelComplete: result.fields.complete,
    managedModelName: result.fields.model,
    managedModelProviderId: result.fields.providerId,
    managedModelGatewayHost: result.fields.baseUrlHost,
    managedModelHasGatewayKey: result.fields.hasGatewayKey
  };
  const summary = modelConfigLogFields(args, edge, runtimeState, { reason: result.reason });
  logEvent("info", "model_config_mode_resolved", summary);
  if (previousEffective && previousEffective !== result.effective) {
    logEvent("info", "model_config_mode_changed", {
      ...summary,
      previousEffectiveModelConfigMode: previousEffective
    });
  }
  if (opts.exposesModelCredentials) {
    const enabled = result.effective !== "native-config";
    const brokerKey = `${enabled}|${runtimeState.digest || ""}|${result.effective}`;
    if (args.lastModelBrokerModeLogKey !== brokerKey) {
      args.lastModelBrokerModeLogKey = brokerKey;
      logEvent("info", "model_broker_mode_updated", {
        ...summary,
        modelCredentialsEnabled: enabled,
        trigger: "model-config-sync"
      });
    }
  }
  logAdapterModelConfig(args, summary, result);

  const needsProxy = result.effective !== "native-config" && typeof opts.startModelProxy === "function";
  if (!needsProxy) {
    if (args.modelProxy) {
      await stopModelProxy(args, result.reason, summary);
    }
    return result;
  }

  if (args.modelProxy?.server && args.modelProxy?.endpoint) {
    args.modelProxy.kind = args.modelProxy.kind || proxyKind;
    logEvent("info", "model_proxy_reused", {
      ...summary,
      proxyKind: args.modelProxy.kind,
      endpoint: args.modelProxy.endpoint,
      modelConfigChanged: previousSignature && previousSignature !== result.fields.signature
    });
    return result;
  }

  logEvent("info", "model_proxy_starting", { ...summary, proxyKind });
  try {
    const proxy = await opts.startModelProxy(args, edge, runtimeState);
    if (!proxy || !proxy.endpoint) {
      throw modeError("ManagedRuntimeModelProxyMissing", "managed model config requires a local model proxy");
    }
    proxy.kind = proxy.kind || proxyKind;
    args.modelProxy = proxy;
    logEvent("info", "model_proxy_started", {
      ...summary,
      proxyKind: proxy.kind,
      endpoint: proxy.endpoint
    });
    return result;
  } catch (error) {
    logEvent("error", "model_proxy_start_failed", { ...summary, proxyKind, error });
    throw error;
  }
}

module.exports = {
  MODEL_CONFIG_MODES,
  normalizeModelConfigMode,
  runtimeModelFields,
  modelConfigLogFields,
  resolveEffectiveModelConfigMode,
  usesNativeModelConfig,
  usesManagedRuntimeModel,
  usesManagedModelConfig,
  stopModelProxy,
  syncModelRuntime
};
