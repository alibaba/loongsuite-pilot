#!/usr/bin/env bash
set -euo pipefail

default_root="${PILOT_DATA:-${HOME}/.local/share/teamharness}"
target_dir="${TEAMHARNESS_CODEX_PLUGIN_DIR:-${TEAMHARNESS_CODEXCLI_PLUGIN_DIR:-${default_root}/plugins/teamharness-codex-plugin}}"
rm -rf "${target_dir}"

if [ -n "${TEAMHARNESS_INSTALL_LOG:-}" ]; then
  mkdir -p "$(dirname "${TEAMHARNESS_INSTALL_LOG}")"
  printf '{"event":"uninstall","runtime":"codex","pluginDir":"%s"}\n' "${target_dir}" >> "${TEAMHARNESS_INSTALL_LOG}"
fi
