#!/usr/bin/env bash
set -euo pipefail

bundle_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
default_root="${PILOT_DATA:-${HOME}/.local/share/teamharness}"
target_dir="${TEAMHARNESS_CODEX_PLUGIN_DIR:-${TEAMHARNESS_CODEXCLI_PLUGIN_DIR:-${default_root}/plugins/teamharness-codex-plugin}}"
tmp_dir="${target_dir}.tmp"

rm -rf "${tmp_dir}"
mkdir -p "${tmp_dir}"
(cd "${bundle_dir}/teamharness-codex-plugin" && tar -cf - .) | (cd "${tmp_dir}" && tar -xf -)
rm -rf "${target_dir}"
mv "${tmp_dir}" "${target_dir}"

if [ -n "${TEAMHARNESS_INSTALL_LOG:-}" ]; then
  mkdir -p "$(dirname "${TEAMHARNESS_INSTALL_LOG}")"
  printf '{"event":"install","runtime":"codex","pluginDir":"%s"}\n' "${target_dir}" >> "${TEAMHARNESS_INSTALL_LOG}"
fi
