#!/usr/bin/env node
"use strict";

const crypto = require("crypto");
const fs = require("fs");
const path = require("path");

function mkdirp(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

function writeJson(file, payload, mode) {
  mkdirp(path.dirname(file));
  const targetMode = mode || 0o600;
  const nonce = crypto.randomBytes(16).toString("hex");
  const tmp = path.join(path.dirname(file), `.${path.basename(file)}.${process.pid}.${nonce}.tmp`);
  let temporaryCreated = false;
  try {
    fs.writeFileSync(tmp, `${JSON.stringify(payload, null, 2)}\n`, { mode: targetMode, flag: "wx" });
    temporaryCreated = true;
    fs.renameSync(tmp, file);
    temporaryCreated = false;
  } finally {
    if (temporaryCreated) removeFileQuietly(tmp);
  }
  try {
    fs.chmodSync(file, targetMode);
  } catch {
    // Best effort; the write already succeeded.
  }
}

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return fallback;
  }
}

function runtimeId(args) {
  return String(args.runtime || args.runtimeId || "remote-node");
}

function writeStatus(args, phase, reason, message, extra) {
  const payload = {
    phase,
    reason,
    message,
    updatedAt: new Date().toISOString(),
    runtime: runtimeId(args),
    instanceId: args.instanceId || "",
    ...(extra || {})
  };
  writeJson(path.join(args.stateDir, "status.json"), payload);
}

function pluginStatePath(args, pluginName) {
  const name = String(pluginName || "").trim();
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(name)) {
    throw new Error(`invalid plugin name: ${name}`);
  }
  const stateDir = path.resolve(String(args?.stateDir || ""));
  if (!args?.stateDir) throw new Error("stateDir is required");
  const instanceDir = args.instanceDir ? path.resolve(args.instanceDir) : path.dirname(stateDir);
  return path.join(instanceDir, "plugin-state", name, "state.json");
}

function writePluginState(args, pluginName, payload) {
  const file = pluginStatePath(args, pluginName);
  const dir = path.dirname(file);
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  fs.chmodSync(dir, 0o700);
  writeJson(file, {
    ...(payload || {}),
    updatedAt: new Date().toISOString()
  }, 0o600);
  return file;
}

function pluginResolverStatePath(args) {
  const stateDir = path.resolve(String(args?.stateDir || ""));
  if (!args?.stateDir) throw new Error("stateDir is required");
  const instanceDir = args.instanceDir ? path.resolve(args.instanceDir) : path.dirname(stateDir);
  return path.join(instanceDir, "plugin-state", "_resolver", "state.json");
}

function writePluginResolverState(args, payload) {
  const file = pluginResolverStatePath(args);
  const dir = path.dirname(file);
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  fs.chmodSync(dir, 0o700);
  writeJson(file, {
    scope: "resolver",
    ...(payload || {}),
    updatedAt: new Date().toISOString()
  }, 0o600);
  return file;
}

function clearPluginResolverState(args) {
  const file = pluginResolverStatePath(args);
  removeFileQuietly(file);
  try {
    fs.rmdirSync(path.dirname(file));
  } catch {
    // The resolver directory can be absent or contain diagnostic artifacts.
  }
}

function removeFileQuietly(file) {
  try {
    fs.rmSync(file, { force: true });
  } catch {
    // Best-effort cleanup only.
  }
}

function cleanupLegacySensitiveState(args) {
  for (const name of ["edge-token.json", "sts.json", "runtime-state.json", "credential-token", "credential-broker.json"]) {
    removeFileQuietly(path.join(args.stateDir, name));
  }
}

function positiveIntervalSeconds(value, fallback) {
  const number = Number(value);
  return Number.isFinite(number) && number >= 0 ? number : fallback;
}

function stsRefreshRequired(sts, nowSeconds) {
  if (!sts || typeof sts !== "object") return true;
  const issuedAt = Number(sts.issuedAt || 0);
  const expiresIn = Number(sts.expires_in_sec || sts.expiresInSeconds || 0);
  if (!issuedAt || !expiresIn) return true;
  const now = nowSeconds || Math.floor(Date.now() / 1000);
  const refreshAt = Math.min(issuedAt + expiresIn * 0.8, issuedAt + Math.max(expiresIn - 300, 0));
  return now >= refreshAt;
}

module.exports = {
  mkdirp,
  writeJson,
  readJson,
  writeStatus,
  pluginStatePath,
  writePluginState,
  pluginResolverStatePath,
  writePluginResolverState,
  clearPluginResolverState,
  removeFileQuietly,
  cleanupLegacySensitiveState,
  positiveIntervalSeconds,
  stsRefreshRequired
};
