#!/usr/bin/env node
"use strict";

const fs = require("fs");
const { spawnSync } = require("child_process");

const CONTEXT_TEAMHARNESS_KEYS = new Set([
  "TEAMHARNESS_TEAM_NAME",
  "TEAMHARNESS_MEMBER_NAME",
  "TEAMHARNESS_ROLE",
  "TEAMHARNESS_RUNTIME_CONFIG",
  "TEAMHARNESS_SHARED_DIR"
]);

const SHELL_ENV_TIMEOUT_MS = 3000;
const SHELL_ENV_MARKER = "__TEAMHARNESS_NATIVE_ENV_BEGIN__";
const NATIVE_ENV_DIAGNOSTICS = Symbol("teamharnessNativeEnvDiagnostics");

function cleanManagedEnv(source) {
  const env = {};
  for (const [key, value] of Object.entries(source || {})) {
    if (key.startsWith("HICLAW_")) continue;
    if (key.startsWith("AGENTTEAM_")) continue;
    if (key.startsWith("AGENTTEAMS_")) continue;
    if (CONTEXT_TEAMHARNESS_KEYS.has(key)) continue;
    env[key] = value;
  }
  return env;
}

function agentteamsEnv(options) {
  const opts = options || {};
  const edge = opts.edge || {};
  const runtimeState = opts.runtimeState || {};
  const member = runtimeState.runtime?.member || {};
  return {
    AGENTTEAMS_WORKER_NAME: String(edge.workerName || member.runtimeName || "").trim()
  };
}

function buildManagedRuntimeEnv(baseEnv, options) {
  const opts = options || {};
  const env = cleanManagedEnv(baseEnv);
  for (const [key, value] of Object.entries(opts.runtimeEnv || {})) {
    env[key] = String(value);
  }
  Object.assign(env, agentteamsEnv(opts));
  return env;
}

function sourceScriptForShell(shellPath) {
  const shell = String(shellPath || "").split(/[\\/]/).pop() || "";
  if (shell.includes("zsh")) {
    return "for f in \"$HOME/.zprofile\" \"$HOME/.zshrc\" \"$HOME/.profile\"; do [ -f \"$f\" ] && . \"$f\" >/dev/null 2>/dev/null || true; done";
  }
  if (shell.includes("bash")) {
    return "for f in \"$HOME/.bash_profile\" \"$HOME/.bashrc\" \"$HOME/.profile\"; do [ -f \"$f\" ] && . \"$f\" >/dev/null 2>/dev/null || true; done";
  }
  return "[ -f \"$HOME/.profile\" ] && . \"$HOME/.profile\" >/dev/null 2>/dev/null || true";
}

function resolveShell(env) {
  const explicit = String(env?.SHELL || "").trim();
  if (explicit && fs.existsSync(explicit)) return explicit;
  for (const candidate of ["/bin/bash", "/usr/bin/bash", "/bin/zsh", "/bin/sh"]) {
    if (fs.existsSync(candidate)) return candidate;
  }
  return "";
}

function shellProfileResult(status, shell, env, error) {
  return {
    env: env || {},
    diagnostics: {
      status,
      shell: shell || "",
      error: error || ""
    }
  };
}

function readShellProfileEnvResult(baseEnv) {
  const env = { ...(baseEnv || {}) };
  const shell = resolveShell(env);
  if (!shell) return shellProfileResult("skipped", "", {});

  const script = [
    "set +e",
    sourceScriptForShell(shell),
    `printf '${SHELL_ENV_MARKER}\\0'`,
    "env -0"
  ].join("\n");

  const result = spawnSync(shell, ["-lc", script], {
    env,
    timeout: SHELL_ENV_TIMEOUT_MS,
    maxBuffer: 1024 * 1024
  });
  if (result.error) {
    const status = result.error.code === "ETIMEDOUT" ? "timeout" : "failed";
    return shellProfileResult(status, shell, {}, result.error.message);
  }
  if (result.status !== 0 || !result.stdout) {
    return shellProfileResult("failed", shell, {}, `shell exited with status ${result.status}`);
  }

  const stdout = Buffer.isBuffer(result.stdout) ? result.stdout : Buffer.from(String(result.stdout));
  const marker = Buffer.from(`${SHELL_ENV_MARKER}\0`);
  const markerOffset = stdout.indexOf(marker);
  if (markerOffset < 0) return shellProfileResult("failed", shell, {}, "shell env marker not found");

  const payload = stdout.subarray(markerOffset + marker.length).toString("utf8");
  const out = {};
  for (const entry of payload.split("\0")) {
    if (!entry) continue;
    const index = entry.indexOf("=");
    if (index <= 0) continue;
    const key = entry.slice(0, index);
    if (!key) continue;
    out[key] = entry.slice(index + 1);
  }
  return shellProfileResult("success", shell, out);
}

function readShellProfileEnv(baseEnv) {
  return readShellProfileEnvResult(baseEnv).env;
}

function buildNativeConfigRuntimeEnv(baseEnv, options) {
  const opts = options || {};
  const env = buildManagedRuntimeEnv(baseEnv, opts);
  const profile = readShellProfileEnvResult(env);
  let importedKeys = 0;
  for (const [key, value] of Object.entries(cleanManagedEnv(profile.env))) {
    if (!Object.prototype.hasOwnProperty.call(env, key)) {
      env[key] = value;
      importedKeys += 1;
    }
  }
  for (const [key, value] of Object.entries(opts.runtimeEnv || {})) {
    env[key] = String(value);
  }
  Object.assign(env, agentteamsEnv(opts));
  Object.defineProperty(env, NATIVE_ENV_DIAGNOSTICS, {
    value: {
      ...profile.diagnostics,
      importedKeys
    },
    enumerable: false
  });
  return env;
}

function nativeEnvDiagnostics(env) {
  return env?.[NATIVE_ENV_DIAGNOSTICS] || null;
}

module.exports = {
  agentteamsEnv,
  buildNativeConfigRuntimeEnv,
  buildManagedRuntimeEnv,
  cleanManagedEnv,
  nativeEnvDiagnostics
};
