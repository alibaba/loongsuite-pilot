#!/usr/bin/env node
"use strict";

const fs = require("fs");
const path = require("path");
const { logEvent } = require("./log");
const { writeJson, writeStatus } = require("./status");
const { ossPut, ossDelete, ossList } = require("./storage-oss");

const backgroundSyncs = new Map();
const VIEW_REQUEST_TIMEOUT_MS = 30_000;
const VIEW_STOP_GRACE_MS = 30_000;

function abortError() {
  const error = new Error("Agent Package View sync aborted");
  error.name = "AbortError";
  return error;
}

function throwIfAborted(signal) {
  if (signal?.aborted) throw abortError();
}

function isAbortError(error, signal) {
  return Boolean(signal?.aborted || error?.name === "AbortError");
}

function packageViewBasePrefixes(runtime) {
  const storage = runtime.storage && typeof runtime.storage === "object" ? runtime.storage : {};
  const member = runtime.member && typeof runtime.member === "object" ? runtime.member : {};
  let memberPrefix = String(storage.memberPrefix || "").trim().replace(/^\/+|\/+$/g, "");
  if (!memberPrefix) {
    const runtimeName = String(member.runtimeName || member.name || "").trim();
    if (runtimeName) {
      memberPrefix = `agents/${runtimeName}`;
    }
  }
  if (!memberPrefix) return [];

  const prefixes = [memberPrefix];
  const memberRuntime = String(member.runtime || "").trim().toLowerCase();
  if (["qwenpaw", "remote-managed-local"].includes(memberRuntime) && !memberPrefix.includes("/.qwenpaw/workspaces/default")) {
    prefixes.push(`${memberPrefix}/.qwenpaw/workspaces/default`);
  }
  return Array.from(new Set(prefixes));
}

async function syncPackageFileToView(sts, source, objectKey, options) {
  const signal = options?.signal;
  const timeoutMs = options?.requestTimeoutMs;
  throwIfAborted(signal);
  if (fs.existsSync(source) && fs.statSync(source).isFile()) {
    await ossPut(sts, objectKey, fs.readFileSync(source), { signal, timeoutMs });
    throwIfAborted(signal);
    return true;
  }
  await ossDelete(sts, objectKey, { signal, timeoutMs });
  throwIfAborted(signal);
  return false;
}

async function syncPackageSkillsToView(sts, packageDir, skillsPrefix, options) {
  const signal = options?.signal;
  const timeoutMs = options?.requestTimeoutMs;
  throwIfAborted(signal);
  const existing = await ossList(sts, skillsPrefix, { signal, timeoutMs });
  await Promise.all(existing.map(key => ossDelete(sts, key, { signal, timeoutMs })));
  throwIfAborted(signal);

  const skillsDir = path.join(packageDir, "skills");
  if (!fs.existsSync(skillsDir) || !fs.statSync(skillsDir).isDirectory()) {
    return 0;
  }
  const writes = [];
  const walk = dir => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        walk(full);
      } else if (entry.isFile()) {
        const rel = path.relative(skillsDir, full).split(path.sep).join("/");
        writes.push(ossPut(sts, `${skillsPrefix}${rel}`, fs.readFileSync(full), { signal, timeoutMs }));
      }
    }
  };
  walk(skillsDir);
  await Promise.all(writes);
  throwIfAborted(signal);
  return writes.length;
}

async function syncAgentPackageView(args, runtimeState, packageState, packageDir, sts, options) {
  const signal = options?.signal;
  const requestTimeoutMs = options?.requestTimeoutMs;
  throwIfAborted(signal);
  const runtime = runtimeState.runtime || {};
  const prefixes = options?.prefixes || packageViewBasePrefixes(runtime);
  if (!prefixes.length) {
    throw new Error("runtime storage.memberPrefix is required to sync AgentSpec package view");
  }

  const configDir = path.join(packageDir, "config");
  let totalSkillFiles = 0;
  const writtenContext = [];
  for (const prefix of prefixes) {
    throwIfAborted(signal);
    const prefixStartedAt = Date.now();
    const contextStart = writtenContext.length;
    for (const name of ["SOUL.md", "AGENTS.md"]) {
      if (await syncPackageFileToView(sts, path.join(configDir, name), `${prefix}/${name}`, { signal, requestTimeoutMs })) {
        writtenContext.push(`${prefix}/${name}`);
      }
    }
    const skillFiles = await syncPackageSkillsToView(sts, packageDir, `${prefix}/skills/`, { signal, requestTimeoutMs });
    totalSkillFiles += skillFiles;
    logEvent("info", "agent_package_view_prefix_synced", {
      runtime: args.runtime,
      prefix,
      contextFiles: writtenContext.length - contextStart,
      skillFiles,
      durationMs: Date.now() - prefixStartedAt
    });
  }

  const marker = {
    status: "synced",
    ref: packageState.ref || "",
    digest: packageState.digest || "",
    objectKey: packageState.objectKey || "",
    prefixes,
    contextFiles: writtenContext,
    skillFiles: totalSkillFiles,
    syncedAt: Math.floor(Date.now() / 1000)
  };
  for (const prefix of prefixes) {
    throwIfAborted(signal);
    await ossPut(sts, `${prefix}/.agent-package.json`, `${JSON.stringify(marker, null, 2)}\n`, {
      signal,
      timeoutMs: requestTimeoutMs
    });
  }
  throwIfAborted(signal);
  return marker;
}

function sortedPrefixes(runtimeState) {
  return packageViewBasePrefixes(runtimeState.runtime || {}).slice().sort();
}

function viewSyncIdentity(state, prefixes) {
  return JSON.stringify({
    ref: String(state.ref || ""),
    digest: String(state.digest || ""),
    prefixes: prefixes.slice().sort()
  });
}

function viewSyncMatches(state, prefixes) {
  const viewSync = state.viewSync || {};
  return viewSync.status === "synced" &&
    String(viewSync.ref || "") === String(state.ref || "") &&
    String(viewSync.digest || "") === String(state.digest || "") &&
    JSON.stringify((viewSync.prefixes || []).slice().sort()) === JSON.stringify(prefixes.slice().sort());
}

async function syncAgentPackageViewIfNeeded(args, runtimeState, state, packageDir, sts, options) {
  const signal = options?.signal;
  const requestTimeoutMs = options?.requestTimeoutMs;
  throwIfAborted(signal);
  const prefixes = options?.prefixes || sortedPrefixes(runtimeState);
  if (viewSyncMatches(state, prefixes)) {
    return state;
  }
  const startedAt = Date.now();
  logEvent("info", "agent_package_view_sync_starting", {
    runtime: args.runtime,
    ref: state.ref || "",
    digest: state.digest || "",
    prefixes
  });
  let viewSync;
  try {
    viewSync = await syncAgentPackageView(args, runtimeState, state, packageDir, sts, {
      prefixes,
      signal,
      requestTimeoutMs
    });
    throwIfAborted(signal);
    logEvent("info", "agent_package_view_sync_finished", {
      runtime: args.runtime,
      ref: state.ref || "",
      digest: state.digest || "",
      prefixes: viewSync.prefixes || [],
      contextFiles: Array.isArray(viewSync.contextFiles) ? viewSync.contextFiles.length : 0,
      skillFiles: viewSync.skillFiles || 0,
      durationMs: Date.now() - startedAt
    });
  } catch (error) {
    if (isAbortError(error, signal)) throw (error?.name === "AbortError" ? error : abortError());
    viewSync = {
      status: "failed",
      digest: state.digest || "",
      message: String(error.message || error).slice(0, 500),
      failedAt: Math.floor(Date.now() / 1000)
    };
    logEvent("warn", "agent_package_view_sync_failed", {
      runtime: args.runtime,
      ref: state.ref || "",
      digest: state.digest || "",
      durationMs: Date.now() - startedAt,
      error
    });
  }
  throwIfAborted(signal);
  if (typeof options?.shouldCommit === "function" && !options.shouldCommit()) {
    logEvent("info", "agent_package_view_sync_superseded", {
      runtime: args.runtime,
      ref: state.ref || "",
      digest: state.digest || "",
      prefixes
    });
    return state;
  }
  state.viewSync = viewSync;
  if (viewSync.status === "synced" && options?.writeStatusOnSuccess !== false) {
    writeStatus(args, "Running", "AgentPackageViewSynced", "AgentSpec package view synced");
  }
  writeJson(path.join(args.stateDir, "agent-package-state.json"), state);
  runtimeState.agentPackage = state;
  return state;
}

function syncAgentPackageViewInBackground(args, runtimeState, state, packageDir, sts, options) {
  const viewLease = options?.viewLease;
  let leaseReleased = false;
  const releaseViewLease = () => {
    if (leaseReleased) return;
    leaseReleased = true;
    viewLease?.release?.();
  };
  if (options?.signal?.aborted) {
    releaseViewLease();
    return state;
  }
  const prefixes = sortedPrefixes(runtimeState);
  if (viewSyncMatches(state, prefixes)) {
    releaseViewLease();
    return state;
  }
  const coordinatorKey = path.resolve(args.stateDir);
  let coordinator = backgroundSyncs.get(coordinatorKey);
  if (!coordinator) {
    coordinator = {
      closed: false,
      controller: new AbortController(),
      generation: 0,
      latestIdentity: "",
      latestRun: null,
      tail: Promise.resolve(),
      pending: 0
    };
    backgroundSyncs.set(coordinatorKey, coordinator);
  }
  if (coordinator.closed) {
    releaseViewLease();
    return state;
  }
  const identity = viewSyncIdentity(state, prefixes);
  if (coordinator.latestIdentity === identity && coordinator.latestRun) {
    releaseViewLease();
    return state;
  }

  const generation = ++coordinator.generation;
  coordinator.latestIdentity = identity;
  const isCurrent = () => !coordinator.closed && !options?.signal?.aborted &&
    coordinator.generation === generation && coordinator.latestIdentity === identity;
  const run = coordinator.tail.catch(() => {}).then(async () => {
    if (!isCurrent()) return state;
    return syncAgentPackageViewIfNeeded(args, runtimeState, state, packageDir, sts, {
      prefixes,
      requestTimeoutMs: VIEW_REQUEST_TIMEOUT_MS,
      signal: coordinator.controller.signal,
      shouldCommit: isCurrent,
      writeStatusOnSuccess: false
    });
  });
  coordinator.tail = run;
  coordinator.latestRun = run;
  coordinator.pending += 1;
  const cleanup = () => {
    coordinator.pending -= 1;
    if (coordinator.latestRun === run) coordinator.latestRun = null;
    if (coordinator.tail === run && coordinator.pending === 0) backgroundSyncs.delete(coordinatorKey);
    releaseViewLease();
  };
  run.then(cleanup, cleanup);
  run.catch(error => {
    if (isAbortError(error)) return;
    logEvent("warn", "agent_package_view_sync_background_failed", {
      runtime: args.runtime,
      ref: state.ref || "",
      digest: state.digest || "",
      error
    });
  });
  return state;
}

async function stopAgentPackageViewSync(args) {
  const coordinatorKey = path.resolve(args.stateDir);
  const coordinator = backgroundSyncs.get(coordinatorKey);
  if (!coordinator) return;
  coordinator.closed = true;
  coordinator.generation += 1;
  const timer = setTimeout(() => coordinator.controller.abort(), VIEW_STOP_GRACE_MS);
  timer.unref?.();
  try {
    await Promise.allSettled([coordinator.tail]);
  } finally {
    clearTimeout(timer);
  }
  if (backgroundSyncs.get(coordinatorKey) === coordinator) backgroundSyncs.delete(coordinatorKey);
}

module.exports = {
  packageViewBasePrefixes,
  stopAgentPackageViewSync,
  syncPackageFileToView,
  syncPackageSkillsToView,
  syncAgentPackageView,
  syncAgentPackageViewIfNeeded,
  syncAgentPackageViewInBackground
};
