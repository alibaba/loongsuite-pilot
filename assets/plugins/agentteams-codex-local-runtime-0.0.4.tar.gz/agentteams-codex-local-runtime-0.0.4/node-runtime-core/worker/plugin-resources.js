#!/usr/bin/env node
"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const YAML = require("yaml");
const { computePluginDigest, parsePluginRef } = require("./plugin-store");

const RUNTIME_ROLE_MAPPINGS = Object.freeze({
  team_leader: "leader",
  worker: "worker",
  standalone: "standalone"
});
const PLUGIN_ROLES = new Set(Object.values(RUNTIME_ROLE_MAPPINGS));
const BINDING_NAMES = ["credentialBroker", "nodeExecutable"];
const EXECUTABLE_BINDINGS = new Set(["nodeExecutable"]);
const ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]*$/;
const ENV_PATTERN = /^[A-Z_][A-Z0-9_]*$/;
const PACKAGE_INCLUDE_ORDER = ["plugin.yaml", "prompts/", "skills/", "mcp/"];
const PLUGIN_API_VERSION = "hiclaw.agentteam/v1alpha2";
const PLUGIN_KIND = "AgentTeamPlugin";

function pluginError(reason, message, detail) {
  return Object.assign(new Error(message), { reason }, detail ? { detail } : {});
}

function invalid(message, detail) {
  throw pluginError("PluginManifestInvalid", message, detail);
}

function invalidBinding(message, detail) {
  throw pluginError("PluginBindingInvalid", message, detail);
}

function mapping(value, label, reason = "manifest") {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    (reason === "binding" ? invalidBinding : invalid)(`${label} must be a mapping`);
  }
  return value;
}

function array(value, label, reason = "manifest") {
  if (!Array.isArray(value)) {
    (reason === "binding" ? invalidBinding : invalid)(`${label} must be an array`);
  }
  return value;
}

function exactKeys(value, requiredKeys, optionalKeys, label, reason = "manifest") {
  const object = mapping(value, label, reason);
  const allowed = new Set([...requiredKeys, ...optionalKeys]);
  const fail = reason === "binding" ? invalidBinding : invalid;
  for (const key of requiredKeys) {
    if (!Object.prototype.hasOwnProperty.call(object, key)) fail(`${label}.${key} is required`);
  }
  for (const key of Object.keys(object)) {
    if (!allowed.has(key)) fail(`${label}.${key} is not allowed`);
  }
  return object;
}

function uniqueStrings(value, label, { allowed, pattern, nonEmpty = true, reason = "manifest" } = {}) {
  const values = array(value, label, reason);
  const fail = reason === "binding" ? invalidBinding : invalid;
  if (nonEmpty && values.length === 0) fail(`${label} must not be empty`);
  const seen = new Set();
  for (const item of values) {
    if (typeof item !== "string" || (pattern && !pattern.test(item)) || (allowed && !allowed.has(item))) {
      fail(`${label} contains an invalid value`);
    }
    if (seen.has(item)) fail(`${label} contains a duplicate value`);
    seen.add(item);
  }
  return values;
}

function resourcePath(pluginSourceDir, relativePath, expectedType, label) {
  if (typeof relativePath !== "string" || !relativePath || relativePath.includes("\\") || path.posix.isAbsolute(relativePath)) {
    invalid(`${label} must be a safe relative POSIX path`);
  }
  const parts = relativePath.split("/");
  if (parts.some(part => !part || part === "." || part === "..") || path.posix.normalize(relativePath) !== relativePath) {
    invalid(`${label} must be a safe relative POSIX path`);
  }

  let current = pluginSourceDir;
  try {
    for (const part of parts) {
      current = path.join(current, part);
      const stat = fs.lstatSync(current);
      if (stat.isSymbolicLink()) invalid(`${label} must not traverse a symbolic link`);
    }
    const stat = fs.statSync(current);
    if ((expectedType === "file" && !stat.isFile()) || (expectedType === "directory" && !stat.isDirectory())) {
      invalid(`${label} has the wrong resource type`);
    }
  } catch (error) {
    if (error.reason) throw error;
    invalid(`${label} does not exist`);
  }

  const resolved = fs.realpathSync(current);
  if (resolved !== pluginSourceDir && !resolved.startsWith(`${pluginSourceDir}${path.sep}`)) {
    invalid(`${label} escapes the plugin source directory`);
  }
  return resolved;
}

function validateBindingReferences(value, manifest, label, required) {
  if (value === undefined && !required) return [];
  const names = uniqueStrings(value, label, {
    allowed: new Set(BINDING_NAMES),
    reason: "binding"
  });
  for (const name of names) {
    if (!Object.prototype.hasOwnProperty.call(manifest.bindings, name)) {
      invalidBinding(`${label} references an undeclared binding`, { type: "missing-reference", binding: name });
    }
  }
  return names;
}

function validateRoles(value, label) {
  return uniqueStrings(value, label, { allowed: PLUGIN_ROLES });
}

function validateManifest(manifest, pluginSourceDir) {
  exactKeys(manifest, ["apiVersion", "kind", "metadata", "roles", "bindings", "resources", "package"], [], "manifest");
  if (manifest.apiVersion !== PLUGIN_API_VERSION || manifest.kind !== PLUGIN_KIND) {
    invalid(`plugin apiVersion/kind must be ${PLUGIN_API_VERSION} / ${PLUGIN_KIND}`);
  }

  const metadata = exactKeys(manifest.metadata, ["name", "version"], [], "metadata");
  try {
    parsePluginRef(`${metadata.name}@${metadata.version}`);
  } catch {
    invalid("metadata name or version is invalid");
  }

  const roles = exactKeys(manifest.roles, ["mappings"], [], "roles");
  const mappings = exactKeys(
    roles.mappings,
    Object.keys(RUNTIME_ROLE_MAPPINGS),
    [],
    "roles.mappings"
  );
  for (const [runtimeRole, pluginRole] of Object.entries(RUNTIME_ROLE_MAPPINGS)) {
    if (mappings[runtimeRole] !== pluginRole) invalid(`roles.mappings.${runtimeRole} is invalid`);
  }

  const bindings = exactKeys(manifest.bindings, BINDING_NAMES, [], "bindings", "binding");
  const envNames = new Set();
  for (const name of BINDING_NAMES) {
    const binding = exactKeys(bindings[name], ["env"], [], `bindings.${name}`, "binding");
    if (typeof binding.env !== "string" || !ENV_PATTERN.test(binding.env)) {
      invalidBinding(`bindings.${name}.env is invalid`, { type: "invalid-env", binding: name });
    }
    if (envNames.has(binding.env)) {
      invalidBinding("binding env names must be globally unique", { type: "env-conflict", binding: name });
    }
    envNames.add(binding.env);
  }

  const resources = exactKeys(manifest.resources, ["prompts", "skills", "mcp"], [], "resources");
  const resourceIds = new Set();
  const registerId = (entry, label) => {
    if (typeof entry.id !== "string" || !ID_PATTERN.test(entry.id)) invalid(`${label}.id is invalid`);
    if (resourceIds.has(entry.id)) invalid(`duplicate resource id: ${entry.id}`);
    resourceIds.add(entry.id);
  };

  const promptResources = array(resources.prompts, "resources.prompts");
  for (const entry of promptResources) {
    exactKeys(entry, ["id", "path", "roles"], [], "prompt resource");
    registerId(entry, "prompt resource");
    validateRoles(entry.roles, `prompt ${entry.id}.roles`);
    resourcePath(pluginSourceDir, entry.path, "file", `prompt ${entry.id}.path`);
  }

  const skills = exactKeys(resources.skills, ["agent", "team"], [], "resources.skills");
  const skillResources = [];
  for (const group of ["agent", "team"]) {
    const entries = array(skills[group], `resources.skills.${group}`);
    skillResources.push(...entries);
    for (const entry of entries) {
      exactKeys(entry, ["id", "path", "roles"], ["bindings"], "skill resource");
      registerId(entry, "skill resource");
      validateRoles(entry.roles, `skill ${entry.id}.roles`);
      validateBindingReferences(entry.bindings, manifest, `skill ${entry.id}.bindings`, false);
      resourcePath(pluginSourceDir, entry.path, "directory", `skill ${entry.id}.path`);
      resourcePath(pluginSourceDir, path.posix.join(entry.path, "SKILL.md"), "file", `skill ${entry.id}.SKILL.md`);
    }
  }

  const mcp = exactKeys(resources.mcp, ["servers"], [], "resources.mcp");
  const mcpServers = array(mcp.servers, "resources.mcp.servers");
  for (const entry of mcpServers) {
    exactKeys(
      entry,
      ["id", "transport", "command", "roles", "bindings", "args", "tools"],
      [],
      "MCP server resource"
    );
    registerId(entry, "MCP server resource");
    if (entry.transport !== "stdio") invalid(`MCP server ${entry.id}.transport must be stdio`);
    validateRoles(entry.roles, `MCP server ${entry.id}.roles`);
    validateBindingReferences(entry.bindings, manifest, `MCP server ${entry.id}.bindings`, true);
    const command = exactKeys(entry.command, ["binding"], [], `MCP server ${entry.id}.command`, "binding");
    if (!BINDING_NAMES.includes(command.binding) || !Object.prototype.hasOwnProperty.call(bindings, command.binding)) {
      invalidBinding(`MCP server ${entry.id}.command.binding is unknown`, {
        type: "missing-reference",
        binding: command.binding
      });
    }
    if (!EXECUTABLE_BINDINGS.has(command.binding)) {
      invalidBinding(`MCP server ${entry.id}.command.binding is not executable`, {
        type: "invalid-command-binding",
        binding: command.binding
      });
    }
    const args = array(entry.args, `MCP server ${entry.id}.args`);
    if (args.length === 0) invalid(`MCP server ${entry.id}.args must not be empty`);
    for (const arg of args) resourcePath(pluginSourceDir, arg, "file", `MCP server ${entry.id}.args`);
    uniqueStrings(entry.tools, `MCP server ${entry.id}.tools`, { pattern: ID_PATTERN, nonEmpty: false });
  }

  const packageSection = exactKeys(manifest.package, ["include"], [], "package");
  const includes = array(packageSection.include, "package.include");
  const normalizedIncludes = PACKAGE_INCLUDE_ORDER.filter(entry => includes.includes(entry));
  if (includes[0] !== "plugin.yaml" ||
      includes.length !== normalizedIncludes.length ||
      includes.some((entry, index) => entry !== normalizedIncludes[index])) {
    invalid("package.include is invalid");
  }
  if (promptResources.length > 0 && !includes.includes("prompts/")) {
    invalid("package.include must include prompts/ when prompt resources are declared");
  }
  if (skillResources.length > 0 && !includes.includes("skills/")) {
    invalid("package.include must include skills/ when skill resources are declared");
  }
  if (mcpServers.length > 0 && !includes.includes("mcp/")) {
    invalid("package.include must include mcp/ when MCP servers are declared");
  }
  resourcePath(pluginSourceDir, "plugin.yaml", "file", "package.include[0]");
  for (const entry of includes.slice(1)) {
    resourcePath(pluginSourceDir, entry.slice(0, -1), "directory", `package.include ${entry}`);
  }
}

function loadPluginManifest(pluginSourceDir) {
  let sourceDir;
  try {
    sourceDir = fs.realpathSync(path.resolve(String(pluginSourceDir || "")));
    if (!fs.statSync(sourceDir).isDirectory()) invalid("plugin source must be a directory");
  } catch (error) {
    if (error.reason) throw error;
    invalid("plugin source must be a directory");
  }

  const manifestPath = path.join(sourceDir, "plugin.yaml");
  let manifest;
  try {
    const stat = fs.lstatSync(manifestPath);
    if (!stat.isFile() || stat.isSymbolicLink()) invalid("plugin.yaml must be a regular file");
    manifest = YAML.parse(fs.readFileSync(manifestPath, "utf8"));
  } catch (error) {
    if (error.reason) throw error;
    invalid(`plugin.yaml is invalid: ${error.message}`);
  }
  validateManifest(manifest, sourceDir);
  return manifest;
}

function resolvePluginRole(manifest, runtimeRole) {
  const role = String(runtimeRole || "");
  if (!Object.prototype.hasOwnProperty.call(RUNTIME_ROLE_MAPPINGS, role)) {
    invalid("runtime role is not supported");
  }
  const roles = exactKeys(manifest?.roles, ["mappings"], [], "roles");
  const mappings = exactKeys(roles.mappings, Object.keys(RUNTIME_ROLE_MAPPINGS), [], "roles.mappings");
  const pluginRole = mappings[role];
  if (pluginRole !== RUNTIME_ROLE_MAPPINGS[role]) invalid(`runtime role mapping is invalid: ${role}`);
  return pluginRole;
}

function sha256(value) {
  return `sha256:${crypto.createHash("sha256").update(value).digest("hex")}`;
}

function relativePath(pluginSourceDir, absolutePath) {
  return path.relative(pluginSourceDir, absolutePath).split(path.sep).join("/");
}

function resolvePluginResources({ pluginSourceDir, runtimeRole } = {}) {
  const manifest = loadPluginManifest(pluginSourceDir);
  const sourceDir = fs.realpathSync(path.resolve(String(pluginSourceDir || "")));
  const pluginRole = resolvePluginRole(manifest, runtimeRole);
  const selected = entry => entry.roles.includes(pluginRole);

  const prompts = manifest.resources.prompts.filter(selected).map(entry => {
    const resolvedPath = resourcePath(sourceDir, entry.path, "file", `prompt ${entry.id}.path`);
    return { id: entry.id, path: resolvedPath, content: fs.readFileSync(resolvedPath, "utf8") };
  });
  const skills = [
    ...manifest.resources.skills.agent,
    ...manifest.resources.skills.team
  ].filter(selected).map(entry => ({
    id: entry.id,
    path: resourcePath(sourceDir, entry.path, "directory", `skill ${entry.id}.path`),
    bindings: [...(entry.bindings || [])]
  }));
  const mcpServers = manifest.resources.mcp.servers.filter(selected).map(entry => ({
    id: entry.id,
    transport: entry.transport,
    command: { binding: entry.command.binding },
    args: entry.args.map(arg => resourcePath(sourceDir, arg, "file", `MCP server ${entry.id}.args`)),
    bindings: [...entry.bindings],
    tools: [...entry.tools]
  }));

  const required = new Set();
  for (const skill of skills) for (const name of skill.bindings) required.add(name);
  for (const server of mcpServers) {
    required.add(server.command.binding);
    for (const name of server.bindings) required.add(name);
  }
  const requiredBindings = BINDING_NAMES.filter(name => required.has(name));
  const pluginDigest = computePluginDigest(sourceDir);
  const digestInput = {
    plugin: { name: manifest.metadata.name, version: manifest.metadata.version },
    runtimeRole,
    pluginRole,
    bindings: requiredBindings.map(name => ({ name, env: manifest.bindings[name].env })),
    prompts: prompts.map(prompt => ({
      id: prompt.id,
      path: relativePath(sourceDir, prompt.path),
      contentDigest: sha256(prompt.content)
    })),
    skills: skills.map(skill => ({
      id: skill.id,
      path: relativePath(sourceDir, skill.path),
      bindings: skill.bindings,
      contentDigest: computePluginDigest(skill.path)
    })),
    mcpServers: mcpServers.map(server => ({
      id: server.id,
      transport: server.transport,
      command: server.command,
      args: server.args.map(arg => ({
        path: relativePath(sourceDir, arg),
        contentDigest: sha256(fs.readFileSync(arg))
      })),
      bindings: server.bindings,
      tools: server.tools
    }))
  };

  return {
    plugin: {
      name: manifest.metadata.name,
      version: manifest.metadata.version,
      digest: pluginDigest
    },
    runtimeRole,
    pluginRole,
    prompts,
    skills,
    mcpServers,
    requiredBindings,
    resolvedResourcesDigest: sha256(JSON.stringify(digestInput))
  };
}

module.exports = {
  loadPluginManifest,
  resolvePluginResources,
  resolvePluginRole
};
