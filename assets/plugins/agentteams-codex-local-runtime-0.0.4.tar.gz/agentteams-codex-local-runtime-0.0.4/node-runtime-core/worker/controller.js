#!/usr/bin/env node
"use strict";

const path = require("path");
const os = require("os");
const { encodeBootstrapToken, writeBootstrapTokenFile } = require("./bootstrap");
const { writeJson, writeStatus } = require("./status");

const DEFAULT_CONTROLLER_REQUEST_TIMEOUT_MS = 30_000;

function abortError() {
  const error = new Error("controller request aborted");
  error.name = "AbortError";
  return error;
}

function timeoutError(timeoutMs) {
  const error = new Error(`controller request timed out after ${timeoutMs}ms`);
  error.name = "TimeoutError";
  error.reason = "ControllerRequestTimeout";
  error.timeoutMs = timeoutMs;
  return error;
}

function throwIfAborted(signal) {
  if (signal?.aborted) throw abortError();
}

function requestAbortContext(options) {
  const external = options?.signal;
  const configuredTimeout = Number(options?.timeoutMs);
  const timeoutMs = Number.isFinite(configuredTimeout) && configuredTimeout > 0
    ? configuredTimeout
    : DEFAULT_CONTROLLER_REQUEST_TIMEOUT_MS;
  const controller = new AbortController();
  let timedOut = false;
  const abort = () => controller.abort();
  if (external?.aborted) controller.abort();
  else external?.addEventListener("abort", abort, { once: true });
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, timeoutMs);
  timer.unref?.();
  return {
    signal: controller.signal,
    timeoutMs,
    timedOut: () => timedOut,
    cleanup() {
      clearTimeout(timer);
      external?.removeEventListener("abort", abort);
    }
  };
}

async function controllerRequest(url, init, options) {
  throwIfAborted(options?.signal);
  const abortContext = requestAbortContext(options);
  try {
    const response = await fetch(url, { ...init, signal: abortContext.signal });
    const text = await response.text();
    if (abortContext.timedOut()) throw timeoutError(abortContext.timeoutMs);
    throwIfAborted(options?.signal);
    return { response, text };
  } catch (error) {
    if (abortContext.timedOut()) throw timeoutError(abortContext.timeoutMs);
    if (options?.signal?.aborted) throw abortError();
    throw error;
  } finally {
    abortContext.cleanup();
  }
}

function awaitWithSignal(promise, signal) {
  if (!signal) return Promise.resolve(promise);
  if (signal.aborted) return Promise.reject(abortError());
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (callback, value) => {
      if (settled) return;
      settled = true;
      signal.removeEventListener("abort", onAbort);
      callback(value);
    };
    const onAbort = () => finish(reject, abortError());
    signal.addEventListener("abort", onAbort, { once: true });
    Promise.resolve(promise).then(
      value => finish(resolve, value),
      error => finish(reject, error)
    );
  });
}

async function postJson(baseUrl, requestPath, payload, headers, options) {
  const url = new URL(requestPath, `${baseUrl}/`);
  const { response, text } = await controllerRequest(url, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json; charset=utf-8",
      ...(headers || {})
    },
    body: JSON.stringify(payload || {})
  }, options);
  if (!response.ok) {
    throw new Error(`POST ${url} failed: ${response.status} ${text}`);
  }
  if (!text.trim()) {
    return {};
  }
  return JSON.parse(text);
}

async function postEmpty(baseUrl, requestPath, headers, options) {
  const url = new URL(requestPath, `${baseUrl}/`);
  const { response, text } = await controllerRequest(url, {
    method: "POST",
    headers: {
      Accept: "application/json",
      ...(headers || {})
    }
  }, options);
  if (!response.ok) {
    throw new Error(`POST ${url} failed: ${response.status} ${text}`);
  }
}

function localIPAddress() {
  const fallback = [];
  for (const entries of Object.values(os.networkInterfaces())) {
    for (const entry of entries || []) {
      if (!entry || entry.internal || !entry.address) continue;
      if (entry.family === "IPv4" || entry.family === 4) return entry.address;
      fallback.push(entry.address);
    }
  }
  return fallback[0] || "";
}

function heartbeatPayload(args) {
  return {
    localIP: localIPAddress(),
    runtime: String(args?.runtime || "").trim()
  };
}

async function exchangeEdgeToken(args, bootstrap, options) {
  const response = await postJson(bootstrap.controllerUrl, "/api/v1/edge/token", {
    jwtToken: bootstrap.jwtToken
  }, null, options);
  throwIfAborted(options?.signal);
  const token = String(response.token || "").trim();
  const workerName = String(response.workerName || "").trim();
  if (!token || !workerName) {
    throw new Error("edge token response missing token or workerName");
  }
  const refreshedJWT = String(response.jwtToken || "").trim();
  if (refreshedJWT) {
    bootstrap.jwtToken = refreshedJWT;
    writeBootstrapTokenFile(args, encodeBootstrapToken(bootstrap));
  }
  const edge = {
    controllerUrl: bootstrap.controllerUrl,
    modelGatewayUrl: bootstrap.modelGatewayUrl,
    matrixHomeserver: bootstrap.matrixUrl,
    token,
    workerName,
    workerResourceName: String(response.workerResourceName || workerName).trim(),
    runtimeName: String(response.runtimeName || workerName).trim(),
    teamName: String(response.teamName || "").trim(),
    expiresAt: String(response.expiresAt || "").trim(),
    jwtExpiresAt: String(response.jwtExpiresAt || "").trim(),
    updatedAt: Math.floor(Date.now() / 1000)
  };
  writeJson(path.join(args.stateDir, "edge-state.json"), {
    controllerUrl: edge.controllerUrl,
    modelGatewayUrl: edge.modelGatewayUrl,
    matrixHomeserver: edge.matrixHomeserver,
    workerName: edge.workerName,
    workerResourceName: edge.workerResourceName,
    runtimeName: edge.runtimeName,
    teamName: edge.teamName,
    expiresAt: edge.expiresAt,
    jwtExpiresAt: edge.jwtExpiresAt,
    updatedAt: edge.updatedAt
  });
  writeStatus(args, "Running", "EdgeTokenReady", "edge token exchanged", {
    workerName: edge.workerName,
    workerResourceName: edge.workerResourceName
  });
  return edge;
}

function edgeTokenRefreshRequired(edge, nowSeconds) {
  if (!edge || typeof edge !== "object") return true;
  if (!String(edge.token || "").trim()) return true;
  const expiresAt = Date.parse(String(edge.expiresAt || "")) / 1000;
  if (!Number.isFinite(expiresAt) || expiresAt <= 0) return false;
  const now = nowSeconds === undefined ? Math.floor(Date.now() / 1000) : nowSeconds;
  if (now >= expiresAt) return true;
  const issuedAt = Number(edge.updatedAt || 0);
  if (!issuedAt || issuedAt >= expiresAt) {
    return now >= expiresAt - 300;
  }
  const lifetime = expiresAt - issuedAt;
  const refreshAt = Math.min(issuedAt + lifetime * 0.8, issuedAt + Math.max(lifetime - 300, 0));
  return now >= refreshAt;
}

function setHidden(target, key, value) {
  Object.defineProperty(target, key, {
    value,
    writable: true,
    configurable: true,
    enumerable: false
  });
}

async function refreshEdgeToken(args, edge, bootstrap, options) {
  if (!bootstrap || !bootstrap.jwtToken) {
    throw new Error("edge bootstrap token is unavailable; cannot refresh edge token");
  }
  if (args.edgeTokenRefreshPromise) {
    return awaitWithSignal(args.edgeTokenRefreshPromise, options?.signal);
  }
  const promise = exchangeEdgeToken(args, bootstrap, options).then(nextEdge => {
    throwIfAborted(options?.signal);
    Object.assign(edge, nextEdge);
    return edge;
  });
  setHidden(args, "edgeTokenRefreshPromise", promise);
  const clearSharedPromise = () => {
    if (args.edgeTokenRefreshPromise === promise) {
      setHidden(args, "edgeTokenRefreshPromise", null);
    }
  };
  promise.then(clearSharedPromise, clearSharedPromise);
  return awaitWithSignal(promise, options?.signal);
}

async function ensureEdgeTokenFresh(args, edge, options) {
  throwIfAborted(options?.signal);
  const force = Boolean(options && options.force);
  if (!force && !edgeTokenRefreshRequired(edge, options && options.nowSeconds)) {
    return edge;
  }
  return refreshEdgeToken(args, edge, args.edgeBootstrap, options);
}

async function requestSts(args, edge, options) {
  await ensureEdgeTokenFresh(args, edge, options);
  throwIfAborted(options?.signal);
  const sts = await postJson(edge.controllerUrl, "/api/v1/credentials/sts", {}, {
    Authorization: `Bearer ${edge.token}`
  }, options);
  throwIfAborted(options?.signal);
  const required = ["access_key_id", "access_key_secret", "security_token", "oss_endpoint", "oss_bucket"];
  const missing = required.filter(key => !String(sts[key] || "").trim());
  if (missing.length) {
    throw new Error(`STS response missing required fields: ${missing.join(", ")}`);
  }
  const payload = {
    ...sts,
    controllerUrl: edge.controllerUrl,
    modelGatewayUrl: edge.modelGatewayUrl,
    workerName: edge.workerName,
    workerResourceName: edge.workerResourceName,
    issuedAt: Math.floor(Date.now() / 1000)
  };
  writeStatus(args, "Running", "StsReady", "STS credential refreshed", {
    workerName: edge.workerName
  });
  return payload;
}

async function reportHeartbeat(args, edge, options) {
  await ensureEdgeTokenFresh(args, edge, options);
  throwIfAborted(options?.signal);
  const workerPath = encodeURIComponent(edge.workerResourceName || edge.workerName);
  const payload = heartbeatPayload(args);
  await postJson(edge.controllerUrl, `/api/v1/workers/${workerPath}/heartbeat`, payload, {
    Authorization: `Bearer ${edge.token}`
  }, options);
  throwIfAborted(options?.signal);
  writeStatus(args, "Running", "HeartbeatReported", "worker heartbeat reported", {
    workerName: edge.workerName,
    workerResourceName: edge.workerResourceName,
    localIP: payload.localIP,
    runtime: payload.runtime
  });
}

module.exports = {
  postJson,
  postEmpty,
  localIPAddress,
  heartbeatPayload,
  exchangeEdgeToken,
  edgeTokenRefreshRequired,
  ensureEdgeTokenFresh,
  requestSts,
  reportHeartbeat
};
