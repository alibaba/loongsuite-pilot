#!/usr/bin/env node
"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const tar = require("tar");
const YAML = require("yaml");

const PLUGIN_NAME_PATTERN = /^[a-z0-9][a-z0-9._-]*$/;
const EXACT_SEMVER_PATTERN = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*)(?:\.(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*))*))?(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$/;
const DIGEST_PATTERN = /^sha256:[0-9a-f]{64}$/;
const PLUGIN_OSS_PUBLIC_BASE_URL = "https://agentteams-release-cn-hangzhou.oss-cn-hangzhou.aliyuncs.com/plugins/edge-worker";
const PLUGIN_OSS_INTERNAL_BASE_URL = "https://agentteams-release-cn-hangzhou.oss-cn-hangzhou-internal.aliyuncs.com/plugins/edge-worker";
const MAX_ARCHIVE_BYTES = 32 * 1024 * 1024;
const MAX_FILE_COUNT = 4096;
const MAX_FILE_BYTES = 16 * 1024 * 1024;
const MAX_TOTAL_BYTES = 64 * 1024 * 1024;
const DOWNLOAD_TIMEOUT_MS = 15_000;

function pluginError(reason, message, detail) {
  return Object.assign(new Error(message), { reason }, detail ? { detail } : {});
}

function parsePluginRef(value) {
  const ref = String(value || "");
  const separator = ref.lastIndexOf("@");
  const name = separator > 0 ? ref.slice(0, separator) : "";
  const version = separator > 0 ? ref.slice(separator + 1) : "";
  if (!PLUGIN_NAME_PATTERN.test(name) || !EXACT_SEMVER_PATTERN.test(version)) {
    throw pluginError("PluginRefInvalid", "plugin ref must be <name>@<exact-semver>");
  }
  return { name, version };
}

function sourceFiles(rootDir, currentDir = rootDir, files = []) {
  for (const name of fs.readdirSync(currentDir).sort()) {
    const file = path.join(currentDir, name);
    const stat = fs.lstatSync(file);
    if (stat.isSymbolicLink()) {
      throw pluginError("PluginDigestMismatch", `plugin source contains a symbolic link: ${name}`);
    }
    if (stat.isDirectory()) {
      sourceFiles(rootDir, file, files);
    } else if (stat.isFile() && stat.nlink === 1) {
      files.push({ file, stat });
    } else {
      throw pluginError("PluginDigestMismatch", `plugin source contains a non-regular file: ${name}`);
    }
  }
  return files;
}

function computePluginDigest(pluginSourceDir) {
  if (typeof pluginSourceDir !== "string" || !pluginSourceDir) {
    throw pluginError("PluginDigestMismatch", "plugin source directory is required");
  }
  const sourceDir = path.resolve(pluginSourceDir);
  try {
    const stat = fs.lstatSync(sourceDir);
    if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error("not a regular directory");
  } catch (error) {
    throw pluginError("PluginDigestMismatch", `plugin source must be a regular directory: ${error.message}`);
  }
  const digest = crypto.createHash("sha256");
  const files = sourceFiles(sourceDir)
    .map(entry => ({
      ...entry,
      relativePath: path.relative(sourceDir, entry.file).split(path.sep).join("/")
    }))
    .sort((left, right) => Buffer.compare(Buffer.from(left.relativePath), Buffer.from(right.relativePath)));
  for (const { file, stat, relativePath } of files) {
    const content = fs.readFileSync(file);
    const mode = (stat.mode & 0o111) === 0 ? "0644" : "0755";
    digest.update(`${relativePath}\0${mode}\0${content.length}\0`);
    digest.update(content);
    digest.update("\0");
  }
  return `sha256:${digest.digest("hex")}`;
}

function exactObjectKeys(value, keys) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const actual = Object.keys(value).sort();
  return actual.length === keys.length && actual.every((key, index) => key === [...keys].sort()[index]);
}

function readVerificationMarker(versionDir) {
  const markerPath = path.join(versionDir, ".verified.json");
  let marker;
  try {
    const stat = fs.lstatSync(markerPath);
    if (!stat.isFile() || stat.isSymbolicLink()) throw new Error("not a regular file");
    marker = JSON.parse(fs.readFileSync(markerPath, "utf8"));
  } catch (error) {
    throw pluginError("PluginDigestMismatch", `plugin verification marker is invalid: ${error.message}`);
  }
  if (!exactObjectKeys(marker, ["name", "version", "digest"]) || !DIGEST_PATTERN.test(marker.digest)) {
    throw pluginError("PluginDigestMismatch", "plugin verification marker is invalid");
  }
  try {
    parsePluginRef(`${marker.name}@${marker.version}`);
  } catch {
    throw pluginError("PluginDigestMismatch", "plugin verification marker has an invalid name or version");
  }
  return marker;
}

function readManifestIdentity(sourceDir) {
  const manifestPath = path.join(sourceDir, "plugin.yaml");
  try {
    const stat = fs.lstatSync(manifestPath);
    if (!stat.isFile() || stat.isSymbolicLink()) throw new Error("not a regular file");
    const manifest = YAML.parse(fs.readFileSync(manifestPath, "utf8"));
    const name = manifest?.metadata?.name;
    const version = manifest?.metadata?.version;
    parsePluginRef(`${name}@${version}`);
    return { name, version };
  } catch (error) {
    throw pluginError("PluginManifestInvalid", `plugin manifest identity is invalid: ${error.message}`);
  }
}

function verifyPluginVersionDir({ versionDir, expectedRef, expectedDigest } = {}) {
  const expected = typeof expectedRef === "string"
    ? parsePluginRef(expectedRef)
    : parsePluginRef(`${expectedRef?.name}@${expectedRef?.version}`);
  const resolvedVersionDir = path.resolve(String(versionDir || ""));
  let versionRoot;
  try {
    const stat = fs.lstatSync(resolvedVersionDir);
    if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error("not a regular directory");
    versionRoot = fs.realpathSync(resolvedVersionDir);
  } catch (error) {
    throw pluginError("PluginDigestMismatch", `plugin version directory is invalid: ${error.message}`);
  }

  const marker = readVerificationMarker(versionRoot);
  if (marker.name !== expected.name || marker.version !== expected.version) {
    throw pluginError("PluginManifestInvalid", "plugin verification marker does not match the requested ref");
  }

  const sourcePath = path.join(versionRoot, "source", expected.name);
  let sourceDir;
  try {
    const stat = fs.lstatSync(sourcePath);
    if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error("not a regular directory");
    sourceDir = fs.realpathSync(sourcePath);
  } catch (error) {
    throw pluginError("PluginDigestMismatch", `plugin source directory is invalid: ${error.message}`);
  }
  if (sourceDir !== versionRoot && !sourceDir.startsWith(`${versionRoot}${path.sep}`)) {
    throw pluginError("PluginDigestMismatch", "plugin source directory escapes the version directory");
  }

  const identity = readManifestIdentity(sourceDir);
  if (identity.name !== expected.name || identity.version !== expected.version) {
    throw pluginError("PluginManifestInvalid", "plugin manifest identity does not match the requested ref");
  }

  const pluginDigest = computePluginDigest(sourceDir);
  if (pluginDigest !== marker.digest || (expectedDigest && pluginDigest !== expectedDigest)) {
    throw pluginError("PluginDigestMismatch", "plugin source digest does not match its verified digest");
  }

  return {
    name: expected.name,
    version: expected.version,
    pluginDigest,
    sourceDir
  };
}

function readDefaultPin(pluginDefaultFile) {
  if (typeof pluginDefaultFile !== "string" || !pluginDefaultFile) {
    throw pluginError("PluginDefaultMissing", "plugin default file is missing");
  }
  const defaultPath = path.resolve(pluginDefaultFile);
  let pin;
  try {
    const stat = fs.lstatSync(defaultPath);
    if (!stat.isFile() || stat.isSymbolicLink()) throw new Error("not a regular file");
    pin = JSON.parse(fs.readFileSync(defaultPath, "utf8"));
  } catch (error) {
    if (error.code === "ENOENT") {
      throw pluginError("PluginDefaultMissing", "plugin default is missing");
    }
    throw pluginError("PluginDefaultInvalid", `plugin default is invalid: ${error.message}`);
  }
  if (!exactObjectKeys(pin, ["name", "version", "digest"]) || !DIGEST_PATTERN.test(pin.digest)) {
    throw pluginError("PluginDefaultInvalid", "plugin default is invalid");
  }
  try {
    parsePluginRef(`${pin.name}@${pin.version}`);
  } catch {
    throw pluginError("PluginDefaultInvalid", "plugin default has an invalid name or version");
  }
  return pin;
}

function cachedVersionDir(pilotDataDir, ref) {
  if (typeof pilotDataDir !== "string" || !pilotDataDir) {
    throw pluginError("PluginCacheUnavailable", "PILOT_DATA_DIR is required for the shared plugin cache");
  }
  return path.join(
    path.resolve(pilotDataDir),
    "local-worker-cache",
    "plugins",
    ref.name,
    "versions",
    ref.version
  );
}

function pathEntryExists(file) {
  try {
    fs.lstatSync(file);
    return true;
  } catch (error) {
    if (error.code === "ENOENT") return false;
    throw pluginError("PluginDigestMismatch", `plugin version path is unavailable: ${error.message}`);
  }
}

function withPluginIdentity(error, plugin) {
  if (!error || typeof error !== "object" || !plugin) return error;
  error.pluginName = plugin.name;
  error.pluginVersion = plugin.version;
  return error;
}

function pluginPackageUrl(ref, baseUrl = PLUGIN_OSS_INTERNAL_BASE_URL) {
  const parsed = typeof ref === "string" ? parsePluginRef(ref) : parsePluginRef(`${ref?.name}@${ref?.version}`);
  const name = encodeURIComponent(parsed.name);
  const version = encodeURIComponent(parsed.version);
  return `${String(baseUrl).replace(/\/+$/, "")}/${name}/${version}/${name}-${version}.tar.gz`;
}

function pluginPackageUrls(ref) {
  return [
    pluginPackageUrl(ref, PLUGIN_OSS_INTERNAL_BASE_URL),
    pluginPackageUrl(ref, PLUGIN_OSS_PUBLIC_BASE_URL)
  ];
}

function requestAbortContext(signal) {
  const controller = new AbortController();
  const abort = () => controller.abort();
  if (signal?.aborted) controller.abort();
  else signal?.addEventListener("abort", abort, { once: true });
  const timer = setTimeout(abort, DOWNLOAD_TIMEOUT_MS);
  timer.unref?.();
  return {
    signal: controller.signal,
    cleanup() {
      clearTimeout(timer);
      signal?.removeEventListener("abort", abort);
    }
  };
}

async function responseBuffer(response) {
  const length = Number(response.headers.get("content-length") || 0);
  if (Number.isFinite(length) && length > MAX_ARCHIVE_BYTES) {
    throw pluginError("PluginPackageTooLarge", `plugin archive exceeds ${MAX_ARCHIVE_BYTES} bytes`);
  }
  if (!response.body) throw pluginError("PluginDownloadFailed", "plugin download returned an empty body");
  const chunks = [];
  let total = 0;
  for await (const chunk of response.body) {
    const buffer = Buffer.from(chunk);
    total += buffer.length;
    if (total > MAX_ARCHIVE_BYTES) {
      throw pluginError("PluginPackageTooLarge", `plugin archive exceeds ${MAX_ARCHIVE_BYTES} bytes`);
    }
    chunks.push(buffer);
  }
  return Buffer.concat(chunks, total);
}

async function downloadPluginPackage({ ref, signal, fetchImpl = fetch } = {}) {
  let lastError;
  for (const url of pluginPackageUrls(ref)) {
    const abortContext = requestAbortContext(signal);
    try {
      const response = await fetchImpl(url, {
        method: "GET",
        redirect: "error",
        signal: abortContext.signal
      });
      if (!response.ok) {
        const error = pluginError("PluginDownloadFailed", `plugin download failed: HTTP ${response.status}`);
        error.httpStatus = response.status;
        throw error;
      }
      return await responseBuffer(response);
    } catch (error) {
      if (signal?.aborted) throw error;
      if (error.httpStatus || error.reason === "PluginPackageTooLarge") throw error;
      lastError = error;
    } finally {
      abortContext.cleanup();
    }
  }
  throw pluginError("PluginDownloadFailed", `plugin download failed on internal and public OSS endpoints: ${lastError?.message || "network error"}`);
}

function safeArchivePath(value, expectedRoot) {
  const raw = String(value || "");
  if (!raw || raw.includes("\0") || raw.includes("\\") || path.posix.isAbsolute(raw)) {
    throw pluginError("PluginPackageInvalid", `unsafe plugin archive path: ${raw}`);
  }
  const normalized = raw.endsWith("/") ? raw.slice(0, -1) : raw;
  const parts = normalized.split("/");
  if (!normalized || parts.some(part => !part || part === "." || part === "..") || parts[0] !== expectedRoot) {
    throw pluginError("PluginPackageInvalid", `unsafe plugin archive path: ${raw}`);
  }
  return normalized;
}

async function extractPluginArchive(archive, destination, ref) {
  if (!Buffer.isBuffer(archive)) throw pluginError("PluginDownloadFailed", "plugin download did not return bytes");
  if (archive.length > MAX_ARCHIVE_BYTES) {
    throw pluginError("PluginPackageTooLarge", `plugin archive exceeds ${MAX_ARCHIVE_BYTES} bytes`);
  }
  const packageFile = path.join(destination, ".plugin-package.tar.gz");
  const sourceParent = path.join(destination, "source");
  fs.mkdirSync(sourceParent, { recursive: true, mode: 0o700 });
  fs.writeFileSync(packageFile, archive, { mode: 0o600 });
  const seen = new Set();
  let entryCount = 0;
  let totalBytes = 0;
  let validationError = null;
  try {
    await tar.x({
      cwd: sourceParent,
      file: packageFile,
      strict: true,
      preservePaths: false,
      noMtime: true,
      filter(entryPath, entry) {
        if (validationError) return false;
        try {
          const normalized = safeArchivePath(entryPath, ref.name);
          if (seen.has(normalized)) throw pluginError("PluginPackageInvalid", `duplicate plugin archive entry: ${normalized}`);
          seen.add(normalized);
          entryCount += 1;
          if (entryCount > MAX_FILE_COUNT) throw pluginError("PluginPackageTooLarge", "plugin archive contains too many entries");
          if (entry.type === "Directory") return true;
          if (entry.type !== "File" && entry.type !== "OldFile") {
            throw pluginError("PluginPackageInvalid", `unsupported plugin archive entry type: ${entry.type}`);
          }
          const size = Number(entry.size || 0);
          if (!Number.isSafeInteger(size) || size < 0 || size > MAX_FILE_BYTES) {
            throw pluginError("PluginPackageTooLarge", `plugin archive file is too large: ${normalized}`);
          }
          totalBytes += size;
          if (totalBytes > MAX_TOTAL_BYTES) throw pluginError("PluginPackageTooLarge", "plugin archive expands beyond its size limit");
          return true;
        } catch (error) {
          validationError = error;
          return false;
        }
      }
    });
    if (validationError) throw validationError;
  } catch (error) {
    if (error?.reason) throw error;
    throw pluginError("PluginPackageInvalid", `invalid plugin tar.gz archive: ${error.message}`);
  } finally {
    fs.rmSync(packageFile, { force: true });
  }
  const roots = fs.readdirSync(sourceParent);
  if (roots.length !== 1 || roots[0] !== ref.name) {
    throw pluginError("PluginPackageInvalid", `plugin archive must contain exactly one ${ref.name} root`);
  }
  return path.join(sourceParent, ref.name);
}

function freezePluginVersion(root) {
  const entry = fs.lstatSync(root);
  if (entry.isSymbolicLink()) throw pluginError("PluginPackageInvalid", `plugin cache contains a symbolic link: ${root}`);
  if (entry.isDirectory()) {
    fs.chmodSync(root, 0o755);
    for (const name of fs.readdirSync(root)) freezePluginVersion(path.join(root, name));
    return;
  }
  if (!entry.isFile() || entry.nlink !== 1) {
    throw pluginError("PluginPackageInvalid", `plugin cache contains an unsupported entry: ${root}`);
  }
  fs.chmodSync(root, entry.mode & 0o111 ? 0o555 : 0o444);
}

async function installDownloadedPlugin({ pilotDataDir, ref, archive, expectedDigest } = {}) {
  const target = cachedVersionDir(pilotDataDir, ref);
  const versionsDir = path.dirname(target);
  fs.mkdirSync(versionsDir, { recursive: true, mode: 0o700 });
  const staging = path.join(versionsDir, `.${ref.version}.tmp-${process.pid}-${crypto.randomBytes(6).toString("hex")}`);
  fs.mkdirSync(staging, { mode: 0o700 });
  try {
    const sourceDir = await extractPluginArchive(archive, staging, ref);
    const identity = readManifestIdentity(sourceDir);
    if (identity.name !== ref.name || identity.version !== ref.version) {
      throw pluginError("PluginManifestInvalid", "downloaded plugin manifest does not match the requested ref");
    }
    const digest = computePluginDigest(sourceDir);
    if (expectedDigest && digest !== expectedDigest) {
      throw pluginError("PluginDigestMismatch", "downloaded default plugin does not match the bundle pin");
    }
    fs.writeFileSync(path.join(staging, ".verified.json"), `${JSON.stringify({
      name: ref.name,
      version: ref.version,
      digest
    })}\n`, { mode: 0o400 });
    freezePluginVersion(staging);
    try {
      fs.renameSync(staging, target);
    } catch (error) {
      if (!pathEntryExists(target)) throw error;
      const installed = verifyPluginVersionDir({ versionDir: target, expectedRef: ref, expectedDigest });
      if (installed.pluginDigest !== digest) {
        throw pluginError("PluginVersionConflict", `${ref.name}@${ref.version} is already installed with a different digest`);
      }
    }
    return verifyPluginVersionDir({ versionDir: target, expectedRef: ref, expectedDigest });
  } finally {
    fs.rmSync(staging, { recursive: true, force: true });
  }
}

async function resolvePluginSource({ pilotDataDir, pluginDefaultFile, pluginRef, fetchPackage, signal } = {}) {
  const pin = pluginRef ? null : readDefaultPin(pluginDefaultFile);
  const requested = pluginRef ? parsePluginRef(pluginRef) : { name: pin.name, version: pin.version };
  const selectionMode = pluginRef ? "explicit" : "bundle-default";
  const expectedDigest = pin?.digest;
  try {
    const cacheDir = cachedVersionDir(pilotDataDir, requested);
    if (pathEntryExists(cacheDir)) {
      const cached = verifyPluginVersionDir({
        versionDir: cacheDir,
        expectedRef: requested,
        expectedDigest
      });
      return {
        ...cached,
        selectionMode,
        source: "local-cache",
        fromCache: true
      };
    }

    const request = {
      url: pluginPackageUrl(requested),
      ref: { ...requested }
    };
    if (signal) request.signal = signal;
    let archive;
    if (fetchPackage) {
      try {
        archive = await fetchPackage(request);
      } catch (error) {
        if (error?.reason) throw error;
        throw pluginError("PluginDownloadFailed", `plugin download failed: ${error.message}`);
      }
    } else {
      archive = await downloadPluginPackage({ ref: requested, signal });
    }
    const installed = await installDownloadedPlugin({
      pilotDataDir,
      ref: requested,
      archive,
      expectedDigest
    });
    return {
      ...installed,
      selectionMode,
      source: "remote-oss",
      fromCache: false
    };
  } catch (error) {
    throw withPluginIdentity(error, requested);
  }
}

module.exports = {
  computePluginDigest,
  downloadPluginPackage,
  parsePluginRef,
  pluginPackageUrl,
  resolvePluginSource,
  verifyPluginVersionDir
};
