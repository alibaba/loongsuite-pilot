#!/usr/bin/env node
"use strict";

const fs = require("node:fs");
const path = require("node:path");
const YAML = require("yaml");

function requiredObject(value, name) {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error(`${name} is required`);
  return value;
}

function requiredText(value, name) {
  const text = String(value ?? "").trim();
  if (!text) throw new Error(`${name} is required`);
  return text;
}

function resourceId(value, name) {
  const id = requiredText(value, name);
  if (!/^[A-Za-z0-9_.-]+$/.test(id)) throw new Error(`${name} is invalid: ${id}`);
  return id;
}

function textFrom(value, name) {
  if (value === undefined || value === null) return "";
  if (typeof value === "string") return value.trim();
  const entry = requiredObject(value, name);
  if (Object.prototype.hasOwnProperty.call(entry, "content")) return String(entry.content || "").trim();
  const source = requiredText(entry.path, `${name}.path`);
  if (!fs.statSync(source).isFile()) throw new Error(`${name}.path is not a file: ${source}`);
  return fs.readFileSync(source, "utf8").trim();
}

function normalizeProcessSpec(value, index) {
  const entry = requiredObject(value, `runtimeBindings.mcpServers[${index}]`);
  const command = requiredText(entry.command, `runtimeBindings.mcpServers[${index}].command`);
  const cwd = requiredText(entry.cwd, `runtimeBindings.mcpServers[${index}].cwd`);
  if (!path.isAbsolute(command)) throw new Error(`MCP command must be absolute: ${command}`);
  if (!path.isAbsolute(cwd)) throw new Error(`MCP cwd must be absolute: ${cwd}`);
  if (!Array.isArray(entry.args)) throw new Error(`runtimeBindings.mcpServers[${index}].args must be an array`);
  const env = requiredObject(entry.env || {}, `runtimeBindings.mcpServers[${index}].env`);
  return {
    id: resourceId(entry.id, `runtimeBindings.mcpServers[${index}].id`),
    command,
    args: entry.args.map(item => String(item)),
    cwd,
    env: Object.fromEntries(Object.keys(env).sort().map(key => [key, String(env[key])]))
  };
}

function normalizeMaterializerInput(input) {
  const value = requiredObject(input, "materializer input");
  const resources = requiredObject(value.resolvedResources, "resolvedResources");
  const plugin = requiredObject(resources.plugin, "resolvedResources.plugin");
  const bindings = requiredObject(value.runtimeBindings, "runtimeBindings");
  const executables = requiredObject(bindings.executables, "runtimeBindings.executables");
  const nodeExecutable = requiredText(executables.node, "runtimeBindings.executables.node");
  if (!path.isAbsolute(nodeExecutable)) throw new Error(`Node executable must be absolute: ${nodeExecutable}`);
  const agentPackage = requiredObject(value.agentPackage || {}, "agentPackage");
  const targetDir = path.resolve(requiredText(value.targetDir, "targetDir"));
  if (!fs.existsSync(targetDir) || !fs.statSync(targetDir).isDirectory()) {
    throw new Error(`targetDir is not a directory: ${targetDir}`);
  }

  const prompts = (resources.prompts || []).map((entry, index) => {
    const prompt = requiredObject(entry, `resolvedResources.prompts[${index}]`);
    return {
      id: resourceId(prompt.id, `resolvedResources.prompts[${index}].id`),
      content: textFrom(prompt, `resolvedResources.prompts[${index}]`)
    };
  });
  const skills = Array.isArray(resources.skills) ? resources.skills : [];
  const packageSkills = Array.isArray(agentPackage.skills) ? agentPackage.skills : [];
  const expectedMcpIds = (resources.mcpServers || []).map((entry, index) =>
    resourceId(requiredObject(entry, `resolvedResources.mcpServers[${index}]`).id, `resolvedResources.mcpServers[${index}].id`)
  );
  const mcpServers = (bindings.mcpServers || []).map(normalizeProcessSpec);
  const actualMcpIds = mcpServers.map(entry => entry.id);
  if (JSON.stringify(actualMcpIds) !== JSON.stringify(expectedMcpIds)) {
    throw new Error(`Runtime MCP process specs do not match resolved resources: ${actualMcpIds.join(",")}`);
  }

  return {
    targetDir,
    plugin: {
      name: resourceId(plugin.name, "resolvedResources.plugin.name"),
      version: requiredText(plugin.version, "resolvedResources.plugin.version")
    },
    prompts,
    skills,
    packageSkills,
    agentInstructions: textFrom(agentPackage.agents, "agentPackage.agents"),
    soul: textFrom(agentPackage.soul, "agentPackage.soul"),
    mcpServers,
    executables: { node: nodeExecutable },
    runtimeEnv: Object.fromEntries(
      Object.keys(requiredObject(bindings.runtimeEnv || {}, "runtimeBindings.runtimeEnv"))
        .sort()
        .map(key => [key, String(bindings.runtimeEnv[key])])
    ),
    resourceIds: {
      prompts: prompts.map(entry => entry.id),
      skills: skills.map((entry, index) => resourceId(requiredObject(entry, `resolvedResources.skills[${index}]`).id, `resolvedResources.skills[${index}].id`)),
      mcpServers: expectedMcpIds
    }
  };
}

function createOutputRoot(targetDir, name) {
  const root = path.join(targetDir, name);
  if (fs.existsSync(root)) throw new Error(`materializer output already exists: ${root}`);
  fs.mkdirSync(root, { recursive: false, mode: 0o700 });
  return root;
}

function writeText(file, content) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  fs.writeFileSync(file, content ? `${String(content).trim()}\n` : "", { mode: 0o600 });
}

function writeJson(file, payload) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  fs.writeFileSync(file, `${JSON.stringify(payload, null, 2)}\n`, { mode: 0o600 });
}

function copyTree(source, target) {
  const entry = fs.lstatSync(source);
  if (entry.isSymbolicLink()) throw new Error(`Skill source must not contain symbolic links: ${source}`);
  if (entry.isDirectory()) {
    fs.mkdirSync(target, { recursive: false, mode: entry.mode & 0o777 });
    for (const name of fs.readdirSync(source).sort()) copyTree(path.join(source, name), path.join(target, name));
    return;
  }
  if (!entry.isFile()) throw new Error(`Skill source contains unsupported entry: ${source}`);
  fs.copyFileSync(source, target);
  fs.chmodSync(target, entry.mode & 0o777);
}

function copySkillSet(root, selected, packageSkills) {
  const skillsRoot = path.join(root, "skills");
  fs.mkdirSync(skillsRoot, { recursive: false, mode: 0o700 });
  const seen = new Set();
  for (const [group, entries] of [["resolvedResources.skills", selected], ["agentPackage.skills", packageSkills]]) {
    entries.forEach((value, index) => {
      const entry = requiredObject(value, `${group}[${index}]`);
      const id = resourceId(entry.id, `${group}[${index}].id`);
      if (seen.has(id)) throw new Error(`Duplicate materialized Skill id: ${id}`);
      seen.add(id);
      const source = path.resolve(requiredText(entry.path, `${group}[${index}].path`));
      if (!fs.existsSync(path.join(source, "SKILL.md"))) throw new Error(`Skill is missing SKILL.md: ${source}`);
      copyTree(source, path.join(skillsRoot, id));
    });
  }
  return Array.from(seen);
}

function writeSharedResources(root, model) {
  writeText(path.join(root, "AGENTS.md"), model.agentInstructions);
  writeText(path.join(root, "SOUL.md"), model.soul);
  const skillIds = copySkillSet(root, model.skills, model.packageSkills);
  writeJson(path.join(root, "runtime-env.json"), model.runtimeEnv);
  return skillIds;
}

function declaredSkillNames(root, skillIds) {
  return skillIds.map(id => {
    const file = path.join(root, "skills", id, "SKILL.md");
    const source = fs.readFileSync(file, "utf8");
    const frontmatter = source.match(/^---[ \t]*\r?\n([\s\S]*?)\r?\n---[ \t]*(?:\r?\n|$)/);
    if (!frontmatter) return id;
    let metadata;
    try {
      metadata = YAML.parse(frontmatter[1]);
    } catch (error) {
      throw new Error(`Skill frontmatter is invalid: ${file}: ${error.message}`);
    }
    if (!metadata || typeof metadata !== "object" || Array.isArray(metadata) || !metadata.name) return id;
    return resourceId(metadata.name, `Skill ${id} frontmatter name`);
  });
}

function combinedPrompt(model, includeSoul) {
  return [
    ...model.prompts.map(entry => entry.content),
    model.agentInstructions,
    ...(includeSoul ? [model.soul] : [])
  ].map(value => String(value || "").trim()).filter(Boolean).join("\n\n");
}

function mcpServerMap(model) {
  return Object.fromEntries(model.mcpServers.map(entry => [entry.id, {
    command: entry.command,
    args: entry.args,
    cwd: entry.cwd,
    env: entry.env
  }]));
}

function tomlString(value) {
  return JSON.stringify(String(value));
}

function mcpToml(model) {
  const sections = [];
  for (const server of model.mcpServers) {
    const prefix = `mcp_servers.${tomlString(server.id)}`;
    sections.push(
      `[${prefix}]`,
      `command = ${tomlString(server.command)}`,
      `args = [${server.args.map(tomlString).join(", ")}]`,
      `cwd = ${tomlString(server.cwd)}`
    );
    if (Object.keys(server.env).length) {
      sections.push(`[${prefix}.env]`);
      for (const [key, value] of Object.entries(server.env)) sections.push(`${tomlString(key)} = ${tomlString(value)}`);
    }
    sections.push("");
  }
  return sections.join("\n");
}

function successfulValidation(model, skillIds) {
  return {
    ok: true,
    resourceIds: model.resourceIds,
    agentPackageSkillIds: skillIds.filter(id => !model.resourceIds.skills.includes(id))
  };
}

module.exports = {
  combinedPrompt,
  copyTree,
  createOutputRoot,
  declaredSkillNames,
  mcpServerMap,
  mcpToml,
  normalizeMaterializerInput,
  successfulValidation,
  writeJson,
  writeSharedResources,
  writeText
};
