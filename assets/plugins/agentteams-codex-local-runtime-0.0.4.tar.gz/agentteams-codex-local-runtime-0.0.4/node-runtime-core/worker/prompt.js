#!/usr/bin/env node
"use strict";

const HISTORY_CONTEXT_MARKER = "[Chat messages since your last reply - for context]";
const CURRENT_MESSAGE_MARKER = "[Current message - respond to this]";

function runtimeModel(runtimeState) {
  const runtime = runtimeState && runtimeState.runtime ? runtimeState.runtime : {};
  const desired = runtime.desired || {};
  return desired.model || {};
}

function appendMetadata(lines, metadata) {
  for (const item of metadata || []) {
    lines.push(`${item.label}: ${item.value || ""}`);
  }
}

function singleLine(value) {
  return String(value || "").replace(/[\r\n]+/g, " ").trim();
}

function messageBody(item) {
  if (item?.body !== undefined) return String(item.body || "");
  const content = item?.content && typeof item.content === "object" ? item.content : {};
  const replacement = content["m.new_content"] && typeof content["m.new_content"] === "object"
    ? content["m.new_content"]
    : null;
  return String((replacement && replacement.body) || content.body || "");
}

function messageSentAt(item) {
  const value = Number(item?.originServerTs || item?.origin_server_ts || 0);
  if (!Number.isFinite(value) || value <= 0) return "";
  try {
    return new Date(value).toISOString();
  } catch (_error) {
    return "";
  }
}

function formatMessageBlock(item, marker) {
  const lines = marker ? [marker] : [];
  const eventId = singleLine(item?.eventId || item?.event_id);
  const sentAt = messageSentAt(item);
  const matrixUserId = singleLine(item?.sender);
  const displayName = singleLine(item?.senderDisplayName || item?.sender_display_name);
  if (eventId) lines.push(`event_id: ${eventId}`);
  if (sentAt) lines.push(`sent_at: ${sentAt}`);
  if (matrixUserId || displayName) {
    lines.push("sender:");
    if (matrixUserId) lines.push(`  matrix_user_id: ${matrixUserId}`);
    if (displayName) lines.push(`  display_name: ${displayName}`);
  }
  lines.push("message:");
  lines.push(messageBody(item));
  return lines;
}

function buildStableRuntimePrompt(options) {
  const opts = options || {};
  const lines = Array.isArray(opts.introLines) ? [...opts.introLines] : [];
  appendMetadata(lines, opts.metadata);
  for (const line of opts.guidanceLines || []) {
    lines.push(line);
  }

  const model = opts.model || runtimeModel(opts.runtimeState);
  if (model.model) {
    lines.push(`Managed model: ${model.model}`);
  }
  if (opts.workspace) {
    lines.push(`Workspace: ${opts.workspace}`);
  }
  const contextSections = (opts.contextSections || []).filter(Boolean);
  if (contextSections.length) {
    lines.push("");
    lines.push(opts.contextTitle || "Runtime context:");
    lines.push(...contextSections);
  }
  return `${lines.join("\n").replace(/\s+$/, "")}\n`;
}

function buildMatrixTurnPrompt(options) {
  const opts = options || {};
  const lines = [];
  appendMetadata(lines, opts.metadata || opts.turnMetadata);
  if (opts.taskPathHint) {
    lines.push(`Task path: ${opts.taskPathHint}`);
  }

  const roomHistory = Array.isArray(opts.roomHistory) ? opts.roomHistory : [];
  const history = roomHistory.slice(-20).filter(item => messageBody(item).trim());
  if (history.length) {
    if (lines.length) lines.push("");
    lines.push(HISTORY_CONTEXT_MARKER);
    lines.push("");
    history.forEach((item, index) => {
      lines.push(...formatMessageBlock(item, "[History message]"));
      if (index < history.length - 1) lines.push("");
    });
    lines.push("");
  } else if (lines.length) {
    lines.push("");
  }
  const currentMessages = Array.isArray(opts.currentMessages) ? opts.currentMessages : [];
  if (currentMessages.length) {
    currentMessages.forEach((item, index) => {
      const marker = currentMessages.length === 1
        ? CURRENT_MESSAGE_MARKER
        : `[Current message ${index + 1} - respond to this]`;
      lines.push(marker);
      if (index === 0 && opts.currentMessagePrefix) {
        lines.push(String(opts.currentMessagePrefix).trim(), "");
      }
      lines.push(...formatMessageBlock(item));
      if (index < currentMessages.length - 1) lines.push("");
    });
  } else {
    lines.push(CURRENT_MESSAGE_MARKER);
    lines.push(opts.currentMessage || "");
  }
  return `${lines.join("\n").replace(/\s+$/, "")}\n`;
}

function buildRuntimePrompt(options) {
  const stable = buildStableRuntimePrompt(options).trimEnd();
  const turn = buildMatrixTurnPrompt(options).trimEnd();
  if (stable && turn) return `${stable}\n\n${turn}\n`;
  if (stable) return `${stable}\n`;
  return `${turn}\n`;
}

function extractTaskPathHint(text) {
  const match = String(text || "").match(/(shared\/tasks\/[A-Za-z0-9_.:/@-]+)/);
  return match ? match[1] : "";
}

function nonEmpty(value) {
  return String(value || "").trim();
}

function teamPromptProfile(role) {
  const normalized = nonEmpty(role);
  if (normalized === "team_leader") {
    return { teamPromptName: "TEAMS.md", rolePromptName: "leader" };
  }
  if (normalized === "worker") {
    return { teamPromptName: "TEAMS.md", rolePromptName: "worker" };
  }
  if (normalized === "standalone") {
    return { teamPromptName: "", rolePromptName: "worker" };
  }
  throw new Error(`runtime role is not supported: ${normalized || "<missing>"}`);
}

function memberPromptFacts(member, role) {
  const source = member || {};
  return {
    name: nonEmpty(source.name),
    runtimeName: nonEmpty(source.runtimeName),
    role,
    runtime: nonEmpty(source.runtime),
    matrixUserId: nonEmpty(source.matrixUserId),
    personalRoomId: nonEmpty(source.personalRoomId)
  };
}

function rosterEntry(member) {
  const source = member && typeof member === "object" && !Array.isArray(member) ? member : {};
  return {
    name: nonEmpty(source.name),
    runtimeName: nonEmpty(source.runtimeName),
    role: nonEmpty(source.role),
    matrixUserId: nonEmpty(source.matrixUserId),
    personalRoomId: nonEmpty(source.personalRoomId)
  };
}

function runtimePromptProjection(runtimeState) {
  const runtime = runtimeState?.runtime || {};
  const team = runtime.team || {};
  const member = runtime.member || {};
  const hasTeam = Boolean(nonEmpty(runtimeState?.edge?.teamName || team.name || team.teamName));
  const role = nonEmpty(runtimeState?.staticRole || member.role);
  teamPromptProfile(role);
  const projection = {
    role,
    member: memberPromptFacts(member, role)
  };

  if (role === "standalone" || !hasTeam) return projection;

  const members = Array.isArray(team.members) ? team.members.map(rosterEntry) : [];
  const leaderName = nonEmpty(team.leaderName);
  const leaderRuntimeName = nonEmpty(team.leaderRuntimeName);
  const leader = members.find(item => item.role === "team_leader")
    || members.find(item => leaderRuntimeName && item.runtimeName === leaderRuntimeName)
    || members.find(item => leaderName && item.name === leaderName)
    || {};
  projection.team = {
    name: nonEmpty(runtimeState?.edge?.teamName || team.name || team.teamName),
    teamRoomId: nonEmpty(runtime.matrix?.teamRoomId || team.teamRoomId || team.roomId)
  };

  if (role === "team_leader") {
    const admin = team.admin && typeof team.admin === "object" && !Array.isArray(team.admin) ? team.admin : {};
    projection.team.leaderDmRoomId = nonEmpty(team.leaderDmRoomId);
    projection.team.admin = {
      name: nonEmpty(admin.name),
      matrixUserId: nonEmpty(admin.matrixUserId)
    };
    projection.members = members;
  } else if (role === "worker") {
    projection.leader = {
      name: leaderName || nonEmpty(leader.name),
      runtimeName: leaderRuntimeName || nonEmpty(leader.runtimeName),
      matrixUserId: nonEmpty(leader.matrixUserId)
    };
  }

  return projection;
}

function pushFact(lines, label, value) {
  const text = nonEmpty(value);
  if (text) lines.push(`- ${label}: ${text}`);
}

function matrixTurnMetadata(options) {
  const opts = options || {};
  const metadata = [];
  if (opts.roomId) metadata.push({ label: "Room ID", value: opts.roomId });
  return metadata;
}

function managedRuntimeContextBlock(runtimeState, options) {
  const opts = options || {};
  const projection = runtimePromptProjection(runtimeState);
  const hasMember = Object.values(projection.member || {}).some(Boolean);
  if (!projection.team && !hasMember) return "";
  const start = opts.startMarker || "<!-- BEGIN TEAMHARNESS RUNTIME CONTEXT -->";
  const end = opts.endMarker || "<!-- END TEAMHARNESS RUNTIME CONTEXT -->";
  const lines = [
    start,
    "## Runtime Team Context",
    ""
  ];

  if (projection.team) {
    lines.push("### Team");
    pushFact(lines, "Team", projection.team.name);
    pushFact(lines, "Team room", projection.team.teamRoomId);
    if (projection.role === "team_leader") {
      pushFact(lines, "Leader DM room", projection.team.leaderDmRoomId);
      pushFact(lines, "Admin", projection.team.admin?.name);
      pushFact(lines, "Admin Matrix user", projection.team.admin?.matrixUserId);
    }
    lines.push("");
  }

  if (projection.leader) {
    lines.push("### Leader");
    pushFact(lines, "Name", projection.leader.name);
    pushFact(lines, "Runtime name", projection.leader.runtimeName);
    pushFact(lines, "Matrix user", projection.leader.matrixUserId);
    lines.push("");
  }

  lines.push("### Current member");
  pushFact(lines, "Member", projection.member.name);
  pushFact(lines, "Runtime name", projection.member.runtimeName);
  pushFact(lines, "Role", projection.member.role);
  pushFact(lines, "Runtime", projection.member.runtime);
  pushFact(lines, "Matrix user", projection.member.matrixUserId);
  pushFact(lines, "Personal room", projection.member.personalRoomId);

  if (Array.isArray(projection.members) && projection.members.length) {
    lines.push("", "### Team members");
    for (const member of projection.members) {
      const fields = [
        ["name", member.name],
        ["runtimeName", member.runtimeName],
        ["role", member.role],
        ["matrixUserId", member.matrixUserId],
        ["personalRoomId", member.personalRoomId]
      ].filter(([, value]) => Boolean(value));
      if (fields.length) lines.push(`- ${fields.map(([key, value]) => `${key}: ${value}`).join(", ")}`);
    }
  }

  lines.push("");
  lines.push("Do not include secrets, credentials, or live task status in this context block.");
  lines.push(end);
  return lines.join("\n");
}

module.exports = {
  HISTORY_CONTEXT_MARKER,
  CURRENT_MESSAGE_MARKER,
  buildStableRuntimePrompt,
  buildMatrixTurnPrompt,
  buildRuntimePrompt,
  extractTaskPathHint,
  teamPromptProfile,
  runtimePromptProjection,
  matrixTurnMetadata,
  managedRuntimeContextBlock
};
