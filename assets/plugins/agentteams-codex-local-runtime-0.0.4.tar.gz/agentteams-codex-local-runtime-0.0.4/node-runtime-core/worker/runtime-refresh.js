#!/usr/bin/env node
"use strict";

const {
  createMutableRuntimeCandidate,
  createRuntimeSnapshot,
  discardPreparedPluginRuntime
} = require("./plugin-runtime");
const { retainView } = require("./view-registry");

const coordinators = new WeakMap();
const VIEW_DIGEST_PATTERN = /^sha256:[0-9a-f]{64}$/;

function abortError() {
  const error = new Error("runtime refresh aborted");
  error.name = "AbortError";
  return error;
}

function isAbortError(error) {
  return Boolean(error && error.name === "AbortError");
}

function throwIfAborted(signal) {
  if (signal?.aborted) throw abortError();
}

function awaitWithSignal(promise, signal) {
  if (!signal) return Promise.resolve(promise);
  if (signal.aborted) return Promise.reject(abortError());
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (callback, value) => {
      if (settled) return;
      settled = true;
      signal.removeEventListener("abort", onAbort);
      callback(value);
    };
    const onAbort = () => finish(reject, abortError());
    signal.addEventListener("abort", onAbort, { once: true });
    Promise.resolve(promise).then(
      value => finish(resolve, value),
      error => finish(reject, error)
    );
  });
}

function coordinatorFor(runtimeState) {
  let coordinator = coordinators.get(runtimeState);
  if (!coordinator) {
    coordinator = {
      closed: false,
      controller: new AbortController(),
      inFlight: null,
      closePromise: null
    };
    coordinators.set(runtimeState, coordinator);
  }
  return coordinator;
}

function replaceObjectContents(target, source, replacements, preserveKeys) {
  const preserved = new Map();
  for (const key of preserveKeys || []) {
    const descriptor = Object.getOwnPropertyDescriptor(target, key);
    if (descriptor) preserved.set(key, descriptor);
  }
  for (const key of Reflect.ownKeys(target)) {
    if (preserved.has(key)) continue;
    const descriptor = Object.getOwnPropertyDescriptor(target, key);
    if (descriptor?.configurable) delete target[key];
  }
  for (const key of Reflect.ownKeys(source)) {
    if (preserved.has(key)) continue;
    const descriptor = Object.getOwnPropertyDescriptor(source, key);
    if (!descriptor) continue;
    if (Object.prototype.hasOwnProperty.call(descriptor, "value") && replacements.has(descriptor.value)) {
      descriptor.value = replacements.get(descriptor.value);
    }
    const existing = Object.getOwnPropertyDescriptor(target, key);
    if (existing && !existing.configurable) {
      if (Object.prototype.hasOwnProperty.call(descriptor, "value") && existing.writable) {
        target[key] = descriptor.value;
      }
      continue;
    }
    Object.defineProperty(target, key, descriptor);
  }
  for (const [key, descriptor] of preserved) {
    const existing = Object.getOwnPropertyDescriptor(target, key);
    if (!existing || existing.configurable) Object.defineProperty(target, key, descriptor);
  }
}

function applyRuntime(rootArgs, rootRuntimeState, sourceArgs, sourceRuntimeState) {
  const replacements = new Map([
    [sourceArgs, rootArgs],
    [sourceRuntimeState, rootRuntimeState]
  ]);
  replaceObjectContents(
    rootArgs,
    sourceArgs,
    replacements,
    rootArgs.edgeTokenRefreshPromise ? ["edgeTokenRefreshPromise"] : []
  );
  replaceObjectContents(
    rootRuntimeState,
    sourceRuntimeState,
    replacements,
    [
      "matrixCredentialRevision",
      "matrixState",
      "matrixSyncAbortController",
      "refreshPromise"
    ]
  );
  rootArgs.runtimeState = rootRuntimeState;
  rootRuntimeState.args = rootArgs;
}

function refreshIdentity(args, runtimeState) {
  return JSON.stringify({
    runtimeDigest: String(runtimeState?.digest || ""),
    viewDigest: String(runtimeState?.pluginRuntime?.viewDigest || ""),
    agentPackageDigest: String(
      runtimeState?.agentPackage?.agentPackageDigest ||
      runtimeState?.agentPackage?.digest ||
      runtimeState?.pluginRuntime?.agentPackageDigest ||
      ""
    ),
    modelMode: String(args?.effectiveModelConfigMode || ""),
    modelSignature: String(args?.modelConfigSignature || ""),
    openclawConfigPath: String(args?.openclawConfigPath || "")
  });
}

function closeCandidateProxy(candidate, initialServer) {
  const proxy = candidate?.args?.modelProxy;
  if (!proxy?.server || proxy.server === initialServer) return Promise.resolve();
  return new Promise(resolve => {
    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve();
    };
    const timer = setTimeout(finish, 1000);
    timer.unref?.();
    try {
      proxy.server.close(finish);
    } catch {
      finish();
    }
  });
}

function retainPreviousView(args, runtimeState, candidateRuntimeState) {
  const previousDigest = String(runtimeState?.pluginRuntime?.viewDigest || "");
  const candidateDigest = String(candidateRuntimeState?.pluginRuntime?.viewDigest || "");
  if (!VIEW_DIGEST_PATTERN.test(previousDigest) || previousDigest === candidateDigest) {
    return null;
  }
  return retainView(args, previousDigest);
}

async function runRefresh(options) {
  const opts = options || {};
  const args = opts.args || {};
  const runtimeState = opts.runtimeState || {};
  if (typeof opts.reconcile !== "function") {
    throw new Error("runtime refresh reconcile is required");
  }
  throwIfAborted(opts.signal);
  const coordinator = coordinatorFor(runtimeState);
  throwIfAborted(coordinator.controller.signal);

  if (coordinator.inFlight) {
    return awaitWithSignal(coordinator.inFlight, opts.signal);
  }
  if (!opts.force && typeof opts.refreshRequired === "function" && !opts.refreshRequired()) {
    return null;
  }

  const base = createRuntimeSnapshot(args, runtimeState);
  const candidate = createMutableRuntimeCandidate(args, runtimeState);
  const rollback = createMutableRuntimeCandidate(args, runtimeState);
  const initialProxyServer = candidate.args?.modelProxy?.server;
  const beforeIdentity = refreshIdentity(args, runtimeState);

  const refresh = (async () => {
    let previousViewLease = null;
    try {
      await opts.reconcile({
        args: candidate.args,
        baseSnapshot: base,
        force: Boolean(opts.force),
        liveRuntimeState: runtimeState,
        runtimeState: candidate.runtimeState,
        signal: coordinator.controller.signal
      });
      throwIfAborted(coordinator.controller.signal);

      const changed = beforeIdentity !== refreshIdentity(candidate.args, candidate.runtimeState);
      previousViewLease = retainPreviousView(args, runtimeState, candidate.runtimeState);
      applyRuntime(args, runtimeState, candidate.args, candidate.runtimeState);
      try {
        if (changed) await opts.onApplied?.(base);
        else await opts.onChecked?.(base);
      } catch (error) {
        applyRuntime(args, runtimeState, rollback.args, rollback.runtimeState);
        await opts.onRollback?.(base);
        throw error;
      }
      return {
        changed,
        snapshot: createRuntimeSnapshot(args, runtimeState)
      };
    } catch (error) {
      await closeCandidateProxy(candidate, initialProxyServer);
      discardPreparedPluginRuntime(candidate.args, candidate.runtimeState);
      throw error;
    } finally {
      previousViewLease?.release();
    }
  })();

  coordinator.inFlight = refresh.finally(() => {
    if (coordinator.inFlight === tracked) coordinator.inFlight = null;
  });
  const tracked = coordinator.inFlight;
  tracked.catch(() => {});
  return awaitWithSignal(tracked, opts.signal);
}

async function runLiveRefresh(options) {
  const opts = options || {};
  const args = opts.args || {};
  const runtimeState = opts.runtimeState || {};
  if (typeof opts.reconcile !== "function") {
    throw new Error("runtime refresh reconcile is required");
  }
  throwIfAborted(opts.signal);
  const coordinator = coordinatorFor(runtimeState);
  throwIfAborted(coordinator.controller.signal);

  if (coordinator.inFlight) {
    return awaitWithSignal(coordinator.inFlight, opts.signal);
  }
  if (!opts.force && typeof opts.refreshRequired === "function" && !opts.refreshRequired()) {
    return null;
  }

  const base = createRuntimeSnapshot(args, runtimeState);
  const beforeIdentity = refreshIdentity(args, runtimeState);
  const refresh = (async () => {
    await opts.reconcile({
      args,
      baseSnapshot: base,
      force: Boolean(opts.force),
      liveRuntimeState: runtimeState,
      runtimeState,
      signal: coordinator.controller.signal
    });
    throwIfAborted(coordinator.controller.signal);
    const changed = beforeIdentity !== refreshIdentity(args, runtimeState);
    if (changed) await opts.onApplied?.(base);
    else await opts.onChecked?.(base);
    return {
      changed,
      snapshot: createRuntimeSnapshot(args, runtimeState)
    };
  })();

  coordinator.inFlight = refresh.finally(() => {
    if (coordinator.inFlight === tracked) coordinator.inFlight = null;
  });
  const tracked = coordinator.inFlight;
  tracked.catch(() => {});
  return awaitWithSignal(tracked, opts.signal);
}

function closeRuntimeRefresh(runtimeState) {
  const coordinator = coordinatorFor(runtimeState || {});
  if (coordinator.closePromise) return coordinator.closePromise;
  coordinator.closed = true;
  coordinator.controller.abort();
  coordinator.closePromise = Promise.allSettled(
    coordinator.inFlight ? [coordinator.inFlight] : []
  ).then(() => undefined);
  return coordinator.closePromise;
}

module.exports = {
  abortError,
  awaitWithSignal,
  closeRuntimeRefresh,
  isAbortError,
  runLiveRefresh,
  runRefresh,
  throwIfAborted
};
