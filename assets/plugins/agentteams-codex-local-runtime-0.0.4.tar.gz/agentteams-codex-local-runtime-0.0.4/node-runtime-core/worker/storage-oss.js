#!/usr/bin/env node
"use strict";

const crypto = require("crypto");
const { logEvent } = require("./log");

const endpointFallbacks = new Map();

function stripEndpoint(endpoint) {
  return String(endpoint || "").trim().replace(/\/+$/, "");
}

function ossPublicEndpointFallback(endpoint) {
  const parsed = new URL(endpoint);
  const suffix = "-internal.aliyuncs.com";
  if (!parsed.hostname.includes("oss-") || !parsed.hostname.endsWith(suffix)) {
    return "";
  }
  parsed.hostname = `${parsed.hostname.slice(0, -suffix.length)}.aliyuncs.com`;
  return parsed.toString().replace(/\/+$/, "");
}

function brokerOssEndpoint(sts) {
  const endpoint = stripEndpoint(sts.oss_endpoint || sts.ossEndpoint || "");
  try {
    return ossPublicEndpointFallback(endpoint) || endpoint;
  } catch {
    return endpoint;
  }
}

function encodeObjectKey(key) {
  return String(key || "")
    .split("/")
    .map(part => encodeURIComponent(part))
    .join("/");
}

function ossRequestUrl(endpoint, bucket, objectKey, query) {
  const parsed = new URL(stripEndpoint(endpoint));
  const pathStyle = parsed.hostname === "localhost" || /^\d+\.\d+\.\d+\.\d+$/.test(parsed.hostname);
  if (pathStyle) {
    parsed.pathname = `/${bucket}${objectKey ? `/${encodeObjectKey(objectKey)}` : "/"}`;
  } else if (parsed.hostname.split(".")[0] === bucket) {
    parsed.pathname = objectKey ? `/${encodeObjectKey(objectKey)}` : "/";
  } else {
    parsed.hostname = `${bucket}.${parsed.hostname}`;
    parsed.pathname = objectKey ? `/${encodeObjectKey(objectKey)}` : "/";
  }
  parsed.search = query || "";
  return parsed;
}

function canonicalizedOssResource(bucket, objectKey, queryKeys) {
  const resource = `/${bucket}${objectKey ? `/${objectKey}` : "/"}`;
  if (!queryKeys || queryKeys.length === 0) {
    return resource;
  }
  return `${resource}?${queryKeys.sort().join("&")}`;
}

function ossAuthHeaders(method, sts, bucket, objectKey, queryKeys) {
  const date = new Date().toUTCString();
  const securityToken = String(sts.security_token || sts.securityToken || "");
  const canonicalHeaders = securityToken ? `x-oss-security-token:${securityToken}\n` : "";
  const canonicalResource = canonicalizedOssResource(bucket, objectKey, queryKeys);
  const stringToSign = `${method}\n\n\n${date}\n${canonicalHeaders}${canonicalResource}`;
  const signature = crypto
    .createHmac("sha1", String(sts.access_key_secret || sts.accessKeySecret || ""))
    .update(stringToSign)
    .digest("base64");
  const headers = {
    Date: date,
    Authorization: `OSS ${String(sts.access_key_id || sts.accessKeyId || "")}:${signature}`
  };
  if (securityToken) {
    headers["x-oss-security-token"] = securityToken;
  }
  return headers;
}

function requestAbortContext(options) {
  const external = options?.signal;
  const timeoutMs = Number(options?.timeoutMs || 0);
  if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) {
    return { signal: external, cleanup() {} };
  }
  const controller = new AbortController();
  const abort = () => controller.abort();
  if (external?.aborted) controller.abort();
  else external?.addEventListener("abort", abort, { once: true });
  const timer = setTimeout(abort, timeoutMs);
  timer.unref?.();
  return {
    signal: controller.signal,
    cleanup() {
      clearTimeout(timer);
      external?.removeEventListener("abort", abort);
    }
  };
}

async function ossFetch(method, sts, objectKey, options) {
  const bucket = String(sts.oss_bucket || sts.ossBucket || "").trim();
  const endpoint = stripEndpoint(sts.oss_endpoint || sts.ossEndpoint || "");
  if (!bucket || !endpoint) {
    throw new Error("STS response missing OSS endpoint or bucket");
  }
  const query = options && options.query ? options.query : "";
  const queryKeys = options && options.queryKeys ? options.queryKeys : [];
  const body = options && options.body;
  const abortContext = requestAbortContext(options);
  const signal = abortContext.signal;
  const tryEndpoint = async candidate => {
    const url = ossRequestUrl(candidate, bucket, objectKey, query);
    const headers = ossAuthHeaders(method, sts, bucket, objectKey, queryKeys);
    const response = await fetch(url, { method, headers, body, signal });
    const data = Buffer.from(await response.arrayBuffer());
    if (!response.ok) {
      const error = new Error(`${method} ${url} failed: ${response.status} ${data.toString("utf8")}`);
      error.ossStatus = response.status;
      throw error;
    }
    return data;
  };
  try {
    try {
      const cachedFallback = endpointFallbacks.get(endpoint);
      if (cachedFallback) {
        return await tryEndpoint(cachedFallback);
      }
      return await tryEndpoint(endpoint);
    } catch (error) {
      if (signal?.aborted) throw error;
      let fallback = "";
      try {
        fallback = ossPublicEndpointFallback(endpoint);
      } catch {
        fallback = "";
      }
      if (!fallback) {
        throw error;
      }
      if (!error.ossStatus) {
        endpointFallbacks.set(endpoint, fallback);
        logEvent("warn", "oss_endpoint_fallback_selected", {
          endpoint,
          fallbackEndpoint: fallback,
          method,
          objectKey,
          error
        });
      }
      return await tryEndpoint(fallback);
    }
  } finally {
    abortContext.cleanup();
  }
}

async function ossGet(sts, objectKey, options) {
  return (await ossFetch("GET", sts, objectKey, options)).toString("utf8");
}

async function ossPut(sts, objectKey, content, options) {
  await ossFetch("PUT", sts, objectKey, {
    ...(options || {}),
    body: Buffer.isBuffer(content) ? content : Buffer.from(String(content))
  });
}

async function ossDelete(sts, objectKey, options) {
  await ossFetch("DELETE", sts, objectKey, options);
}

function decodeXmlText(value) {
  return String(value || "")
    .replace(/&#x([0-9a-f]+);/gi, (_match, code) => String.fromCodePoint(Number.parseInt(code, 16)))
    .replace(/&#([0-9]+);/g, (_match, code) => String.fromCodePoint(Number.parseInt(code, 10)))
    .replace(/&(lt|gt|quot|apos|amp);/g, entity => ({
      "&lt;": "<",
      "&gt;": ">",
      "&quot;": "\"",
      "&apos;": "'",
      "&amp;": "&"
    })[entity]);
}

function xmlValues(xml, tag) {
  const pattern = new RegExp(`<${tag}>([\\s\\S]*?)</${tag}>`, "g");
  return Array.from(xml.matchAll(pattern)).map(match => decodeXmlText(match[1]));
}

async function ossList(sts, prefix, options) {
  const normalizedPrefix = String(prefix || "");
  const keys = [];
  let marker = "";
  while (true) {
    const query = `?prefix=${encodeURIComponent(normalizedPrefix)}` +
      (marker ? `&marker=${encodeURIComponent(marker)}` : "");
    const xml = (await ossFetch("GET", sts, "", {
      ...(options || {}),
      query,
      queryKeys: []
    })).toString("utf8");
    const pageKeys = xmlValues(xml, "Key");
    keys.push(...pageKeys);
    const truncated = xmlValues(xml, "IsTruncated")[0]?.trim().toLowerCase() === "true";
    if (!truncated) return keys;

    const nextMarker = xmlValues(xml, "NextMarker")[0] || pageKeys.at(-1) || "";
    if (!nextMarker || nextMarker === marker) {
      throw new Error("OSS LIST pagination did not advance");
    }
    marker = nextMarker;
  }
}

module.exports = {
  stripEndpoint,
  ossPublicEndpointFallback,
  brokerOssEndpoint,
  encodeObjectKey,
  ossRequestUrl,
  canonicalizedOssResource,
  ossAuthHeaders,
  ossFetch,
  ossGet,
  ossPut,
  ossDelete,
  ossList
};
