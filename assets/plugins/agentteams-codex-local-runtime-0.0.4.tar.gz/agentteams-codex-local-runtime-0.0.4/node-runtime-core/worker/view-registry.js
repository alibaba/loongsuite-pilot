#!/usr/bin/env node
"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { isDeepStrictEqual } = require("node:util");

const registries = new Map();

function viewError(reason, message) {
  return Object.assign(new Error(message), { reason });
}

function instanceKey(args) {
  const value = String(args?.instanceDir || "").trim()
    || (args?.stateDir ? path.dirname(path.resolve(args.stateDir)) : "");
  if (!value) throw viewError("ViewRegistryInvalid", "instanceDir or stateDir is required");
  return path.resolve(value);
}

function registryFor(args) {
  const key = instanceKey(args);
  let registry = registries.get(key);
  if (!registry) {
    registry = {
      currentDigest: "",
      views: new Map()
    };
    registries.set(key, registry);
  }
  return registry;
}

function pathWithin(root, candidate) {
  const relative = path.relative(path.resolve(root), path.resolve(candidate));
  return relative === "" ||
    (!relative.startsWith(`..${path.sep}`) && relative !== ".." && !path.isAbsolute(relative));
}

function cleanupPaths(args, runtimeState, viewDigest, pluginDir, agentPackage) {
  const digest = String(viewDigest || "").replace(/^sha256:/, "");
  const instanceRoot = instanceKey(args);
  const pluginRoot = path.join(instanceRoot, "plugins");
  const configuredViewPath = String(runtimeState?.pluginRuntime?.viewPath || "").trim();
  const viewPath = configuredViewPath &&
    path.basename(path.resolve(configuredViewPath)) === `sha256-${digest}` &&
    pathWithin(pluginRoot, configuredViewPath) &&
    pathWithin(configuredViewPath, pluginDir)
    ? path.resolve(configuredViewPath)
    : "";

  const packageDigest = String(
    agentPackage.agentPackageDigest ||
    agentPackage.digest ||
    runtimeState?.pluginRuntime?.agentPackageDigest ||
    ""
  ).replace(/^sha256:/, "");
  const configuredPackageRoot = String(agentPackage.packageRoot || "").trim();
  const expectedPackageRoot = packageDigest
    ? path.resolve(args.stateDir, "agent-package", "versions", packageDigest)
    : "";
  const packageRoot = configuredPackageRoot &&
    path.resolve(configuredPackageRoot) === expectedPackageRoot
    ? expectedPackageRoot
    : "";
  return Object.freeze({ packageRoot, viewPath });
}

function cloneStatic(value, seen) {
  if (value === null || typeof value !== "object") return value;
  if (seen.has(value)) {
    throw viewError("ViewSnapshotInvalid", "View static data must not contain cycles");
  }
  seen.add(value);
  let clone;
  if (Array.isArray(value)) {
    clone = value.map(item => cloneStatic(item, seen));
  } else {
    const prototype = Object.getPrototypeOf(value);
    if (prototype !== Object.prototype && prototype !== null) {
      throw viewError("ViewSnapshotInvalid", "View static data must contain only plain objects and arrays");
    }
    clone = {};
    for (const [key, item] of Object.entries(value)) {
      clone[key] = cloneStatic(item, seen);
    }
  }
  seen.delete(value);
  return Object.freeze(clone);
}

function staticSnapshot(value) {
  return cloneStatic(value === undefined ? null : value, new WeakSet());
}

function staticPluginRuntime(runtimeState) {
  const source = runtimeState?.pluginRuntime || {};
  return staticSnapshot({
    viewDigest: source.viewDigest,
    materializedPluginDir: source.materializedPluginDir,
    resolvedResources: source.resolvedResources || {}
  });
}

function createStaticView(args, runtimeState) {
  const pluginRuntime = runtimeState?.pluginRuntime || {};
  const agentPackage = runtimeState?.agentPackage || pluginRuntime.agentPackage || {};
  const viewDigest = String(pluginRuntime.viewDigest || "").trim();
  const pluginDir = String(args?.pluginDir || pluginRuntime.materializedPluginDir || "").trim();
  if (!viewDigest) throw viewError("ViewSnapshotInvalid", "pluginRuntime.viewDigest is required");
  if (!pluginDir) throw viewError("ViewSnapshotInvalid", "pluginDir is required");
  return {
    cleanup: cleanupPaths(args, runtimeState, viewDigest, pluginDir, agentPackage),
    view: Object.freeze({
      viewDigest,
      pluginDir,
      pluginRuntimeEnv: staticSnapshot(args?.pluginRuntimeEnv || {}),
      pluginMcpServers: staticSnapshot(args?.pluginMcpServers || []),
      pluginRuntime: staticPluginRuntime(runtimeState),
      agentPackage: staticSnapshot({
        agentPackageDigest: agentPackage.agentPackageDigest || agentPackage.digest || pluginRuntime.agentPackageDigest || ""
      })
    })
  };
}

function viewStatus(record) {
  if (!record.status) {
    record.status = Object.freeze({
      viewDigest: record.view.viewDigest,
      get activeTurns() {
        return record.activeTurns;
      },
      get retired() {
        return record.retired;
      }
    });
  }
  return record.status;
}

function removeDirectory(directory) {
  if (!directory) return;
  fs.rmSync(directory, { recursive: true, force: true });
}

function pruneDirectories(root, keep, namePattern) {
  if (!fs.existsSync(root)) return;
  for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
    if (!entry.isDirectory() || !namePattern.test(entry.name)) continue;
    const candidate = path.join(root, entry.name);
    if (keep && path.resolve(candidate) === path.resolve(keep)) continue;
    removeDirectory(candidate);
  }
}

function pruneRestartArtifacts(args, current) {
  const pluginRoot = path.join(instanceKey(args), "plugins");
  if (fs.existsSync(pluginRoot)) {
    for (const plugin of fs.readdirSync(pluginRoot, { withFileTypes: true })) {
      if (!plugin.isDirectory()) continue;
      pruneDirectories(
        path.join(pluginRoot, plugin.name, "views"),
        current.cleanup.viewPath,
        /^sha256-[0-9a-f]{64}$/
      );
    }
  }
  pruneDirectories(
    path.join(args.stateDir, "agent-package", "versions"),
    current.cleanup.packageRoot,
    /^[0-9a-f]{64}$/
  );
}

function collectRetiredView(registry, digest) {
  const record = registry.views.get(digest);
  if (!record || !record.retired || record.activeLeases !== 0) return false;
  removeDirectory(record.cleanup.viewPath);
  const packageInUse = record.cleanup.packageRoot && [...registry.views.entries()].some(([otherDigest, other]) =>
    otherDigest !== digest && other.cleanup.packageRoot === record.cleanup.packageRoot
  );
  if (record.cleanup.packageRoot && !packageInUse) {
    removeDirectory(record.cleanup.packageRoot);
  }
  registry.views.delete(digest);
  return true;
}

function discardUnpublishedResources(args, resources) {
  const candidate = resources || {};
  const cleanup = cleanupPaths(
    args,
    {
      pluginRuntime: {
        agentPackageDigest: candidate.agentPackageDigest,
        viewPath: candidate.viewPath
      }
    },
    candidate.viewDigest,
    candidate.materializedPluginDir || candidate.viewPath,
    {
      agentPackageDigest: candidate.agentPackageDigest,
      packageRoot: candidate.packageRoot
    }
  );
  const registry = registryFor(args);
  if (cleanup.viewPath && ![...registry.views.values()].some(record =>
    record.cleanup.viewPath === cleanup.viewPath
  )) {
    removeDirectory(cleanup.viewPath);
  }
  if (cleanup.packageRoot && ![...registry.views.values()].some(record =>
    record.cleanup.packageRoot === cleanup.packageRoot
  )) {
    removeDirectory(cleanup.packageRoot);
  }
}

function publishCurrentView(args, runtimeState) {
  const registry = registryFor(args);
  const firstPublication = !registry.currentDigest && registry.views.size === 0;
  const prepared = createStaticView(args, runtimeState);
  const view = prepared.view;
  let record = registry.views.get(view.viewDigest);
  if (record) {
    if (!isDeepStrictEqual(record.view, view) || !isDeepStrictEqual(record.cleanup, prepared.cleanup)) {
      throw viewError("ViewDigestConflict", `View ${view.viewDigest} has conflicting static content`);
    }
  } else {
    record = {
      activeLeases: 0,
      activeTurns: 0,
      cleanup: prepared.cleanup,
      retired: false,
      status: null,
      view
    };
    registry.views.set(view.viewDigest, record);
  }

  if (registry.currentDigest && registry.currentDigest !== view.viewDigest) {
    const previous = registry.views.get(registry.currentDigest);
    if (previous) previous.retired = true;
  }
  record.retired = false;
  registry.currentDigest = view.viewDigest;
  if (firstPublication) pruneRestartArtifacts(args, record);
  for (const digest of [...registry.views.keys()]) collectRetiredView(registry, digest);
  return viewStatus(record);
}

function capturedSnapshot(args, runtimeState, view) {
  const snapshotArgs = {
    ...(args || {}),
    pluginDir: view.pluginDir,
    pluginRuntimeEnv: view.pluginRuntimeEnv,
    pluginMcpServers: view.pluginMcpServers
  };
  const snapshotRuntimeState = {
    ...(runtimeState || {}),
    edge: staticSnapshot(runtimeState?.edge || {}),
    runtime: staticSnapshot(runtimeState?.runtime || {}),
    pluginRuntime: view.pluginRuntime,
    agentPackage: view.agentPackage
  };
  snapshotArgs.runtimeState = snapshotRuntimeState;
  snapshotRuntimeState.args = snapshotArgs;
  return Object.freeze({
    args: Object.freeze(snapshotArgs),
    runtimeState: Object.freeze(snapshotRuntimeState)
  });
}

function retainRecord(registry, record, viewDigest, activeTurn) {
  record.activeLeases += 1;
  if (activeTurn) record.activeTurns += 1;
  let released = false;
  return {
    viewDigest,
    release() {
      if (released) return false;
      released = true;
      record.activeLeases -= 1;
      if (activeTurn) record.activeTurns -= 1;
      collectRetiredView(registry, viewDigest);
      return true;
    }
  };
}

function retainView(args, digest) {
  const registry = registryFor(args);
  const viewDigest = String(digest || "").trim();
  const record = registry.views.get(viewDigest);
  if (!record) throw viewError("ViewNotFound", `View is not published: ${viewDigest || "<missing>"}`);
  return Object.freeze(retainRecord(registry, record, viewDigest, false));
}

function retainCurrentView(args) {
  const registry = registryFor(args);
  if (!registry.currentDigest) {
    throw viewError("ViewNotReady", "Current View has not been published");
  }
  return retainView(args, registry.currentDigest);
}

function captureView(args, runtimeState, digest) {
  const registry = registryFor(args);
  const viewDigest = String(digest || "").trim();
  const record = registry.views.get(viewDigest);
  if (!record) throw viewError("ViewNotFound", `View is not published: ${viewDigest || "<missing>"}`);
  const lease = retainRecord(registry, record, viewDigest, true);
  return Object.freeze({
    ...lease,
    snapshot: capturedSnapshot(args, runtimeState, record.view),
    view: viewStatus(record)
  });
}

function captureCurrentView(args, runtimeState) {
  const registry = registryFor(args);
  if (!registry.currentDigest) {
    throw viewError("ViewNotReady", "Current View has not been published");
  }
  return captureView(args, runtimeState, registry.currentDigest);
}

function releaseView(handle) {
  return Boolean(handle && typeof handle.release === "function" && handle.release());
}

module.exports = {
  captureCurrentView,
  captureView,
  discardUnpublishedResources,
  publishCurrentView,
  releaseView,
  retainCurrentView,
  retainView
};
