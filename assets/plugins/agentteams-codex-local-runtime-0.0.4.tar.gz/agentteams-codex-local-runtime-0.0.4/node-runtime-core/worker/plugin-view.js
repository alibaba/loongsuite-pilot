#!/usr/bin/env node
"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");

const instanceLocks = new Map();
const VIEW_MARKER = ".plugin-view.json";

function canonicalValue(value) {
  if (Array.isArray(value)) return value.map(canonicalValue);
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.keys(value).sort().map(key => [key, canonicalValue(value[key])])
    );
  }
  return value;
}

function canonicalJson(value) {
  return JSON.stringify(canonicalValue(value));
}

function requiredText(inputs, name) {
  const value = String(inputs?.[name] ?? "").trim();
  if (!value) throw new Error(`${name} is required to compute plugin view identity`);
  return value;
}

function stableIdentity(inputs) {
  return {
    pluginName: requiredText(inputs, "pluginName"),
    pluginDigest: requiredText(inputs, "pluginDigest"),
    runtime: requiredText(inputs, "runtime"),
    runtimeRole: requiredText(inputs, "runtimeRole"),
    pluginRole: requiredText(inputs, "pluginRole"),
    resolvedResourcesDigest: requiredText(inputs, "resolvedResourcesDigest"),
    agentPackageDigest: requiredText(inputs, "agentPackageDigest"),
    runtimeBindingDigest: requiredText(inputs, "runtimeBindingDigest"),
    materializerVersion: requiredText(inputs, "materializerVersion")
  };
}

function computePluginViewIdentity(inputs) {
  const payload = canonicalJson(stableIdentity(inputs));
  return `sha256:${crypto.createHash("sha256").update(payload).digest("hex")}`;
}

function viewDirectoryName(viewDigest) {
  const match = String(viewDigest || "").match(/^sha256:([0-9a-f]{64})$/);
  if (!match) throw new Error(`invalid plugin view digest: ${viewDigest}`);
  return `sha256-${match[1]}`;
}

function pathWithin(root, candidate) {
  const relative = path.relative(path.resolve(root), path.resolve(candidate));
  return relative === "" || (!relative.startsWith(`..${path.sep}`) && relative !== ".." && !path.isAbsolute(relative));
}

function assertPathWithin(root, candidate, label) {
  if (!pathWithin(root, candidate)) {
    throw new Error(`${label} must remain inside ${root}`);
  }
}

function assertNoSymlinkComponents(root, candidate, label) {
  const resolvedRoot = path.resolve(root);
  const resolvedCandidate = path.resolve(candidate);
  assertPathWithin(resolvedRoot, resolvedCandidate, label);
  const relative = path.relative(resolvedRoot, resolvedCandidate);
  let current = resolvedRoot;
  for (const component of relative.split(path.sep).filter(Boolean)) {
    current = path.join(current, component);
    if (fs.existsSync(current) && fs.lstatSync(current).isSymbolicLink()) {
      throw new Error(`${label} must not contain symbolic links: ${current}`);
    }
  }
}

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf8"));
}

function writeJsonAtomic(file, payload) {
  fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
  const temporary = path.join(path.dirname(file), `.${path.basename(file)}.${process.pid}.${crypto.randomUUID()}.tmp`);
  let temporaryCreated = false;
  try {
    fs.writeFileSync(temporary, `${JSON.stringify(payload, null, 2)}\n`, { mode: 0o600, flag: "wx" });
    temporaryCreated = true;
    fs.renameSync(temporary, file);
    temporaryCreated = false;
    try {
      fs.chmodSync(file, 0o600);
    } catch {
      // The atomic replacement already succeeded.
    }
  } finally {
    if (temporaryCreated) fs.rmSync(temporary, { force: true });
  }
}

function walkTree(root, visit) {
  const entry = fs.lstatSync(root);
  if (entry.isSymbolicLink()) throw new Error(`plugin view must not contain symbolic links: ${root}`);
  if (!entry.isDirectory() && !entry.isFile()) throw new Error(`plugin view contains unsupported entry: ${root}`);
  if (entry.isFile() && entry.nlink !== 1) throw new Error(`plugin view must not contain hard links: ${root}`);
  if (entry.isDirectory()) {
    for (const name of fs.readdirSync(root)) walkTree(path.join(root, name), visit);
  }
  visit(root, entry);
}

function computeTreeContentDigest(root) {
  const digest = crypto.createHash("sha256");
  const visit = (entryPath, relative) => {
    const entry = fs.lstatSync(entryPath);
    if (entry.isSymbolicLink()) throw new Error(`plugin view must not contain symbolic links: ${entryPath}`);
    if (entry.isDirectory()) {
      digest.update(`D\0${relative}\0`);
      for (const name of fs.readdirSync(entryPath).sort()) {
        if (!relative && name === VIEW_MARKER) continue;
        visit(path.join(entryPath, name), relative ? `${relative}/${name}` : name);
      }
      return;
    }
    if (!entry.isFile()) throw new Error(`plugin view contains unsupported entry: ${entryPath}`);
    if (entry.nlink !== 1) throw new Error(`plugin view must not contain hard links: ${entryPath}`);
    const content = fs.readFileSync(entryPath);
    const executable = (entry.mode & 0o111) ? "x" : "-";
    digest.update(`F\0${relative}\0${executable}\0${content.length}\0`);
    digest.update(content);
    digest.update("\0");
  };
  visit(root, "");
  return `sha256:${digest.digest("hex")}`;
}

function validateMaterializedTree(stagingDir, materializedPluginDir) {
  if (!fs.existsSync(materializedPluginDir)) {
    throw new Error(`adapter did not create materialized plugin directory: ${materializedPluginDir}`);
  }
  const realStaging = fs.realpathSync(stagingDir);
  const realMaterialized = fs.realpathSync(materializedPluginDir);
  assertPathWithin(realStaging, realMaterialized, "materializedPluginDir");
  if (!fs.statSync(realMaterialized).isDirectory()) {
    throw new Error(`materializedPluginDir is not a directory: ${materializedPluginDir}`);
  }
  walkTree(stagingDir, () => {});
  return realMaterialized;
}

function makeTreeReadOnly(root) {
  walkTree(root, (entryPath, entry) => {
    const permissions = entry.mode & 0o777;
    const nextMode = entry.isDirectory()
      ? ((permissions | 0o700) & ~0o022)
      : (permissions & ~0o222);
    fs.chmodSync(entryPath, nextMode);
  });
}

function makeTreeWritable(root) {
  if (!fs.existsSync(root)) return;
  const entry = fs.lstatSync(root);
  if (entry.isSymbolicLink()) return;
  if (entry.isDirectory()) {
    fs.chmodSync(root, (entry.mode & 0o777) | 0o700);
    for (const name of fs.readdirSync(root)) makeTreeWritable(path.join(root, name));
  } else if (entry.isFile()) {
    if (entry.nlink === 1) fs.chmodSync(root, (entry.mode & 0o777) | 0o600);
  } else {
    throw new Error(`plugin view contains unsupported entry: ${root}`);
  }
}

function removeTree(root) {
  if (!fs.existsSync(root)) return;
  makeTreeWritable(root);
  fs.rmSync(root, { recursive: true, force: true });
}

function validationSucceeded(result) {
  return result === true || Boolean(result && typeof result === "object" && result.ok === true);
}

function markerForView(viewPath, expectedDigest, expectedIdentity) {
  const markerPath = path.join(viewPath, VIEW_MARKER);
  if (!fs.existsSync(markerPath)) throw new Error(`published plugin view marker is missing: ${markerPath}`);
  const marker = readJson(markerPath);
  if (marker.viewDigest !== expectedDigest || canonicalJson(marker.identity) !== canonicalJson(expectedIdentity)) {
    throw new Error(`published plugin view identity does not match ${expectedDigest}`);
  }
  if (!/^sha256:[0-9a-f]{64}$/.test(String(marker.contentDigest || "")) ||
      computeTreeContentDigest(viewPath) !== marker.contentDigest) {
    throw new Error(`plugin view content digest mismatch: ${viewPath}`);
  }
  const relative = String(marker.materializedRelativePath || "");
  if (!relative || path.isAbsolute(relative)) throw new Error(`published plugin view has invalid materialized path: ${relative}`);
  const materializedPluginDir = path.resolve(viewPath, relative);
  assertPathWithin(viewPath, materializedPluginDir, "published materializedPluginDir");
  const realView = fs.realpathSync(viewPath);
  const realMaterialized = fs.realpathSync(materializedPluginDir);
  assertPathWithin(realView, realMaterialized, "published materializedPluginDir");
  if (!fs.statSync(realMaterialized).isDirectory()) {
    throw new Error(`published materializedPluginDir is not a directory: ${materializedPluginDir}`);
  }
  return { marker, materializedPluginDir };
}

async function withInstanceLock(instancePluginDir, operation) {
  const key = path.resolve(instancePluginDir);
  const previous = instanceLocks.get(key) || Promise.resolve();
  let release;
  const token = new Promise(resolve => { release = resolve; });
  const tail = previous.then(() => token);
  instanceLocks.set(key, tail);
  await previous;
  try {
    return await operation();
  } finally {
    release();
    if (instanceLocks.get(key) === tail) instanceLocks.delete(key);
  }
}

function publishPluginCurrent(options) {
  const opts = options || {};
  const instancePluginDir = path.resolve(requiredText(opts, "instancePluginDir"));
  const materializedPath = path.resolve(requiredText(opts, "materializedPath"));
  const viewDigest = requiredText(opts, "viewDigest");
  const viewPath = path.join(instancePluginDir, "views", viewDirectoryName(viewDigest));
  assertPathWithin(viewPath, materializedPath, "materializedPath");
  if (!fs.existsSync(materializedPath) || !fs.statSync(materializedPath).isDirectory()) {
    throw new Error(`materializedPath is not a directory: ${materializedPath}`);
  }
  const payload = {
    name: requiredText(opts, "name"),
    version: requiredText(opts, "version"),
    pluginDigest: requiredText(opts, "pluginDigest"),
    materializerVersion: requiredText(opts, "materializerVersion"),
    viewDigest,
    materializedPath,
    updatedAt: new Date().toISOString()
  };
  writeJsonAtomic(path.join(instancePluginDir, "current.json"), payload);
  return payload;
}

function identityFromPreparation(options) {
  const opts = options || {};
  const source = opts.verifiedSource || {};
  const resources = opts.resolvedResources || {};
  const plugin = resources.plugin || {};
  const bindings = opts.runtimeBindings || {};
  const agentPackage = opts.agentPackage || {};
  const adapter = opts.adapter || {};
  return stableIdentity({
    pluginName: source.name || plugin.name,
    pluginDigest: source.pluginDigest || plugin.digest,
    runtime: opts.runtime || adapter.runtime,
    runtimeRole: resources.runtimeRole,
    pluginRole: resources.pluginRole,
    resolvedResourcesDigest: resources.resolvedResourcesDigest,
    agentPackageDigest: agentPackage.agentPackageDigest || agentPackage.digest,
    runtimeBindingDigest: bindings.runtimeBindingDigest,
    materializerVersion: adapter.materializerVersion
  });
}

async function preparePluginView(options) {
  const opts = options || {};
  const instanceRoot = path.resolve(requiredText(opts, "instanceRoot"));
  const instancePluginDir = path.resolve(requiredText(opts, "instancePluginDir"));
  const adapter = opts.adapter || {};
  if (typeof adapter.materialize !== "function") throw new Error("adapter.materialize is required");
  assertNoSymlinkComponents(instanceRoot, instancePluginDir, "plugin view path");
  const identity = identityFromPreparation(opts);
  const viewDigest = computePluginViewIdentity(identity);
  const viewPath = path.join(instancePluginDir, "views", viewDirectoryName(viewDigest));

  fs.mkdirSync(path.join(instancePluginDir, "views"), { recursive: true, mode: 0o700 });
  assertNoSymlinkComponents(instanceRoot, viewPath, "plugin view path");
  const realInstanceRoot = fs.realpathSync(instanceRoot);
  const realInstancePluginDir = fs.realpathSync(instancePluginDir);
  assertPathWithin(realInstanceRoot, realInstancePluginDir, "instancePluginDir");
  return withInstanceLock(instancePluginDir, async () => {
    assertNoSymlinkComponents(instanceRoot, viewPath, "plugin view path");
    let materializedPluginDir;
    let reused = false;
    if (fs.existsSync(viewPath)) {
      ({ materializedPluginDir } = markerForView(viewPath, viewDigest, identity));
      makeTreeReadOnly(viewPath);
      reused = true;
    } else {
      const stagingDir = path.join(instancePluginDir, `.view-staging-${crypto.randomUUID()}`);
      fs.mkdirSync(stagingDir, { recursive: false, mode: 0o700 });
      try {
        const result = await adapter.materialize({
          verifiedSource: opts.verifiedSource,
          resolvedResources: opts.resolvedResources,
          runtimeBindings: opts.runtimeBindings,
          agentPackage: opts.agentPackage,
          runtime: identity.runtime,
          runtimeRole: identity.runtimeRole,
          pluginRole: identity.pluginRole,
          materializerVersion: identity.materializerVersion,
          viewDigest,
          targetDir: stagingDir
        });
        if (!result || !validationSucceeded(result.validationResult)) {
          const message = result?.validationResult?.message || "adapter materialization validation failed";
          throw new Error(message);
        }
        const stagedMaterialized = validateMaterializedTree(stagingDir, result.materializedPluginDir);
        const relative = path.relative(fs.realpathSync(stagingDir), stagedMaterialized) || ".";
        const contentDigest = computeTreeContentDigest(stagingDir);
        fs.writeFileSync(path.join(stagingDir, VIEW_MARKER), `${JSON.stringify({
          viewDigest,
          identity,
          contentDigest,
          materializedRelativePath: relative
        }, null, 2)}\n`, { mode: 0o444 });
        try {
          fs.renameSync(stagingDir, viewPath);
        } catch (error) {
          if (!fs.existsSync(viewPath)) throw error;
          ({ materializedPluginDir } = markerForView(viewPath, viewDigest, identity));
          reused = true;
        }
        if (!reused) {
          materializedPluginDir = path.resolve(viewPath, relative);
          makeTreeReadOnly(viewPath);
        }
      } finally {
        removeTree(stagingDir);
      }
    }

    const source = opts.verifiedSource || {};
    const plugin = opts.resolvedResources?.plugin || {};
    const current = opts.publishCurrent === false ? null : publishPluginCurrent({
      instancePluginDir,
      name: identity.pluginName,
      version: source.version || plugin.version,
      pluginDigest: identity.pluginDigest,
      materializerVersion: identity.materializerVersion,
      viewDigest,
      materializedPath: materializedPluginDir
    });
    return {
      viewDigest,
      viewPath,
      materializedPluginDir,
      reused,
      current
    };
  });
}

module.exports = {
  canonicalJson,
  computePluginViewIdentity,
  preparePluginView,
  publishPluginCurrent
};
