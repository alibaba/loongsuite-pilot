#!/usr/bin/env node
"use strict";

const crypto = require("crypto");
const path = require("path");
const YAML = require("yaml");
const { logEvent } = require("./log");
const { writeJson, writeStatus, positiveIntervalSeconds, stsRefreshRequired } = require("./status");
const { requestSts } = require("./controller");
const { ossGet } = require("./storage-oss");
const { modelConfigLogFields } = require("./model-config");
const { canonicalJson } = require("./plugin-view");
const {
  createMutableRuntimeCandidate,
  createRuntimeSnapshot,
  discardPreparedPluginRuntime
} = require("./plugin-runtime");
const { captureCurrentView, captureView } = require("./view-registry");
const {
  abortError,
  awaitWithSignal,
  closeRuntimeRefresh,
  isAbortError,
  runLiveRefresh,
  throwIfAborted
} = require("./runtime-refresh");

const RUNTIME_ROLES = new Set(["team_leader", "worker", "standalone"]);
const DEFAULT_MATRIX_TOKEN_VALIDATION_TIMEOUT_MS = 10_000;
const MODEL_ARG_KEYS = [
  "effectiveModelConfigMode",
  "lastAdapterModelConfigLogKey",
  "lastModelBrokerModeLogKey",
  "modelConfigSignature",
  "modelRoute",
  "requestedModelConfigMode"
];
const PLUGIN_ARG_KEYS = ["pluginDir", "pluginMcpServers", "pluginRuntimeEnv"];

function parseRuntimeYaml(text) {
  const parsed = YAML.parse(String(text || ""));
  if (parsed === null || parsed === undefined) return {};
  if (typeof parsed !== "object" || Array.isArray(parsed)) {
    throw new Error("runtime.yaml root must be a mapping");
  }
  return parsed;
}

function runtimeConfigDigest(runtime) {
  const normalized = { ...(runtime || {}) };
  if (normalized.metadata && typeof normalized.metadata === "object" && !Array.isArray(normalized.metadata)) {
    normalized.metadata = { ...normalized.metadata };
    delete normalized.metadata.updatedAt;
  }
  return crypto.createHash("sha256").update(canonicalJson(normalized)).digest("hex");
}

function runtimeRole(runtime) {
  const role = String(runtime?.member?.role || "").trim();
  if (!role) {
    throw Object.assign(new Error("runtime.member.role is required"), {
      reason: "InvalidRuntimeRole"
    });
  }
  if (!RUNTIME_ROLES.has(role)) {
    throw Object.assign(new Error(`runtime.member.role is not supported: ${role}`), {
      reason: "InvalidRuntimeRole"
    });
  }
  return role;
}

function runtimeObjectKey(runtimeName) {
  return `agents/${runtimeName}/runtime/runtime.yaml`;
}

function preserveCurrentRuntime(error) {
  if (error && (typeof error === "object" || typeof error === "function")) {
    Object.defineProperty(error, "preserveCurrentRuntime", {
      configurable: true,
      enumerable: false,
      value: true
    });
    return error;
  }
  return Object.assign(new Error(String(error)), { preserveCurrentRuntime: true });
}

function matrixUserId(runtime) {
  return String(runtime?.member?.matrixUserId || "").trim();
}

function matrixAccessToken(runtime) {
  return String(runtime?.matrix?.accessToken || "");
}

function matrixCredentialValidationTimeoutError(timeoutMs) {
  return Object.assign(
    new Error(`Matrix token validation timed out after ${timeoutMs}ms`),
    {
      name: "TimeoutError",
      reason: "MatrixCredentialValidationTimeout",
      timeoutMs
    }
  );
}

async function validateMatrixAccessToken(runtime, edge, options) {
  const token = matrixAccessToken(runtime);
  const expectedUserId = matrixUserId(runtime);
  const homeserver = String(edge?.matrixHomeserver || "").trim().replace(/\/+$/, "");
  if (!token || !expectedUserId || !homeserver) {
    throw Object.assign(
      new Error("matrix access token validation requires bootstrap homeserver, matrixUserId, and accessToken"),
      { reason: "MatrixCredentialInvalid" }
    );
  }
  const signal = options?.signal;
  throwIfAborted(signal);
  const configuredTimeoutMs = Number(options?.timeoutMs);
  const timeoutMs = Number.isFinite(configuredTimeoutMs) && configuredTimeoutMs > 0
    ? configuredTimeoutMs
    : DEFAULT_MATRIX_TOKEN_VALIDATION_TIMEOUT_MS;
  const controller = new AbortController();
  let abortListener;
  let timeoutId;
  let aborted = false;
  let timedOut = false;
  const abortGate = signal && new Promise((_, reject) => {
    abortListener = () => {
      aborted = true;
      const error = abortError();
      controller.abort(error);
      reject(error);
    };
    if (signal.aborted) abortListener();
    else signal.addEventListener("abort", abortListener, { once: true });
  });
  const timeoutGate = new Promise((_, reject) => {
    timeoutId = setTimeout(() => {
      timedOut = true;
      const error = matrixCredentialValidationTimeoutError(timeoutMs);
      controller.abort(error);
      reject(error);
    }, timeoutMs);
  });
  const request = (async () => {
    const response = await fetch(new URL("/_matrix/client/v3/account/whoami", `${homeserver}/`), {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json"
      },
      signal: controller.signal
    });
    const text = await response.text();
    if (!response.ok) {
      throw Object.assign(
        new Error(`Matrix token validation failed: ${response.status} ${text}`),
        { reason: "MatrixCredentialInvalid", status: response.status }
      );
    }
    const body = text.trim() ? JSON.parse(text) : {};
    const actualUserId = String(body.user_id || "").trim();
    if (actualUserId !== expectedUserId) {
      throw Object.assign(
        new Error(`Matrix token belongs to ${actualUserId || "<unknown>"}, expected ${expectedUserId}`),
        {
          reason: "MatrixTokenIdentityMismatch",
          expectedUserId,
          actualUserId
        }
      );
    }
  })();
  try {
    return await Promise.race([
      request,
      timeoutGate,
      ...(abortGate ? [abortGate] : [])
    ]);
  } catch (error) {
    if (aborted) throw abortError();
    if (timedOut) throw matrixCredentialValidationTimeoutError(timeoutMs);
    throw error;
  } finally {
    clearTimeout(timeoutId);
    if (abortListener) {
      signal.removeEventListener("abort", abortListener);
    }
  }
}

function teamRoomId(runtime) {
  return String(runtime?.matrix?.teamRoomId || runtime?.team?.teamRoomId || runtime?.team?.roomId || "").trim();
}

function personalRoomId(runtime) {
  return String(runtime?.member?.personalRoomId || "").trim();
}

function matrixRooms(runtime) {
  const seen = new Set();
  const rooms = [];
  for (const roomId of [teamRoomId(runtime), personalRoomId(runtime)]) {
    if (roomId && !seen.has(roomId)) {
      seen.add(roomId);
      rooms.push(roomId);
    }
  }
  return rooms;
}

function runtimeStateSnapshot(runtimeState) {
  const parsed = runtimeState.runtime || {};
  const desired = parsed.desired || {};
  const model = desired.model || {};
  return {
    objectKey: runtimeState.objectKey,
    digest: runtimeState.digest,
    loadedAt: runtimeState.loadedAt,
    member: parsed.member || {},
    desired: {
      model: {
        model: model.model || "",
        providerId: model.providerId || "",
        gatewayUrl: model.gatewayUrl || "",
        hasGatewayKey: Boolean(String(model.gatewayKey || "").trim())
      },
      agentPackage: desired.agentPackage || {},
      skillRegistry: desired.skillRegistry || {}
    },
    modelConfig: runtimeState.modelConfig || {},
    storage: parsed.storage || {}
  };
}

function publishRuntimeConfigState(args, edge, runtimeState) {
  writeJson(path.join(args.stateDir, "runtime-state.json"), runtimeStateSnapshot(runtimeState));
  writeStatus(args, "Running", "RuntimeConfigApplied", "runtime.yaml applied", {
    workerName: edge.workerName,
    runtimeDigest: runtimeState.digest || ""
  });
  logEvent("info", "runtime_config_applied", {
    ...modelConfigLogFields(args, edge, runtimeState),
    objectKey: runtimeState.objectKey || "",
    digest: runtimeState.digest || ""
  });
}

async function loadRuntimeConfig(args, edge, sts, options) {
  const signal = options?.signal;
  throwIfAborted(signal);
  const runtimeName = String(edge.runtimeName || edge.workerName || "").trim();
  const objectKey = runtimeObjectKey(runtimeName);
  let yaml;
  try {
    yaml = await ossGet(sts, objectKey, { signal });
  } catch (error) {
    throw preserveCurrentRuntime(error);
  }
  throwIfAborted(signal);
  const parsed = parseRuntimeYaml(yaml);
  const role = runtimeRole(parsed);
  const expectedRole = String(options?.expectedRole || "").trim();
  if (expectedRole && role !== expectedRole) {
    throw Object.assign(
      new Error(`runtime role cannot change after startup: ${expectedRole} -> ${role}`),
      {
        reason: "RoleChangeNotSupported",
        expectedRole,
        candidateRole: role
      }
    );
  }
  const bootstrapHomeserver = String(edge?.matrixHomeserver || "").trim().replace(/\/+$/, "");
  const expectedHomeserver = String(options?.expectedHomeserver || "").trim().replace(/\/+$/, "");
  if (expectedHomeserver && bootstrapHomeserver !== expectedHomeserver) {
    throw Object.assign(
      new Error(`bootstrap matrix homeserver cannot change in place: ${expectedHomeserver} -> ${bootstrapHomeserver}`),
      {
        reason: "InstanceRedeployRequired",
        changeReason: "MatrixHomeserverChanged"
      }
    );
  }
  const candidateMatrixUserId = matrixUserId(parsed);
  const expectedMatrixUserId = String(options?.expectedMatrixUserId || "").trim();
  if (expectedMatrixUserId && candidateMatrixUserId !== expectedMatrixUserId) {
    throw Object.assign(
      new Error(`runtime matrix user cannot change in place: ${expectedMatrixUserId} -> ${candidateMatrixUserId}`),
      {
        reason: "InstanceRedeployRequired",
        changeReason: "MatrixUserChanged"
      }
    );
  }
  const digest = runtimeConfigDigest(parsed);
  const runtimeState = {
    objectKey,
    digest,
    loadedAt: new Date().toISOString(),
    staticRole: expectedRole || role,
    staticMatrixHomeserver: expectedHomeserver || bootstrapHomeserver,
    staticMatrixUserId: expectedMatrixUserId || candidateMatrixUserId,
    runtime: parsed
  };
  logEvent("info", "runtime_config_loaded", {
    ...modelConfigLogFields(args, edge, runtimeState),
    objectKey,
    digest,
    teamRoomId: teamRoomId(parsed),
    personalRoomId: personalRoomId(parsed)
  });
  return runtimeState;
}

function updateRuntimeState(target, source) {
  target.objectKey = source.objectKey;
  target.digest = source.digest;
  target.loadedAt = source.loadedAt;
  target.staticRole = source.staticRole || target.staticRole;
  target.staticMatrixHomeserver = source.staticMatrixHomeserver || target.staticMatrixHomeserver;
  target.staticMatrixUserId = source.staticMatrixUserId || target.staticMatrixUserId;
  target.runtime = source.runtime;
}

function runtimeConfigUnchanged(baseSnapshot, runtimeState) {
  const baseState = baseSnapshot?.runtimeState;
  if (!baseState) return false;
  return Boolean(
    String(baseState.digest || "") &&
    String(baseState.digest || "") === String(runtimeState?.digest || "") &&
    String(baseState.objectKey || "") === String(runtimeState?.objectKey || "")
  );
}

function runtimeRefreshDue(args, runtimeState) {
  const interval = positiveIntervalSeconds(args.runtimeRefreshIntervalSeconds, 60);
  if (interval === 0) return true;
  const last = Math.max(
    Number(runtimeState.lastRuntimeRefreshAt || 0),
    Number(runtimeState.lastRuntimeRefreshAttemptAt || 0)
  );
  return Date.now() - last >= interval * 1000;
}

async function refreshRemoteRuntime(args, edge, runtimeState, options) {
  const signal = options?.signal;
  throwIfAborted(signal);
  if (runtimeState.refreshPromise) {
    return awaitWithSignal(runtimeState.refreshPromise, signal);
  }
  const force = Boolean(options && options.force);
  const refreshRuntime = force || runtimeRefreshDue(args, runtimeState);
  runtimeState.refreshPromise = (async () => {
    if (refreshRuntime) {
      const attemptedAt = Date.now();
      runtimeState.lastRuntimeRefreshAttemptAt = attemptedAt;
      if (options?.liveRuntimeState && options.liveRuntimeState !== runtimeState) {
        options.liveRuntimeState.lastRuntimeRefreshAttemptAt = attemptedAt;
      }
    }
    if (stsRefreshRequired(runtimeState.sts)) {
      try {
        runtimeState.sts = await requestSts(args, edge, { signal });
        if (options?.liveRuntimeState && options.liveRuntimeState !== runtimeState) {
          options.liveRuntimeState.sts = runtimeState.sts;
        }
      } catch (error) {
        throw preserveCurrentRuntime(error);
      }
      throwIfAborted(signal);
    }
    if (refreshRuntime) {
      const next = await loadRuntimeConfig(args, edge, runtimeState.sts, {
        signal,
        expectedRole: runtimeState.staticRole,
        expectedHomeserver: runtimeState.staticMatrixHomeserver,
        expectedMatrixUserId: runtimeState.staticMatrixUserId
      });
      throwIfAborted(signal);
      if (matrixAccessToken(next.runtime) !== matrixAccessToken(runtimeState.runtime)) {
        await validateMatrixAccessToken(next.runtime, edge, { signal });
        throwIfAborted(signal);
      }
      updateRuntimeState(runtimeState, next);
      runtimeState.lastRuntimeRefreshAt = Date.now();
      logEvent("info", "runtime_config_refreshed", {
        ...modelConfigLogFields(args, edge, runtimeState),
        force,
        digest: runtimeState.digest
      });
    }
    return runtimeState;
  })().finally(() => {
    runtimeState.refreshPromise = null;
  });
  return runtimeState.refreshPromise;
}

function notifyMatrixTokenChanged(args, runtimeState, baseSnapshot) {
  const previous = matrixAccessToken(baseSnapshot?.runtimeState?.runtime);
  const current = matrixAccessToken(runtimeState.runtime);
  if (previous === current) return;
  if (String(runtimeState.matrixCredentialHandle?.current?.token || "") === current) return;
  runtimeState.matrixCredentialRevision = Number(runtimeState.matrixCredentialRevision || 0) + 1;
  if (runtimeState.matrixCredentialHandle) {
    runtimeState.matrixCredentialHandle.current = Object.freeze({
      token: current,
      revision: runtimeState.matrixCredentialRevision
    });
  }
  runtimeState.matrixSyncAbortController?.abort?.();
  logEvent("info", "matrix_access_token_rotated", {
    runtime: args.runtime,
    revision: runtimeState.matrixCredentialRevision
  });
}

function runtimeFacetIdentity(runtime, facet) {
  const desired = runtime?.desired || {};
  if (facet === "model") return canonicalJson(desired.model || {});
  if (facet === "agentPackage") return canonicalJson(desired.agentPackage || {});
  throw new Error(`unsupported runtime facet: ${facet}`);
}

function selectedValues(target, keys) {
  return Object.fromEntries(keys.map(key => [key, target[key]]));
}

function cloneRuntimeData(value) {
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}

function setDesiredFacet(runtime, facet, value) {
  runtime.desired = runtime.desired && typeof runtime.desired === "object"
    ? runtime.desired
    : {};
  if (value === undefined) delete runtime.desired[facet];
  else runtime.desired[facet] = cloneRuntimeData(value);
}

function restoreSelectedValues(target, values) {
  for (const [key, value] of Object.entries(values)) {
    if (value === undefined) delete target[key];
    else target[key] = value;
  }
}

function applyModelCandidate(args, runtimeState, candidate) {
  const previous = {
    args: selectedValues(args, MODEL_ARG_KEYS),
    modelConfig: runtimeState.modelConfig,
    modelProxy: args.modelProxy,
    runtimeModel: cloneRuntimeData(runtimeState.runtime?.desired?.model)
  };
  for (const key of MODEL_ARG_KEYS) {
    if (candidate.args[key] === undefined) delete args[key];
    else args[key] = candidate.args[key];
  }
  const candidateProxy = candidate.args.modelProxy;
  if (!args.modelProxy || candidateProxy?.server !== args.modelProxy?.server) {
    if (candidateProxy) args.modelProxy = candidateProxy;
  } else if (candidateProxy?.kind) {
    args.modelProxy.kind = candidateProxy.kind;
  }
  runtimeState.modelConfig = candidate.runtimeState.modelConfig;
  setDesiredFacet(runtimeState.runtime, "model", candidate.runtimeState.runtime?.desired?.model);
  return () => {
    restoreSelectedValues(args, previous.args);
    if (previous.modelProxy === undefined) delete args.modelProxy;
    else args.modelProxy = previous.modelProxy;
    if (previous.modelConfig === undefined) delete runtimeState.modelConfig;
    else runtimeState.modelConfig = previous.modelConfig;
    setDesiredFacet(runtimeState.runtime, "model", previous.runtimeModel);
  };
}

function applyPluginCandidate(args, runtimeState, candidate) {
  const previous = {
    args: selectedValues(args, PLUGIN_ARG_KEYS),
    agentPackage: runtimeState.agentPackage,
    pluginRuntime: runtimeState.pluginRuntime,
    runtimeAgentPackage: cloneRuntimeData(runtimeState.runtime?.desired?.agentPackage)
  };
  for (const key of PLUGIN_ARG_KEYS) {
    if (candidate.args[key] === undefined) delete args[key];
    else args[key] = candidate.args[key];
  }
  runtimeState.agentPackage = candidate.runtimeState.agentPackage;
  runtimeState.pluginRuntime = candidate.runtimeState.pluginRuntime;
  setDesiredFacet(runtimeState.runtime, "agentPackage", candidate.runtimeState.runtime?.desired?.agentPackage);
  return () => {
    restoreSelectedValues(args, previous.args);
    if (previous.agentPackage === undefined) delete runtimeState.agentPackage;
    else runtimeState.agentPackage = previous.agentPackage;
    if (previous.pluginRuntime === undefined) delete runtimeState.pluginRuntime;
    else runtimeState.pluginRuntime = previous.pluginRuntime;
    setDesiredFacet(runtimeState.runtime, "agentPackage", previous.runtimeAgentPackage);
  };
}

function candidateFailure(kind, identity, error) {
  return {
    kind,
    identity,
    reason: error?.reason || (kind === "model" ? "ModelCandidateInvalid" : "PluginCandidateInvalid"),
    message: String(error?.message || error),
    observedAt: new Date().toISOString()
  };
}

function candidateFailureError(runtimeState) {
  const failure = runtimeState.modelCandidateFailure || runtimeState.pluginCandidateFailure;
  if (!failure) return null;
  return Object.assign(new Error(failure.message || "runtime candidate is invalid"), {
    candidateKind: failure.kind,
    reason: failure.reason || "RuntimeCandidateInvalid"
  });
}

async function reconcileRuntimeFacets(args, edge, runtimeState, hooks, options) {
  const opts = options || {};
  const callbacks = hooks || {};
  const baseSnapshot = opts.baseSnapshot || createRuntimeSnapshot(args, runtimeState);
  const previousRuntime = baseSnapshot.runtimeState?.runtime || {};

  await refreshRemoteRuntime(args, edge, runtimeState, {
    force: opts.force,
    signal: opts.signal
  });
  throwIfAborted(opts.signal);

  const runtimeChanged = !runtimeConfigUnchanged(baseSnapshot, runtimeState);
  const observedRuntime = cloneRuntimeData(runtimeState.runtime || {});
  const appliedRuntime = cloneRuntimeData(observedRuntime);
  setDesiredFacet(appliedRuntime, "model", previousRuntime?.desired?.model);
  setDesiredFacet(appliedRuntime, "agentPackage", previousRuntime?.desired?.agentPackage);
  runtimeState.runtime = appliedRuntime;
  if (runtimeChanged) {
    notifyMatrixTokenChanged(args, runtimeState, baseSnapshot);
  }

  const previousModelIdentity = runtimeFacetIdentity(previousRuntime, "model");
  const modelIdentity = runtimeFacetIdentity(observedRuntime, "model");
  const previousPackageIdentity = runtimeFacetIdentity(previousRuntime, "agentPackage");
  const packageIdentity = runtimeFacetIdentity(observedRuntime, "agentPackage");
  const modelChanged = previousModelIdentity !== modelIdentity || Boolean(runtimeState.modelCandidateFailure);
  const packageChanged = previousPackageIdentity !== packageIdentity || Boolean(runtimeState.pluginCandidateFailure);
  const errors = [];
  let applied = runtimeChanged;

  if (modelChanged && typeof callbacks.syncModel === "function") {
    const candidate = createMutableRuntimeCandidate(args, runtimeState);
    candidate.runtimeState.runtime = cloneRuntimeData(observedRuntime);
    try {
      await callbacks.syncModel(candidate.args, candidate.runtimeState, { signal: opts.signal });
      throwIfAborted(opts.signal);
      const rollback = applyModelCandidate(args, runtimeState, candidate);
      try {
        await callbacks.publishModel?.(args, runtimeState);
      } catch (error) {
        rollback();
        throw error;
      }
      delete runtimeState.modelCandidateFailure;
      applied = true;
    } catch (error) {
      runtimeState.modelCandidateFailure = candidateFailure("model", modelIdentity, error);
      errors.push(error);
    }
  }

  if (packageChanged && typeof callbacks.preparePlugin === "function") {
    const candidate = createMutableRuntimeCandidate(args, runtimeState);
    candidate.runtimeState.runtime = cloneRuntimeData(observedRuntime);
    try {
      await callbacks.preparePlugin(candidate.args, candidate.runtimeState, { signal: opts.signal });
      throwIfAborted(opts.signal);
      const rollback = applyPluginCandidate(args, runtimeState, candidate);
      try {
        await callbacks.publishPlugin?.(args, runtimeState, { signal: opts.signal });
      } catch (error) {
        rollback();
        discardPreparedPluginRuntime(candidate.args, candidate.runtimeState);
        throw error;
      }
      delete runtimeState.pluginCandidateFailure;
      applied = true;
    } catch (error) {
      runtimeState.pluginCandidateFailure = candidateFailure("plugin", packageIdentity, error);
      errors.push(error);
    }
  }

  if (applied) {
    try {
      publishRuntimeConfigState(args, edge, runtimeState);
      await callbacks.afterApplied?.(args, runtimeState);
    } catch (error) {
      errors.push(error);
    }
  }
  if (errors.length) throw errors[0];
  return runtimeState;
}

async function runRuntimeRefresh(args, runtimeState, reconcile, options) {
  const opts = options || {};
  return runLiveRefresh({
    args,
    runtimeState,
    reconcile,
    force: Boolean(opts.force || runtimeState.modelCandidateFailure || runtimeState.pluginCandidateFailure),
    onApplied: async baseSnapshot => {
      notifyMatrixTokenChanged(args, runtimeState, baseSnapshot);
      await opts.onApplied?.(baseSnapshot);
    },
    onChecked: opts.onChecked,
    signal: opts.signal,
    refreshRequired: () => Boolean(runtimeState.modelCandidateFailure || runtimeState.pluginCandidateFailure) ||
      (typeof opts.refreshRequired === "function" && opts.refreshRequired())
  });
}

async function acquireRuntimeView(args, runtimeState, reconcile, options) {
  const opts = options || {};
  const viewDigest = String(opts.viewDigest || "").trim();
  if (viewDigest) return captureView(args, runtimeState, viewDigest);

  const blockingFailure = candidateFailureError(runtimeState);
  const refresh = runRuntimeRefresh(args, runtimeState, reconcile, {
    signal: opts.signal,
    refreshRequired: () => runtimeRefreshDue(args, runtimeState)
  });
  refresh.catch(error => {
    if (error?.preserveCurrentRuntime) {
      logEvent("warn", "runtime_refresh_preserved_current", {
        runtime: args.runtime,
        reason: error.reason || error.name || "RuntimeRefreshFailed",
        error
      });
      return;
    }
    if (!isAbortError(error)) {
      writeStatus(args, "Degraded", error?.reason || "RuntimeRefreshFailed", error?.message || String(error));
      logEvent("warn", "runtime_refresh_failed", {
        runtime: args.runtime,
        reason: error.reason || error.name || "RuntimeRefreshFailed",
        error
      });
    }
  });
  if (blockingFailure) throw blockingFailure;

  try {
    return captureCurrentView(args, runtimeState);
  } catch (error) {
    if (error?.reason !== "ViewNotReady") throw error;
    await refresh;
    const failure = candidateFailureError(runtimeState);
    if (failure) throw failure;
    return captureCurrentView(args, runtimeState);
  }
}

async function requestRuntimeReconcile(args, runtimeState, reconcile, options) {
  const opts = options || {};
  return runRuntimeRefresh(args, runtimeState, reconcile, {
    force: true,
    onApplied: opts.onApplied,
    onChecked: opts.onChecked,
    signal: opts.signal
  });
}

function startSingleFlightPeriodicTask(options) {
  const opts = options || {};
  const scheduler = opts.scheduler;
  const controller = new AbortController();
  let closed = false;
  let inFlight = null;
  let stopPromise = null;
  const tick = () => {
    if (closed || inFlight) return;
    const run = Promise.resolve().then(() => opts.run(controller.signal));
    const tracked = run.catch(error => {
      if (!closed && !isAbortError(error)) {
        try {
          opts.onError?.(error);
        } catch {
          // A status-write failure must not create an unhandled timer rejection.
        }
      }
    }).finally(() => {
      if (inFlight === tracked) inFlight = null;
    });
    inFlight = tracked;
  };
  const timer = scheduler.setInterval(tick, opts.intervalMs);
  timer?.unref?.();
  return () => {
    if (stopPromise) return stopPromise;
    closed = true;
    scheduler.clearInterval(timer);
    controller.abort();
    const active = inFlight;
    stopPromise = Promise.allSettled(active ? [active] : []).then(() => undefined);
    return stopPromise;
  };
}

function startRemotePeriodicTasks(options) {
  const opts = options || {};
  const args = opts.args || {};
  const runtimeState = opts.runtimeState || {};
  const scheduler = opts.scheduler || {
    clearInterval: timer => clearInterval(timer),
    setInterval: (callback, delay) => setInterval(callback, delay)
  };
  const stoppers = [];
  const runtimeInterval = positiveIntervalSeconds(args.runtimeRefreshIntervalSeconds, 60);
  if (runtimeInterval > 0 && typeof opts.reconcile === "function") {
    stoppers.push(startSingleFlightPeriodicTask({
      scheduler,
      intervalMs: runtimeInterval * 1000,
      run: signal => requestRuntimeReconcile(args, runtimeState, opts.reconcile, {
        signal,
        onApplied: opts.onApplied,
        onChecked: opts.onChecked,
        onRollback: opts.onRollback,
        requiresDrain: opts.requiresDrain
      }),
      onError: error => {
        if (!error?.restartRequired) {
          writeStatus(args, "Degraded", "RuntimeRefreshFailed", error.message);
        }
      }
    }));
  }
  const heartbeatInterval = positiveIntervalSeconds(args.heartbeatIntervalSeconds, 30);
  if (heartbeatInterval > 0 && typeof opts.heartbeat === "function") {
    stoppers.push(startSingleFlightPeriodicTask({
      scheduler,
      intervalMs: heartbeatInterval * 1000,
      run: async signal => {
        throwIfAborted(signal);
        opts.beforeHeartbeat?.();
        throwIfAborted(signal);
        await opts.heartbeat(signal);
        throwIfAborted(signal);
      },
      onError: error => writeStatus(args, "Degraded", "HeartbeatFailed", error.message)
    }));
  }
  let stopPromise = null;
  return () => {
    if (!stopPromise) {
      stopPromise = Promise.allSettled(stoppers.map(stop => stop()))
        .then(() => closeRuntimeRefresh(runtimeState));
    }
    return stopPromise;
  };
}

module.exports = {
  parseRuntimeYaml,
  runtimeRole,
  runtimeObjectKey,
  teamRoomId,
  personalRoomId,
  matrixRooms,
  runtimeStateSnapshot,
  publishRuntimeConfigState,
  loadRuntimeConfig,
  updateRuntimeState,
  runtimeConfigUnchanged,
  runtimeRefreshDue,
  refreshRemoteRuntime,
  reconcileRuntimeFacets,
  closeRuntimeRefresh,
  acquireRuntimeView,
  requestRuntimeReconcile,
  validateMatrixAccessToken,
  startRemotePeriodicTasks,
  throwIfAborted
};
