#!/usr/bin/env node
"use strict";

const fs = require("fs");
const http = require("http");
const path = require("path");
const crypto = require("crypto");
const { logEvent } = require("./log");
const { brokerOssEndpoint } = require("./storage-oss");
const { teamRoomId, personalRoomId, matrixRooms } = require("./runtime-config");
const { runtimePromptProjection } = require("./prompt");
const { writeJson } = require("./status");

function sendJson(res, status, payload) {
  res.writeHead(status, { "content-type": "application/json" });
  res.end(JSON.stringify(payload));
}

function defaultDescriptorWriter(args, descriptor) {
  const payload = { ...descriptor, updatedAt: new Date().toISOString() };
  const brokerRoot = path.join(args.stateDir, "runtime-services", "credential-broker");
  const descriptorFile = path.join(brokerRoot, "descriptor.json");
  fs.mkdirSync(brokerRoot, { recursive: true, mode: 0o700 });
  fs.chmodSync(brokerRoot, 0o700);
  writeJson(descriptorFile, payload, 0o600);
  return descriptorFile;
}

function publishBrokerDescriptor(args, endpoint, writeDescriptor) {
  const brokerRoot = path.join(args.stateDir, "runtime-services", "credential-broker");
  const tokenFile = path.join(brokerRoot, "token");
  const token = crypto.randomBytes(32).toString("base64url");
  fs.mkdirSync(brokerRoot, { recursive: true, mode: 0o700 });
  fs.chmodSync(brokerRoot, 0o700);
  fs.writeFileSync(tokenFile, `${token}\n`, { mode: 0o600 });
  fs.chmodSync(tokenFile, 0o600);
  const descriptor = { endpoint, tokenFile, pid: process.pid };
  const descriptorFile = writeDescriptor
    ? writeDescriptor(args, descriptor)
    : defaultDescriptorWriter(args, descriptor);
  return { descriptor, descriptorFile, token };
}

function cleanupBrokerState(args, runtimeState) {
  fs.rmSync(path.join(args.stateDir, "runtime-services", "credential-broker"), {
    recursive: true,
    force: true
  });
  if (runtimeState) {
    delete runtimeState.brokerDescriptor;
    delete runtimeState.brokerDescriptorPath;
  }
}

async function startBroker(args, edge, sts, runtimeState, options) {
  const opts = options || {};
  const runtimeId = String(opts.runtime || args.runtime || "remote-node");
  const modelConfig = typeof opts.modelConfig === "function"
    ? opts.modelConfig
    : () => ({});
  const currentExecution = () => ({ args, runtimeState });
  const currentModelCredentialsEnabled = () => {
    if (typeof opts.modelCredentialsEnabled === "function") {
      return Boolean(opts.modelCredentialsEnabled(args, edge, runtimeState));
    }
    return opts.modelCredentialsEnabled !== false;
  };
  let modelCredentialsEnabled = currentModelCredentialsEnabled();
  const updateModelCredentialsMode = trigger => {
    const next = currentModelCredentialsEnabled();
    if (next !== modelCredentialsEnabled) {
      modelCredentialsEnabled = next;
      logEvent("info", "model_broker_mode_updated", {
        runtime: runtimeId,
        modelCredentialsEnabled,
        trigger: trigger || ""
      });
    }
    return modelCredentialsEnabled;
  };
  const writeDescriptor = typeof opts.writeDescriptor === "function" ? opts.writeDescriptor : null;
  const refreshMcpConfig = typeof opts.refreshMcpConfig === "function" ? opts.refreshMcpConfig : () => {};
  const clearMcpNeedsAuthCache = typeof opts.clearMcpNeedsAuthCache === "function" ? opts.clearMcpNeedsAuthCache : () => {};

  cleanupBrokerState(args, runtimeState);
  let brokerToken = "";
  const server = http.createServer((req, res) => {
    const auth = String(req.headers.authorization || "");
    const token = auth.startsWith("Bearer ") ? auth.slice("Bearer ".length) : "";
    if (!brokerToken || token !== brokerToken) {
      sendJson(res, 401, { ok: false, error: "unauthorized" });
      return;
    }
    const execution = currentExecution();
    const requestRuntimeState = execution.runtimeState;
    if (req.method === "GET" && req.url === "/v1/runtime/context") {
      const runtime = requestRuntimeState && requestRuntimeState.runtime ? requestRuntimeState.runtime : {};
      const member = runtime.member || {};
      const desired = runtime.desired || {};
      const projection = runtimePromptProjection({
        ...requestRuntimeState,
        edge: requestRuntimeState.edge || edge
      });
      sendJson(res, 200, {
        ok: true,
        teamName: projection.team?.name || "",
        memberName: member.name || edge.workerName || "",
        runtimeName: member.runtimeName || edge.runtimeName || edge.workerName || "",
        role: projection.role,
        matrixUserId: member.matrixUserId || "",
        teamRoomId: projection.team?.teamRoomId || "",
        personalRoomId: member.personalRoomId || "",
        leaderDmRoomId: projection.team?.leaderDmRoomId || "",
        leader: projection.leader,
        admin: projection.team?.admin,
        members: projection.members,
        storage: runtime.storage || {},
        skillRegistry: desired.skillRegistry || {},
        runtimeGeneration: runtime.metadata?.generation,
        runtimeDigest: requestRuntimeState.digest || ""
      });
      return;
    }
    if (req.method === "GET" && req.url === "/v1/credentials/matrix") {
      const runtime = requestRuntimeState && requestRuntimeState.runtime ? requestRuntimeState.runtime : {};
      const matrix = runtime.matrix || {};
      const member = runtime.member || {};
      sendJson(res, 200, {
        homeserver: String(edge.matrixHomeserver || "").trim().replace(/\/+$/, ""),
        accessToken: matrix.accessToken || "",
        userId: member.matrixUserId || "",
        teamRoomId: teamRoomId(runtime),
        personalRoomId: personalRoomId(runtime),
        rooms: matrixRooms(runtime)
      });
      return;
    }
    if (req.method === "GET" && req.url === "/v1/credentials/model") {
      if (!updateModelCredentialsMode("credentials-model")) {
        sendJson(res, 404, { ok: false, error: "model_credentials_disabled" });
        return;
      }
      const llm = modelConfig(edge, requestRuntimeState) || {};
      sendJson(res, 200, {
        provider: "anthropic-compatible",
        model: llm.model || "",
        baseUrl: llm.baseUrl || "",
        apiKey: llm.apiKey || "",
        runtimeGeneration: requestRuntimeState.runtime?.metadata?.generation,
        runtimeDigest: requestRuntimeState.digest || ""
      });
      return;
    }
    if (req.method === "GET" && req.url === "/v1/credentials/skill-registry") {
      const runtime = requestRuntimeState && requestRuntimeState.runtime ? requestRuntimeState.runtime : {};
      const desired = runtime.desired || {};
      const skillRegistry = desired.skillRegistry || {};
      const currentSts = runtimeState.sts || sts;
      const payload = { ...skillRegistry };
      if (payload.authType === "sts-hiclaw") {
        payload.accessKeyId = currentSts.access_key_id;
        payload.accessKeySecret = currentSts.access_key_secret;
        payload.securityToken = currentSts.security_token;
        payload.expiration = currentSts.expiration || "";
      }
      sendJson(res, 200, payload);
      return;
    }
    if (req.method === "GET" && req.url === "/v1/credentials/storage") {
      const currentSts = runtimeState.sts || sts;
      sendJson(res, 200, {
        provider: "oss",
        accessKeyId: currentSts.access_key_id,
        accessKeySecret: currentSts.access_key_secret,
        securityToken: currentSts.security_token,
        endpoint: brokerOssEndpoint(currentSts),
        bucket: currentSts.oss_bucket,
        expiration: currentSts.expiration || "",
        expiresInSec: currentSts.expires_in_sec
      });
      return;
    }
    sendJson(res, 404, { ok: false, error: "not_found" });
  });

  try {
    await new Promise((resolve, reject) => {
      server.once("error", reject);
      server.listen(0, "127.0.0.1", resolve);
    });
    server.unref();
    const address = server.address();
    if (!address || typeof address === "string") {
      throw new Error("failed to start credential broker");
    }
    const endpoint = `http://127.0.0.1:${address.port}`;
    const published = publishBrokerDescriptor(args, endpoint, writeDescriptor);
    brokerToken = published.token;
    runtimeState.brokerDescriptor = published.descriptor;
    runtimeState.brokerDescriptorPath = published.descriptorFile;
    const descriptorFile = published.descriptorFile;
    refreshMcpConfig(args);
    clearMcpNeedsAuthCache();
    logEvent("info", "credential_broker_started", {
      runtime: runtimeId,
      endpoint,
      descriptorFile,
      modelCredentialsEnabled
    });
    logEvent("info", "model_broker_mode_updated", {
      runtime: runtimeId,
      modelCredentialsEnabled,
      trigger: "broker-started"
    });
    return server;
  } catch (error) {
    if (server.listening) server.close();
    cleanupBrokerState(args, runtimeState);
    throw error;
  }
}

module.exports = { startBroker, cleanupBrokerState };
