"use strict";

const PLUGIN_ID = "teamharness-openclaw-runtime-bridge";

module.exports = {
  id: PLUGIN_ID,
  name: "TeamHarness OpenClaw Runtime Bridge",
  register(api) {
    api.on("before_prompt_build", async () => {
      const systemContext = String(api.pluginConfig?.systemContext || "").trim();
      return systemContext ? { appendSystemContext: systemContext } : undefined;
    });
  }
};
