#!/usr/bin/env bash
set -euo pipefail

bundle_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
node_executable="${bundle_dir}/runtime-bin/node"
pilot_data_dir="${PILOT_DATA_DIR:?PILOT_DATA_DIR is required}"
plugin_ref="${LOCAL_WORKER_PLUGIN_REF:-}"

normalize_args() {
  local -a normalized=()
  while [ "$#" -gt 0 ]; do
    case "$1" in
      --plugin-install-scope)
        if [ "$#" -ge 2 ] && [ -z "${2:-}" ]; then
          normalized+=("--plugin-install-scope" "local")
          shift 2
        elif [ "$#" -ge 2 ] && [[ "${2}" != --* ]]; then
          normalized+=("--plugin-install-scope" "$2")
          shift 2
        else
          normalized+=("--plugin-install-scope" "local")
          shift
        fi
        ;;
      --model-config-mode)
        if [ "$#" -ge 2 ] && [ -z "${2:-}" ]; then
          normalized+=("--model-config-mode" "native-config")
          shift 2
        elif [ "$#" -ge 2 ] && [[ "${2}" != --* ]]; then
          normalized+=("--model-config-mode" "$2")
          shift 2
        else
          normalized+=("--model-config-mode" "native-config")
          shift
        fi
        ;;
      *)
        normalized+=("$1")
        shift
        ;;
    esac
  done
  local -a core_args=(
    "--plugin-default-file" "${bundle_dir}/plugin-default.json"
    "--node-executable" "${node_executable}"
    "--pilot-data-dir" "${pilot_data_dir}"
  )
  if [ -n "${plugin_ref}" ]; then
    core_args+=("--plugin-ref" "${plugin_ref}")
  fi
  exec "${node_executable}" "${bundle_dir}/qodercli-worker/dist/cli.js" "${core_args[@]}" "${normalized[@]}"
}

normalize_args "$@"
